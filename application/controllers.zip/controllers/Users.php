<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function index()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  = $this->Mcrud->get_users_by_un($ceks);
			$data['users']  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					$this->load->view('404_content');
			}else{

					$this->load->view('users/header', $data);
					$this->load->view('users/beranda', $data);
					$this->load->view('users/footer');

					if (isset($_POST['btnkirim'])) {
						date_default_timezone_set('Asia/Jakarta');
						$tgl = date('d-m-Y H:m:s');

						$isi 	= htmlentities(strip_tags($this->input->post('isi')));

							$data = array(
								'pengirim'			=> $id_user,
								'penerima'			=> 1,
								'isi'						=> $isi,
								'id_parent'			=> '',
								'tgl_pesan'			=> $tgl,
								'ket'						=> 'pesan'
							);
							$this->db->insert('tbl_pesan', $data);

							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Pesan berhasil dikirim ke Admin.
								</div>'
							);
							redirect('users');
					}
			}

		}
	}

	public function profile()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['jml_proyek']   = $this->Mcrud->get_countproyek();
			$data['jml_jk']       = $this->Mcrud->get_countjk();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "user") {
					$this->load->view('users/header', $data);
					$this->load->view('users/profile', $data);
					$this->load->view('users/footer');

					if (isset($_POST['btnupdate'])) {
						$password 	= htmlentities(strip_tags($this->input->post('password')));

									$data = array(
										'password'	=> md5($password)
									);
									$this->Mcrud->update_user(array('username' => $ceks), $data);

									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-success alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
											 </button>
											 <strong>Sukses!</strong> Berhasil disimpan.
										</div>'
									);
									redirect('users/profile');
					}
			}else{
					$this->load->view('404_content');
			}

		}
	}

	public function jk()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  = $this->Mcrud->get_users_by_un($ceks);
			$id_bagian = $data['user']->row()->id_bagian;
			$data['cek_bagian']  = $this->Mcrud->get_bagian_by_id("$id_bagian");
			$data['users']  = $this->Mcrud->get_users();
			// $data['kat_proyek']	  = $this->Mcrud->get_proyek_by_un($ceks);

			if ($data['user']->row()->level == "admin") {
					$this->load->view('404_content');
			}else{
					$this->load->view('users/header', $data);
					$this->load->view('users/jk', $data);
					$this->load->view('users/footer');

			}

		}
	}


	public function cek_tgl()
	{
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if (isset($_POST['tgl'])) {

				$tgl = $_POST['tgl'];

				$cek_tgl = $this->db->get_where('tbl_jam_kerja', array('id_user' => $id_user, 'tgl' => $tgl))->num_rows();

				if ($cek_tgl == 0) {
					$status = true;
					$msg = '';
				}else{
					$status = false;
					$msg = '
					<div class="alert alert-warning alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
						 </button>
						 <strong>Maaf!</strong> Tanggal "'.$tgl.'" sudah pernah diisi sebelumnya.
					</div>
					';
				}
				echo json_encode(array("status" => $status, "pesan" => $msg));

		}else{
			redirect('web/error_not_found');
		}
	}

	public function cari_proyek()
	{
		// tangkap variabel keyword dari URL
		$keyword = $this->uri->segment(3);

		// cari di database
		$data = $this->db->from('tbl_proyek')->like('kode_proyek',$keyword)->get();

		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$row->kode_proyek",
				'kode_proyek'	=>$row->kode_proyek,
				'id_proyek'	=>$row->id_proyek//,
				// 'nama_lengkap'	=>$row->nama_lengkap

			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}


	public function cari_proyek_user()
	{
		$nrp = $this->session->userdata('nrp@Proyek-2017');
		// tangkap variabel keyword dari URL
		$keyword = $this->uri->segment(3);

		// cari di database
		$this->db->join('tbl_proyek_user', 'tbl_proyek_user.id_proyek=tbl_proyek.id_proyek');
		$this->db->where('tbl_proyek_user.nrp', $nrp);
		$data = $this->db->from('tbl_proyek')->like('kode_proyek',$keyword)->get();

		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$row->kode_proyek",
				'kode_proyek'	=>$row->kode_proyek,
				'id_proyek'	=>$row->id_proyek
			);
		}

		if ($data->num_rows() == 0) {
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$keyword tidak ditemukan",
				'kode_proyek'	=>'',
				'id_proyek'	=>''
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}


	public function sel_proyek_user($id='')
	{

		// cari di database
		$data = $this->db->get_where('tbl_proyek', "id_proyek = $id");
				// format keluaran di dalam array
				// echo '<option value="">-- Pilih Proyek --</option>';
							foreach($data->result() as $row)
							{?>
								 <option value="<?php echo $row->id_proyek; ?>"><?php echo $row->nama_proyek; ?></option>
							<?php
							}
	}

	public function cari_aktivitas()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		// tangkap variabel keyword dari URL
		$keyword = $this->uri->segment(3);

		$cek_u = $this->db->get_where('tbl_user', "username='$ceks'")->row();
		// cari di database
		$this->db->where('id_bagian', "$cek_u->id_bagian");
		$data = $this->db->from('tbl_aktivitas')->like('nama_aktivitas',$keyword)->get();

		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$row->nama_aktivitas",
				'no_wbs'	=>$row->no_wbs
			);
		}

		if ($data->num_rows() == 0) {
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$keyword tidak ditemukan",
				'no_wbs'	=>''
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}

	public function simpan_jk()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}

		if (isset($_POST['tgl'])) {
				$data['user']  = $this->Mcrud->get_users_by_un($ceks)->row();
				$id_user = $data['user']->id_user;
				$tgl 		= date('d-m-Y', strtotime($this->input->post('tgl')));
				// $no_wbs	= htmlentities(strip_tags($this->input->post('no_wbs')));
				$ket	 	= $this->input->post('ket');
				$mode  	= htmlentities(strip_tags($this->input->post('mode')));

				$tgl2 = substr($tgl,0,2);
				$bln  = substr($tgl,3,2);
				$thn  = substr($tgl,6,4);


				$cek_tgl = $this->db->get_where('tbl_jam_kerja', array('id_user' => $id_user, 'tgl' => $tgl))->num_rows();

				if ($cek_tgl != 0) {
						$status = false;
						$msg = '
						<div class="alert alert-warning alert-dismissible" role="alert">
							 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
								 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
							 </button>
							 <strong>Maaf!</strong> Tanggal "'.$tgl.'" sudah pernah diisi sebelumnya.
						</div>
						';
				}else{
					// $status = true;
					// $msg = '';
					$tgl_now = date('d-m-Y');
					if ($tgl_now == $tgl) {
							$st = "tepat";
							$cs = "";
					}else{
							$st = "telat";
							$cs = "-t";
					}

					$ip	= $this->input->post('id_proyek');

					$no = 0;
					$result = array();
					foreach($ip AS $key => $val){
						$kode_proyekx = $_POST['kode_proyek'][$key];
						$id_proyekx = $_POST['id_proyek'][$key];
						$jam_k = $_POST['jam'][$key];
										$id_pertgl = "$id_user-$id_proyekx-$bln-$thn";

						$result[] = array(
							 "id_user"  		=> $id_user,
							 "no_wbs"  			=> $_POST['no_wbs'][$key],
							 "kode_proyek"  => $_POST['kode_proyek'][$key],
							 "id_proyek"  	=> $_POST['id_proyek'][$key],
							 "aktivitas"    => $_POST['aktivitas'][$key],
							 "Jumlah_jam"	  => $_POST['jam'][$key],
							 "id_pertgl"	  => $id_pertgl,
							 "ket"	  			=> $_POST['ket'][$key],
							 "tgl"	  			=> $tgl,
							 "status"  			=> $st,
							 "mode"	  			=> $mode
						);

						if ($_POST['jam'][$key] >= 0 AND $_POST['jam'][$key] <= 8) {
							$no = 0;
							if ($no == 0) {
								$cek_kd 	= $this->db->get_where('tbl_proyek', "kode_proyek = '$kode_proyekx'")->num_rows();
								if ($cek_kd == 0) {
									$no = 2;
								}else{
										$cek_now  = $this->db->get_where('tbl_pertgl', "id_pertgl = '$id_pertgl'")->num_rows();
										if ($cek_now != 0) { //jika ada
												$data = array(
													'jam_tgl'.$tgl2.''	=> "$jam_k $cs",
												);
												$this->Mcrud->update_pertgl(array('id_pertgl' => $id_pertgl), $data);
										}else{
												$data = array(
													'id_pertgl'			    => $id_pertgl,
													'jam_tgl'.$tgl2.''	=> "$jam_k $cs",
												);
												$this->Mcrud->save_pertgl($data);
										}
								}
							}
						}else{
							$no = 1;
						}

					}

					if ($no == 0) {
							$status = true;
							$simpan = $this->db->insert_batch('tbl_jam_kerja', $result); // fungsi dari codeigniter untuk menyimpan multi array

							if ($simpan){
										$msg = '
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>'
										;
							}else{
									$msg = '
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> disimpan.
										</div>'
									;
							}
					}elseif ($no == 1) {
						$status = false;
						$msg = '
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> Jumlah Jam tidak boleh kurang dari 0 dan lebih dari 8.
							</div>'
						;
					}else{
						$status = false;
						$msg = '
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> Kode Proyek tidak ditemukan.
							</div>'
						;
					}

				}

				echo json_encode(array("status" => $status, "pesan" => $msg));


				// redirect('users/jk');
		}else{
			redirect('web/error_not_found');
		}
	}

	public function jk_manual()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  = $this->Mcrud->get_users_by_un($ceks);
			$id_bagian = $data['user']->row()->id_bagian;
			$data['cek_bagian']  = $this->Mcrud->get_bagian_by_id("$id_bagian");
			$data['users']  = $this->Mcrud->get_users();
			// $data['kat_proyek']	  = $this->Mcrud->get_proyek_by_un($ceks);

			if ($data['user']->row()->level == "admin") {
					$this->load->view('404_content');
			}else{
					$this->load->view('users/header', $data);
					$this->load->view('users/jk_manual', $data);
					$this->load->view('users/footer');

			}

		}
	}


	public function fl()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  = $this->Mcrud->get_users_by_un($ceks);
			$id_bagian = $data['user']->row()->id_bagian;
			$data['cek_bagian']  = $this->Mcrud->get_bagian_by_id("$id_bagian");
			$data['users']  = $this->Mcrud->get_users();
			// $data['kat_proyek']	  = $this->Mcrud->get_proyek_by_un($ceks);

			if ($data['user']->row()->level == "admin") {
					$this->load->view('404_content');
			}else{
					$this->load->view('users/header', $data);
					$this->load->view('users/lembur', $data);
					$this->load->view('users/footer');

			}

		}
	}


	public function cek_tgl_fl()
	{
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if (isset($_POST['tgl'])) {

				$tgl = $_POST['tgl'];

				$cek_tgl = $this->db->get_where('tbl_lembur', array('id_user' => $id_user, 'tgl_lembur' => $tgl))->num_rows();

				if ($cek_tgl == 0) {
					$status = true;
					$msg = '';
				}else{
					$status = false;
					$msg = '
					<div class="alert alert-warning alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
						 </button>
						 <strong>Maaf!</strong> Tanggal "'.$tgl.'" sudah pernah diisi sebelumnya.
					</div>
					';
				}
				echo json_encode(array("status" => $status, "pesan" => $msg));

		}else{
			redirect('web/error_not_found');
		}
	}


	// public function simpan_fl()
	// {
	// 	$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
	// 	$id_user = $this->session->userdata('id_user@Proyek-2017');
	// 	if(!isset($ceks)) {
	// 		redirect('web/login');
	// 	}
	//
	// 	if (isset($_POST['tgl'])) {
	// 			$data['user']  = $this->Mcrud->get_users_by_un($ceks)->row();
	// 			$id_user = $data['user']->id_user;
	// 			$tgl 		= date('d-m-Y', strtotime($this->input->post('tgl')));
	// 			$pilih	= htmlentities(strip_tags($this->input->post('pilih')));
	//
	// 			$tgl2 = substr($tgl,0,2);
	// 			$bln  = substr($tgl,3,2);
	// 			$thn  = substr($tgl,6,4);
	//
	//
	// 			$cek_tgl = $this->db->get_where('tbl_lembur', array('id_user' => $id_user, 'tgl_lembur' => $tgl))->num_rows();
	//
	// 			if ($cek_tgl != 0) {
	// 					$status = false;
	// 					$msg = '
	// 					<div class="alert alert-warning alert-dismissible" role="alert">
	// 						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	// 							 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
	// 						 </button>
	// 						 <strong>Maaf!</strong> Tanggal "'.$tgl.'" sudah pernah diisi sebelumnya.
	// 					</div>
	// 					';
	// 			}else{
	//
	// 				$status = true;
	//
	// 				if ($pilih == 'Ya') {
	// 						$data = array(
	// 							'id_user'			=> $id_user,
	// 							'tgl_lembur'	=> $tgl,
	// 						);
	// 						$this->db->insert('tbl_lembur', $data);
	// 				}
	//
	// 				$msg = '
	// 				<div class="alert alert-success alert-dismissible" role="alert">
	// 					 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	// 						 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
	// 					 </button>
	// 					 <strong>Sukses!</strong> Form Lembur berhasil disimpan.
	// 				</div>
	// 				';
	//
	// 			}
	//
	// 			echo json_encode(array("status" => $status, "pesan" => $msg));
	//
	//
	// 			// redirect('users/jk');
	// 	}else{
	// 		redirect('web/error_not_found');
	// 	}
	// }


	public function simpan_jk_fl()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}

		if (isset($_POST['tgl'])) {
				$data['user']  = $this->Mcrud->get_users_by_un($ceks)->row();
				$id_user = $data['user']->id_user;
				$tgl 		= date('d-m-Y', strtotime($this->input->post('tgl')));
				// $no_wbs	= htmlentities(strip_tags($this->input->post('no_wbs')));
				$ket	 	= $this->input->post('ket');
				$mode  	= htmlentities(strip_tags($this->input->post('mode')));

				$tgl2 = substr($tgl,0,2);
				$bln  = substr($tgl,3,2);
				$thn  = substr($tgl,6,4);


				$cek_tgl = $this->db->get_where('tbl_jam_kerja', array('id_user' => $id_user, 'tgl' => $tgl))->num_rows();

				if ($cek_tgl != 0) {
						$status = false;
						$msg = '
						<div class="alert alert-warning alert-dismissible" role="alert">
							 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
								 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
							 </button>
							 <strong>Maaf!</strong> Tanggal "'.$tgl.'" sudah pernah diisi sebelumnya.
						</div>
						';
				}else{
					// $status = true;
					// $msg = '';
					$tgl_now = date('d-m-Y');
					if ($tgl_now == $tgl) {
							$st = "tepat";
							$cs = "";
					}else{
							$st = "telat";
							$cs = "-t";
					}

					$ip	= $this->input->post('id_proyek');

					$no = 0;
					$result = array();
					foreach($ip AS $key => $val){
						$kode_proyekx = $_POST['kode_proyek'][$key];
						$id_proyekx = $_POST['id_proyek'][$key];
						$jam_k = $_POST['jam'][$key];
										$id_pertgl = "$id_user-$id_proyekx-$bln-$thn";

						$result[] = array(
							 "id_user"  		=> $id_user,
							 "no_wbs"  			=> $_POST['no_wbs'][$key],
							 "kode_proyek"  => $_POST['kode_proyek'][$key],
							 "id_proyek"  	=> $_POST['id_proyek'][$key],
							 "aktivitas"    => $_POST['aktivitas'][$key],
							 "Jumlah_jam"	  => $_POST['jam'][$key],
							 "id_pertgl"	  => $id_pertgl,
							 "ket"	  			=> $_POST['ket'][$key],
							 "tgl"	  			=> $tgl,
							 "status"  			=> $st,
							 "mode"	  			=> $mode
						);

						if ($_POST['jam'][$key] <= 0) {
								$no = 1;
						}else{
							$no = 0;
							if ($no == 0) {
								$cek_kd 	= $this->db->get_where('tbl_proyek', "kode_proyek = '$kode_proyekx'")->num_rows();
								if ($cek_kd == 0) {
									$no = 2;
								}else{
										$cek_now  = $this->db->get_where('tbl_pertgl', "id_pertgl = '$id_pertgl'")->num_rows();
										if ($cek_now != 0) { //jika ada
												$data = array(
													'jam_tgl'.$tgl2.''	=> "$jam_k $cs",
												);
												$this->Mcrud->update_pertgl(array('id_pertgl' => $id_pertgl), $data);
										}else{
												$data = array(
													'id_pertgl'			    => $id_pertgl,
													'jam_tgl'.$tgl2.''	=> "$jam_k $cs",
												);
												$this->Mcrud->save_pertgl($data);
										}

										$data_fl = array(
											'id_user'			=> $id_user,
											'id_proyek'		=> $_POST['id_proyek'][$key],
											'tgl_lembur'	=> $tgl,
										);
										$this->db->insert('tbl_lembur', $data_fl);
								}
							}
						}

					}

					if ($no == 0) {
							$status = true;
							$simpan = $this->db->insert_batch('tbl_jam_kerja', $result); // fungsi dari codeigniter untuk menyimpan multi array

							if ($simpan){
										$msg = '
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>'
										;
							}else{
									$msg = '
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> disimpan.
										</div>'
									;
							}
					}elseif ($no == 1) {
						$status = false;
						$msg = '
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> Jumlah Jam tidak boleh kurang dari 0.
							</div>'
						;
					}else{
						$status = false;
						$msg = '
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> Kode Proyek tidak ditemukan.
							</div>'
						;
					}

				}

				echo json_encode(array("status" => $status, "pesan" => $msg));


				// redirect('users/jk');
		}else{
			redirect('web/error_not_found');
		}
	}


	public function pesan($aksi='', $id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');

		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "user") {
						if ($aksi == '') {
							$this->db->order_by('id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('pengirim' => $id_user, 'ket' => "pesan"))->result();

								$this->load->view('users/header', $data);
								$this->load->view('users/tabel_pesan', $data);
								$this->load->view('users/footer');
						}elseif ($aksi == 'b') {
							$this->db->join('tbl_user', 'tbl_user.id_user=tbl_pesan.pengirim');
							$this->db->order_by('tbl_pesan.id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('tbl_pesan.id_pesan' => "$id", 'tbl_pesan.ket' => "pesan"))->row();

								$this->load->view('users/header', $data);
								$this->load->view('users/buka_pesan', $data);
								$this->load->view('users/footer');
						}elseif ($aksi == 'bls') {
							$this->db->join('tbl_user', 'tbl_user.id_user=tbl_pesan.pengirim');
							$this->db->order_by('tbl_pesan.id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('tbl_pesan.id_pesan' => "$id", 'tbl_pesan.ket' => "pesan"))->row();

								$this->load->view('users/header', $data);
								$this->load->view('users/bls_pesan', $data);
								$this->load->view('users/footer');

								if (isset($_POST['btnkirim'])) {
									date_default_timezone_set('Asia/Jakarta');
									$tgl = date('d-m-Y H:m:s');

									$isi 	= htmlentities(strip_tags($this->input->post('isi')));

										$data = array(
											'pengirim'			=> $id_user,
											'penerima'			=> $data['t_pesan']->pengirim,
											'isi'						=> $isi,
											'id_parent'			=> $id,
											'tgl_pesan'			=> $tgl,
											'ket'						=> 'komentar'
										);
										$this->db->insert('tbl_pesan', $data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Pesan berhasil dikirim.
											</div>'
										);
										redirect('users/pesan');
								}

						}else{
							redirect('users/pesan');
						}
			}else{
					$this->load->view('404_content');
			}
		}
	}

}
