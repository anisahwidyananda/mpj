<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function index()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$cek_user  = $this->Mcrud->get_users_by_un($ceks);
			if ($cek_user->row()->level == "admin") {
					redirect('admin');
			}else{
					redirect('users');
			}
		}
	}


	public function daftar()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(isset($ceks)) {
			$this->load->view('404_content');
		}else{
			$data['bagian']  = $this->Mcrud->get_bagian();
			$this->load->view('web/header');
			$this->load->view('web/daftar', $data);
			$this->load->view('web/footer');


		}
	}

	public function lanjut()
	{
		if (isset($_POST['nrp'])) {
				$nrp 						= htmlentities(strip_tags($this->input->post('nrp')));

				$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_user.id_bagian');
				$cek_nrp = $this->db->get_where('tbl_user', array('nrp' => $nrp));

				date_default_timezone_set('Asia/Jakarta');
				$waktu 	  = date('Y-m-d H:i:s');
				$tgl 			= date('Y-m-d');


				if ($cek_nrp->num_rows() == 0) {
						$msg =
							'
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> NRP "'.$nrp.'" belum terdaftar.
							</div>'
						;

						$status = "gagal";
				}else{

					if ($cek_nrp->row()->status == "terdaftar"){
						$msg =
							'
							<div class="alert alert-info alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp;</span>
								 </button>
								 <strong>Info!</strong> NRP "'.$nrp.'" sudah terdaftar.
							</div>
							';
						$status = "proses";
					}elseif ($cek_nrp->row()->status == "proses") {

						$un		 = $cek_nrp->row()->username;
						$email = $cek_nrp->row()->email;
										$id = md5("$email * $tgl");

						$msg =
							'
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> NRP "'.$nrp.'" belum di aktivasi, <a href="web/verify/'.$id.'/'.$un.'/kirim" class="btn btn-info" id="btnaktivasi">Aktivasi Sekarang</a>.
							</div>
							';
						$status = "proses";
					}else{
						$msg = "";
						$status = $cek_nrp->row();
					}
					// $data['nrp_user'] = $cek_nrp->row();
					//
					// $this->load->view('web/header');
					// $this->load->view('web/daftar', $data);
					// $this->load->view('web/footer');

				}
				echo json_encode(array("status" => $status, "pesan" => $msg));
		}else{
			redirect('web/daftar');
		}
	}

	public function proses_daftar()
	{
	  if (isset($_POST['nrp2'])) {
			// $nama_lengkap 	= htmlentities(strip_tags($this->input->post('nama_lengkap')));
			$nrp 						= htmlentities(strip_tags($this->input->post('nrp2')));
			// $bagian  				= htmlentities(strip_tags($this->input->post('bagian')));
			$email			 		= htmlentities(strip_tags($this->input->post('email')));
			$username			 	= htmlentities(strip_tags($this->input->post('username')));
			$password			 	= htmlentities(strip_tags($this->input->post('password')));
			$password2			= htmlentities(strip_tags($this->input->post('password2')));

			date_default_timezone_set('Asia/Jakarta');
			$tgl_masuk = date('Y-m-d H:m:s');

			if ($password != $password2) {
					$msg2 =
						'
						<div class="alert alert-warning alert-dismissible" role="alert">
							 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
								 <span aria-hidden="true">&times;&nbsp;</span>
							 </button>
							 <strong>Gagal!</strong> Password tidak cocok.
						</div>'
					;

					$status = "gagal";
					// redirect('web/daftar');
			}else{
					$cek_nrp  = $this->Mcrud->get_users_by_nrp($nrp)->row();

					// if ($cek_nrp->nrp != "") {
					//
					// 		$msg2 =
					// 			'
					// 			<div class="alert alert-warning alert-dismissible" role="alert">
					// 				 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
					// 					 <span aria-hidden="true">&times;&nbsp;</span>
					// 				 </button>
					// 				 <strong>Gagal!</strong> NRP "'.$nrp.'" sudah ada.
					// 			</div>'
					// 		;
					//
					// 		$status = "gagal";
					// 		// redirect('web/daftar');
					// }else{
							$cek_un  = $this->Mcrud->get_users_by_un($username)->num_rows();

							if ($cek_un != 0) {

									$msg2=
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> Username "'.$username.'" sudah ada.
										</div>'
									;

									$status = "gagal";
									// redirect('web/daftar');
							}else{

								$cek_mail  = $this->db->get_where('tbl_user', array('email' => $email))->num_rows();

								if ($cek_mail != 0) {

										$msg2=
											'
											<div class="alert alert-warning alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp;</span>
												 </button>
												 <strong>Gagal!</strong> Email "'.$email.'" sudah ada.
											</div>'
										;

										$status = "gagal";
										// redirect('web/daftar');
								}else{

										$this->Mcrud->sent_mail($username,$email,'reg');

										if ($this->email->send()){
												$data = array(
													'email' 				=> $email,
													'username'			=> $username,
													'password'			=> md5($password),
													'status'				=> 'proses',
													'tgl_daftar'		=> $tgl_masuk
												);
												$this->Mcrud->update_user(array('nrp' => $nrp), $data);
												// $this->Mcrud->save_user($data);


												$msg2 =
													'
													<div class="alert alert-success alert-dismissible" role="alert">
														 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
															 <span aria-hidden="true">&times;&nbsp;</span>
														 </button>
														 <strong>Sukses!</strong> User berhasil didaftar, Silahkan cek email Anda untuk aktivasi akun.
													</div>'
												;

												$status = "sukses";
										}else{

												$msg2 =
													'
													<div class="alert alert-success alert-dismissible" role="alert">
														 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
															 <span aria-hidden="true">&times;&nbsp;</span>
														 </button>
														 <strong>Gagal!</strong> Ada kesalahan, silahkan cek koneksi lalu segarkan browser dan coba lagi.
													</div>'
												;

												$status = "gagal";
										}
								}
										// redirect('web/daftar');
							// }
					}

			}

			echo json_encode(array("status" => $status, "pesan2" => $msg2));

		}else{
			redirect('web/daftar');
		}
	}

	public function verify($id='', $un='', $kirim='')
	{
		if ($id == '' or $un == '') {
			redirect('error_not_found');
		}

		date_default_timezone_set('Asia/Jakarta');
		$tgl	 = date('Y-m-d');

			$cek_un = $this->db->get_where('tbl_user', array('username' => $un ));

			if ($cek_un->num_rows() == 0) {
				$this->session->set_flashdata('msg',
					'
					<div class="alert alert-warning alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp;</span>
						 </button>
						 <strong>Gagal!</strong> Data user tidak ditemukan.
					</div>'
				);
				redirect('');
			}

			$email = $cek_un->row()->email;
			$cek_id = md5("$email * $tgl");

		if ($kirim == '') {

			if ($id == $cek_id) {

				$data = array(
					'status'		=> 'terdaftar',
					);
				$this->Mcrud->update_user(array('username' => $un), $data);
				$this->session->set_flashdata('msg',
					'
					<div class="alert alert-success alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp;</span>
						 </button>
						 <strong>Sukses!</strong> Berhasil diaktivasi, Silahkan Login.
					</div>'
				);
			}else{

				$this->session->set_flashdata('msg',
					'
					<div class="alert alert-success alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp;</span>
						 </button>
							<strong>Gagal!</strong> Aktivasi kadaluarsa. <a href="web/verify/'.$cek_id.'/'.$email.'/'.$un.'/kirim" class="btn btn-default"><span class="glyphicon glyphicon-envelope"></span> Kirim Ulang!</a>
					</div>'
				);
			}
		}else{
			$this->Mcrud->sent_mail($un,$email,'reg');

			if ($this->email->send()){

				$this->session->set_flashdata('msg',
					'
					<div class="alert alert-success alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp;</span>
						 </button>
							 <strong>Sukses!</strong> Silahkan cek email Anda untuk Aktivasi akun.
					</div>'
				);
			}else{
				$this->session->set_flashdata('msg',
					'
					<div class="alert alert-warning alert-dismissible" role="alert">
						 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							 <span aria-hidden="true">&times;&nbsp;</span>
						 </button>
							 <strong>Gagal!</strong> Ada kesalahan, silahkan cek koneksi lalu segarkan browser dan coba lagi.
					</div>'
				);
			}

		}

		redirect('web/login');

	}


	public function login()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(isset($ceks)) {
			$this->load->view('404_content');
		}else{
			$this->load->view('web/header');
			$this->load->view('web/login');
			$this->load->view('web/footer');

				if (isset($_POST['btnlogin'])){
						 $username = htmlentities(strip_tags($_POST['username']));
						 $pass	   = htmlentities(strip_tags(md5($_POST['password'])));

						 $query  = $this->Mcrud->get_users_by_un($username);
						 $cek    = $query->result();
						 $cekun  = $cek[0]->username;
						 $jumlah = $query->num_rows();

						 if($jumlah == 0) {
								 $this->session->set_flashdata('msg',
									 '
									 <div class="alert alert-danger alert-dismissible" role="alert">
									 		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;&nbsp;</span>
											</button>
											<strong>Username "'.$username.'"</strong> belum terdaftar.
									 </div>'
								 );
								 redirect('web/login');
						 } else {
										 $row = $query->row();
										 $cekpass = $row->password;
										 if($cekpass <> $pass) {
												$this->session->set_flashdata('msg',
													 '<div class="alert alert-warning alert-dismissible" role="alert">
													 		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
																<span aria-hidden="true">&times;&nbsp;</span>
															</button>
															<strong>Username atau Password Salah!</strong>.
													 </div>'
												);
												redirect('web/login');
										 } else {

																$this->session->set_userdata('Jam_Kerja@Proyek-2017', "$cekun");
																$this->session->set_userdata('id_user@Proyek-2017', "$row->id_user");
																$this->session->set_userdata('nrp@Proyek-2017', "$row->nrp");

																date_default_timezone_set('Asia/Jakarta');
																$tgl = date('Y-m-d H:m:s');
																$data = array(
																	'terakhir_login'		=> $tgl,
																	);
																$this->Mcrud->update_user(array('username' => $username), $data);
												 			 	redirect('web');
										 }
						 }
				}
		}
	}


	public function logout() {
     if ($this->session->has_userdata('Jam_Kerja@Proyek-2017') and $this->session->has_userdata('id_user@Proyek-2017') and $this->session->has_userdata('nrp@Proyek-2017')) {
         $this->session->sess_destroy();
         redirect('');
     }
		 redirect('');
  }


	public function lupa_password()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(isset($ceks)) {
			$this->load->view('404_content');
		}else{
			$this->load->view('web/header');
			$this->load->view('web/lupa_password');
			$this->load->view('web/footer');

			if (isset($_POST['btnkirim'])){
				$email = htmlentities(strip_tags($_POST['email']));

				date_default_timezone_set('Asia/Jakarta');
				$tgl	 = date('Y-m-d');

				$cek_id = md5("$email * $tgl");

				$cek_mail  = $this->db->get_where('tbl_user', array('email' => $email));

				if ($cek_mail->num_rows() == 0) {

						$this->session->set_flashdata('msg',
							'
							<div class="alert alert-warning alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp;</span>
								 </button>
								 <strong>Gagal!</strong> Email "'.$email.'" belum terdaftar.
							</div>'
						);
						redirect('web/lupa_password');
				}else{

						$this->Mcrud->sent_mail($cek_mail->row()->username,$email,'lp');

						if ($this->email->send()){

							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
										 <strong>Sukses!</strong> Cek email untuk membuat password baru.
								</div>'
							);
						}else{
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-warning alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
										 <strong>Gagal!</strong> Ada kesalahan, silahkan cek koneksi lalu segarkan browser dan coba lagi.
								</div>'
							);
						}
						redirect('web/login');

				}

			}

		}
	}

	public function konfirm_pass($id='',$un='') {
		date_default_timezone_set('Asia/Jakarta');
		$tgl	 = date('Y-m-d');

     if ($id != '' or $un != '') {

			 $cek_un  = $this->db->get_where('tbl_user', array('username' => $un));

			 if ($cek_un->num_rows() == 0) {
					 $this->session->set_flashdata('msg',
						'
						<div class="alert alert-warning alert-dismissible" role="alert">
							 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
								 <span aria-hidden="true">&times;&nbsp;</span>
							 </button>
								<strong>Gagal!</strong> Data user tidak ditemukan.</a>
						</div>'
					);
					redirect('web/login');
			 }

			 $email  = $cek_un->row()->email;

			 $cek_id = md5("$email * $tgl");
			 if ($id == $cek_id) {

					 $this->load->view('web/header');
					 $this->load->view('web/reset_pass');
					 $this->load->view('web/footer');

		 				if (isset($_POST['btnkirim'])) {
		 						$pass  			= htmlentities(strip_tags($this->input->post('password')));
								$pass2 			= htmlentities(strip_tags($this->input->post('password2')));

								if ($pass == $pass2) {
										$data = array(
											'password'		=> md5($pass),
											);
										$this->Mcrud->update_user(array('username' => $un), $data);
										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
					 							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					 								<span aria-hidden="true">&times;&nbsp;</span>
					 							</button>
													<strong>Sukses!</strong> Password berhasil diperbarui.
											</div>'
										);
										redirect('web/login');
								}else{
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
				 							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				 								<span aria-hidden="true">&times;&nbsp;</span>
				 							</button>
												<strong>Gagal!</strong> Password Baru dan Ulangi Password Baru tidak cocok, silahkan coba lagi.
										</div>'
									);
								}

								redirect('web/konfirm_pass/'.$id.'/'.$un.'');
						}

			 }else{

				 $this->session->set_flashdata('msg',
					 '
					 <div class="alert alert-warning alert-dismissible" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;&nbsp;</span>
							</button>
							 <strong>Gagal!</strong> Ubah Password baru kadaluarsa.</a>
					 </div>'
				 );
			 }
     }else{
		 	redirect('web/login');
		 }
  }

	function error_not_found(){
		$this->load->view('404_content');
	}

}
