<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['jml_proyek']   = $this->db->get('tbl_proyek')->num_rows();
			$data['jml_jk']       = $this->Mcrud->get_countjk();
			$data['users']  		  = $this->Mcrud->get_users_daftar();
			$data['proyek']			  = $this->db->get('tbl_proyek');
			$data['get_bagian']   = $this->Mcrud->get_bagian();

			if ($data['user']->row()->level == "admin") {
					$this->load->view('admin/header', $data);
					$this->load->view('admin/beranda', $data);
					$this->load->view('admin/footer');
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function profile()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['jml_proyek']   = $this->db->get('tbl_proyek');
			$data['jml_jk']       = $this->Mcrud->get_countjk();
			$data['users']  		  = $this->Mcrud->get_users_daftar();

			if ($data['user']->row()->level == "admin") {
					$this->load->view('admin/header', $data);
					$this->load->view('admin/profile', $data);
					$this->load->view('admin/footer');

					if (isset($_POST['btnupdate'])) {
						$password 	= htmlentities(strip_tags($this->input->post('password')));

									$data = array(
										'password'	=> md5($password)
									);
									$this->Mcrud->update_user(array('username' => $ceks), $data);

									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-success alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
											 </button>
											 <strong>Sukses!</strong> Berhasil disimpan.
										</div>'
									);
									redirect('admin/profile');
					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function lihat_users($aksi='', $id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();

			if ($data['user']->row()->level == "admin") {

					if ($aksi == "t") {
							$this->db->order_by('nama_bagian','ASC');
							$data['bagian']  = $this->db->get('tbl_bagian')->result();
							$data['p_user']  = $this->Mcrud->get_level_users_by_id($id);
							$this->load->view('admin/header', $data);
							$this->load->view('admin/tambah_users', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btnsimpan'])) {
								$nama_lengkap 	= htmlentities(strip_tags($this->input->post('nama_lengkap')));
								$nrp 						= htmlentities(strip_tags($this->input->post('nrp')));
								$bagian  				= htmlentities(strip_tags($this->input->post('bagian')));

								if ($this->db->get_where('tbl_user', array('nrp' => $nrp))->num_rows() != 0) {
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> NRP "'.$nrp.' sudah ada".
										</div>'
									);
									redirect('admin/lihat_users/t');
								}else{
									$data = array(
										'nama_lengkap'	=> $nama_lengkap,
										'nrp' 		  		=> $nrp,
										'id_bagian' 		=> $bagian,
										'level' 				=> 'user'
									);
									$this->Mcrud->save_user($data);
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-success alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Sukses!</strong> User berhasil ditambah.
										</div>'
									);
									redirect('admin/lihat_users');
								}
							}

					}elseif ($aksi == "p") {
							$data['p_user']  = $this->Mcrud->get_level_users_by_id($id);
							if ($data['p_user']->nrp == "") {
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> Data User".
										</div>'
									);
									redirect('admin/lihat_users');
							}

							$this->load->view('admin/header', $data);
							$this->load->view('admin/detail_users', $data);
							$this->load->view('admin/footer');
					}elseif ($aksi == "e") {
							$data['e_user']  = $this->Mcrud->get_level_users_by_id($id);
							if ($data['e_user']->nrp == "") {
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> Data User".
										</div>'
									);
									redirect('admin/lihat_users');
							}

							$data['bagian']  = $this->Mcrud->get_bagian();
							$this->load->view('admin/header', $data);
							$this->load->view('admin/edit_users', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btnver'])) {
										$data = array(
											'status'			=> 'terdaftar'
										);
										$this->Mcrud->update_user(array('id_user' => $id), $data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> User berhasil diverifikasi.
											</div>'
										);
										redirect('admin/lihat_users');
							}

							if (isset($_POST['btnunver'])) {
										$data = array(
											'status'			=> 'proses'
										);
										$this->Mcrud->update_user(array('id_user' => $id), $data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil batalkan verifikasi user.
											</div>'
										);
										redirect('admin/lihat_users');
							}

							if (isset($_POST['btnupdate'])) {
								$nama_lengkap 	= htmlentities(strip_tags($this->input->post('nama_lengkap')));
								$nrp 						= htmlentities(strip_tags($this->input->post('nrp')));
								$bagian  				= htmlentities(strip_tags($this->input->post('bagian')));
								$email			 		= htmlentities(strip_tags($this->input->post('email')));
								$username			 	= htmlentities(strip_tags($this->input->post('username')));
								$password			 	= htmlentities(strip_tags($this->input->post('password')));

								$cek_data = $this->db->get_where('tbl_user', array('nrp' => $nrp))->num_rows();
								if ($cek_data == 0) {
										$cek_nrp = "simpan";
								}else{
									$cek_data_user = $this->db->get_where('tbl_user', array('id_user' => $id));
									if ($cek_data_user->row()->nrp == $nrp) {
										$cek_nrp = "simpan";
									}else{
										$cek_nrp = "";
									}
								}

								if ($cek_nrp == "") {

									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal!</strong> NRP "'.$nrp.' sudah ada".
										</div>'
									);
									redirect('admin/lihat_users/e/'.$id);

								}else{

									date_default_timezone_set('Asia/Jakarta');
									$tgl_masuk = date('Y-m-d H:m:s');

									if ($password == '') {
											$pass = $cek_data_user->row()->password;
									}else{
											$pass = md5($password);
									}

												$data = array(
													'nama_lengkap'	=> $nama_lengkap,
													'nrp' 		  		=> $nrp,
													'id_bagian' 		=> $bagian,
													'email' 				=> $email,
													'username'			=> $username,
													'password'			=> $pass
												);
												$this->Mcrud->update_user(array('id_user' => $id), $data);

												$this->session->set_flashdata('msg',
													'
													<div class="alert alert-success alert-dismissible" role="alert">
														 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
															 <span aria-hidden="true">&times;&nbsp;</span>
														 </button>
														 <strong>Sukses!</strong> User berhasil diupdate.
													</div>'
												);
												redirect('admin/lihat_users');

								}

							}
					}elseif ($aksi == "h") {

							$this->Mcrud->delete_proyek_by_id($id);
							$this->Mcrud->delete_user_by_id($id);
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> User berhasil dihapus.
								</div>'
							);
							redirect('admin/lihat_users');

					}else{
							$this->load->view('admin/header', $data);
							$this->load->view('admin/lihat_users', $data);
							$this->load->view('admin/footer');
					}

			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function ip()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
				$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);

				if ($data['user']->row()->level == "admin") {

							$this->load->view('admin/header', $data);
							$this->load->view('admin/proyek', $data);
							$this->load->view('admin/footer');

									if (isset($_POST['btnsimpan'])) {
											$kp 	= $this->input->post('kode_proyek');

											$result = array();
											foreach($kp AS $key => $val){
												$result[] = array(
													 "kode_proyek"  => $_POST['kode_proyek'][$key],
													 "nama_proyek"  => $_POST['nama_proyek'][$key],
													 "tgl_proyek"   => date('Y-m-d', strtotime($_POST['tgl_proyek'][$key])),
													 "nama_sekolah" => $_POST['nama_sekolah'][$key]
												);
											}

											$simpan = $this->db->insert_batch('tbl_proyek', $result); // fungsi dari codeigniter untuk menyimpan multi array

											if ($simpan){
													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-success alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Sukses!</strong> Proyek berhasil disimpan.
														</div>'
													);
													redirect('admin/t_ip');
											}else{
													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-warning alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Gagal</strong> di simpan.
														</div>'
													);
													redirect('admin/ip');
											}

									}
				}else{
						$this->load->view('404_content');
				}
		}
	}

	public function t_ip($aksi='',$id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
				$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
				$this->db->order_by('id_proyek', 'DESC');
				$data['proyek']  			= $this->db->get('tbl_proyek')->result();

				if ($data['user']->row()->level == "admin") {
						if ($aksi == "t") {
							$data['nama_proyek']  			= $this->db->get_where('tbl_proyek', array('id_proyek' => $id))->row()->nama_proyek;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/proyek_user', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btnsimpan'])) {
									$nrp 	= $this->input->post('nrp');

									$result = array();
									foreach($nrp AS $key => $val){
										if ($_POST['cari'][$key] != "") {
												$result[] = array(
													 "id_proyek"  => $id,
													 "nrp"  			=> $_POST['nrp'][$key]
												);
										}
									}

									$simpan = $this->db->insert_batch('tbl_proyek_user', $result); // fungsi dari codeigniter untuk menyimpan multi array

									if ($simpan){
											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-success alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Sukses!</strong> Proyek User berhasil ditambah.
												</div>'
											);
									}else{
											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-warning alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Gagal</strong> di tambah.
												</div>'
											);
									}
									redirect('admin/t_ip');
							}
						}elseif ($aksi == "e") {
							$data['nama_proyek']  = $this->db->get_where('tbl_proyek', array('id_proyek' => $id))->row()->nama_proyek;
							$data['e_proyek']  		= $this->db->get_where('tbl_proyek_user', array('id_proyek' => $id));

							if ($data['e_proyek']->num_rows() == 0) {
									$this->session->set_flashdata('msg',
										'
										<div class="alert alert-warning alert-dismissible" role="alert">
											 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												 <span aria-hidden="true">&times;&nbsp;</span>
											 </button>
											 <strong>Gagal</strong> User tidak ada.
										</div>'
									);
									redirect('admin/t_ip');
							}

							$this->load->view('admin/header', $data);
							$this->load->view('admin/edit_proyek', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btnupdate'])) {

										$jml_p = $this->db->get_where('tbl_proyek_user', array('id_proyek' => $id))->num_rows();

										for ($i=1; $i <= $jml_p; $i++) {
												$id_p_u = $this->input->post('id_p_u_'.$i.'');
												$nrp 	  = $this->input->post('nrp_'.$i.'');
												$updateData = array(
													'nrp'	=> $nrp
												);
												$this->db->update('tbl_proyek_user', $updateData, array('id_proyek_user' => $id_p_u));
										}


										// $updateData  = array();
										// foreach($nrp AS $key => $val){
										// 	if ($_POST['cari'][$key] != "") {
										// 			$updateData [] = array(
										// 				 "nrp"  		 => $_POST['nrp'][$key]
										// 			);
										// 	}
										// }
											// $update = $this->db->update_batch('tbl_proyek_user', $updateData, array('id_proyek' => '29' ));

											// if ($update){
													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-success alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Sukses!</strong> Proyek User berhasil diupdate.
														</div>'
													);
											// }else{
											// 		$this->session->set_flashdata('msg',
											// 			'
											// 			<div class="alert alert-warning alert-dismissible" role="alert">
											// 				 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											// 					 <span aria-hidden="true">&times;&nbsp;</span>
											// 				 </button>
											// 				 <strong>Gagal</strong> di update.
											// 			</div>'
											// 		);
											// }
											redirect('admin/t_ip');
							}
						}elseif ($aksi == "h") {

								$this->db->delete('tbl_proyek', array('id_proyek' => $id));
								$this->db->delete('tbl_proyek_user', array('id_proyek' => $id));
								$this->session->set_flashdata('msg',
									'
									<div class="alert alert-success alert-dismissible" role="alert">
										 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											 <span aria-hidden="true">&times;&nbsp;</span>
										 </button>
										 <strong>Sukses!</strong> Proyek berhasil dihapus.
									</div>'
								);
								redirect('admin/t_ip');

						}else{
							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_proyek', $data);
							$this->load->view('admin/footer');

						}
				}else{
						$this->load->view('404_content');
				}
		}
	}

	public function cari_nrp()
	{
		// tangkap variabel keyword dari URL
		$keyword = $this->uri->segment(3);

		// cari di database
		$data = $this->db->from('tbl_user')->like('nrp',$keyword)->get();

		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$row->nrp - $row->nama_lengkap",
				'nrp'	=>$row->nrp//,
				// 'nama_lengkap'	=>$row->nama_lengkap

			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}

	public function bagian($aksi='',$id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
				$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
				$data['bagian']   		= $this->Mcrud->get_bagian();

				if ($data['user']->row()->level == "admin") {
						if ($aksi == "e") {
							$data['e_bagian']  = $this->Mcrud->get_bagian_by_id($id);

							$this->load->view('admin/header', $data);
							$this->load->view('admin/edit_bagian', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btnupdate'])) {
									$nama_bagian 	= htmlentities(strip_tags($this->input->post('nama_bagian')));

											$data = array(
												'nama_bagian'	=> $nama_bagian
											);
											$this->Mcrud->update_bagian(array('id_bagian' => $id), $data);

											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-success alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Sukses!</strong> Bagian berhasil diupdate.
												</div>'
											);
											redirect('admin/bagian');
							}
						}elseif ($aksi == "h") {

								$this->Mcrud->delete_bagian_by_id($id);
								$this->session->set_flashdata('msg',
									'
									<div class="alert alert-success alert-dismissible" role="alert">
										 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											 <span aria-hidden="true">&times;&nbsp;</span>
										 </button>
										 <strong>Sukses!</strong> Bagian berhasil dihapus.
									</div>'
								);
								redirect('admin/bagian');

						}else{
							$this->load->view('admin/header', $data);
							$this->load->view('admin/bagian', $data);
							$this->load->view('admin/footer');

									if (isset($_POST['btnsimpan'])) {
													$nb 	= $this->input->post('nama_bagian');

													$result = array();
													foreach($nb AS $key => $val){
														if ($_POST['nama_bagian'][$key] != "") {
															$result[] = array(
																 "nama_bagian"  => $_POST['nama_bagian'][$key]
															);
														}
													}

													$simpan = $this->db->insert_batch('tbl_bagian', $result); // fungsi dari codeigniter untuk menyimpan multi array

													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-success alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Sukses!</strong> Bagian berhasil ditambah.
														</div>'
													);
													redirect('admin/bagian');
									}
						}
				}else{
						$this->load->view('404_content');
				}
		}
	}


	public function aktivitas($aksi='',$id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
				$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
				$data['bagian']   		= $this->Mcrud->get_bagian();

				if ($data['user']->row()->level == "admin") {

					if ($aksi == "t") {
						$data['nama_bagian']  = $this->db->get_where('tbl_bagian', "id_bagian = $id")->row()->nama_bagian;

						$this->load->view('admin/header', $data);
						$this->load->view('admin/tambah_aktivitas', $data);
						$this->load->view('admin/footer');

									if (isset($_POST['btnsimpan'])) {
													$nw 	= $this->input->post('no_wbs');

													$result = array();
													foreach($nw AS $key => $val){
															$result[] = array(
																 "id_bagian" 			 => $id,
																 "no_wbs"  				 => $_POST['no_wbs'][$key],
																 "nama_aktivitas"  => $_POST['nama_aktivitas'][$key]
															);
													}

													$simpan = $this->db->insert_batch('tbl_aktivitas', $result); // fungsi dari codeigniter untuk menyimpan multi array

													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-success alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Sukses!</strong> Aktivitas berhasil ditambah.
														</div>'
													);
													redirect('admin/aktivitas');
									}

					}elseif ($aksi == "e") {
						$data['e_aktivitas']  = $this->db->get_where('tbl_aktivitas', "id_aktivitas = $id")->row();

						$this->load->view('admin/header', $data);
						$this->load->view('admin/edit_aktivitas', $data);
						$this->load->view('admin/footer');

							if (isset($_POST['btnupdate'])) {
									$no_wbs 					= htmlentities(strip_tags($this->input->post('no_wbs')));
									$nama_aktivitas 	= htmlentities(strip_tags($this->input->post('nama_aktivitas')));

											$data = array(
												'no_wbs'					=> $no_wbs,
												'nama_aktivitas'	=> $nama_aktivitas
											);
											$this->db->update('tbl_aktivitas', $data, array('id_aktivitas' => $id));

											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-success alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Sukses!</strong> Aktivitas berhasil diupdate.
												</div>'
											);
											redirect('admin/aktivitas');
							}
					}elseif ($aksi == "h") {

							$this->db->delete('tbl_aktivitas', "id_aktivitas = $id");
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Aktivitas berhasil dihapus.
								</div>'
							);
							redirect('admin/aktivitas');

					}else{

						$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_aktivitas.id_bagian');
						$this->db->order_by('id_aktivitas', 'DESC');
						$data['aktivitas'] = $this->db->get('tbl_aktivitas')->result();

						$this->load->view('admin/header', $data);
						$this->load->view('admin/aktivitas', $data);
						$this->load->view('admin/footer');


					}

				}
		}
	}


	public function keterangan($aksi='',$id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
				$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
				$data['bagian']   		= $this->Mcrud->get_bagian();

				date_default_timezone_set('Asia/Jakarta');
				$tgl = date('d-m-Y');

				if ($data['user']->row()->level == "admin") {

					if ($aksi == "t") {
						$data['nama_bagian']  = $this->db->get_where('tbl_bagian', "id_bagian = $id")->row()->nama_bagian;

						$this->load->view('admin/header', $data);
						$this->load->view('admin/tambah_keterangan', $data);
						$this->load->view('admin/footer');

									if (isset($_POST['btnsimpan'])) {
													$ip 	= $this->input->post('id_proyek');

													$result = array();
													foreach($ip AS $key => $val){
															$result[] = array(
																 "id_bagian" 	=> $id,
																 "id_proyek"  => $_POST['id_proyek'][$key],
																 "tgl_ket"  	=> $tgl
															);
													}

													$simpan = $this->db->insert_batch('tbl_ket', $result); // fungsi dari codeigniter untuk menyimpan multi array

													$this->session->set_flashdata('msg',
														'
														<div class="alert alert-success alert-dismissible" role="alert">
															 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
																 <span aria-hidden="true">&times;&nbsp;</span>
															 </button>
															 <strong>Sukses!</strong> Keterangan berhasil ditambah.
														</div>'
													);
													redirect('admin/keterangan');
									}

					}elseif ($aksi == "e") {
						$this->db->join('tbl_proyek','tbl_proyek.id_proyek=tbl_ket.id_proyek');
						$data['e_ket']  = $this->db->get_where('tbl_ket', "id_ket = $id")->row();

						$this->load->view('admin/header', $data);
						$this->load->view('admin/edit_keterangan', $data);
						$this->load->view('admin/footer');

							if (isset($_POST['btnupdate'])) {
									$id_proyek 					= htmlentities(strip_tags($this->input->post('id_proyek')));

											$data = array(
												'id_proyek'					=> $id_proyek
											);
											$this->db->update('tbl_ket', $data, array('id_ket' => $id));

											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-success alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Sukses!</strong> Keterangan berhasil diupdate.
												</div>'
											);
											redirect('admin/keterangan');
							}
					}elseif ($aksi == "h") {

							$this->db->delete('tbl_ket', "id_ket = $id");
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Keterangan berhasil dihapus.
								</div>'
							);
							redirect('admin/keterangan');

					}else{

						$this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_ket.id_proyek');
						$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_ket.id_bagian');
						$this->db->order_by('id_ket', 'DESC');
						$data['ket'] = $this->db->get('tbl_ket')->result();

						$this->load->view('admin/header', $data);
						$this->load->view('admin/keterangan', $data);
						$this->load->view('admin/footer');


					}

				}
		}
	}


	public function cari_kode_proyek()
	{
		// tangkap variabel keyword dari URL
		// $nrp = $this->uri->segment(3);
		$keyword = $this->uri->segment(3);

		// cari di database
		// $this->db->join('tbl_proyek_user', 'tbl_proyek_user.id_proyek=tbl_proyek.id_proyek');
		// $this->db->where('tbl_proyek_user.nrp', $nrp);
		$data = $this->db->from('tbl_proyek')->like('kode_proyek',$keyword)->get();

		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>"$row->kode_proyek",
				'kode_proyek'	=>$row->kode_proyek,
				'id_proyek'	=>$row->id_proyek,
				'nama_proyek'	=>$row->nama_proyek
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}


	public function ip_user($aksi='', $id='', $pr='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();

			if ($data['user']->row()->level == "admin") {

					if ($aksi == "p") {
							$data['p_user']  			= $this->Mcrud->get_level_users_by_id($id);
							$data['get_proyek']   = $this->Mcrud->get_proyek_by_id($id)->result();
							$data['cek_proyek']   = $this->Mcrud->get_proyek_by_id($id)->num_rows();
							$this->load->view('admin/header', $data);
							$this->load->view('admin/detail_proyek_user', $data);
							$this->load->view('admin/footer');
					}elseif ($aksi == "i") {
							$data['e_user']  = $this->Mcrud->get_level_users_by_id($id);
							$data['bagian']  = $this->Mcrud->get_bagian();
							$data['get_kat_proyek']  = $this->Mcrud->get_kat_proyek();
							$data['get_proyek']   = $this->Mcrud->get_proyek_by_id($id)->result();
							$data['cek_proyek']   = $this->Mcrud->get_proyek_by_id($id)->num_rows();
							$this->load->view('admin/header', $data);
							$this->load->view('admin/edit_proyek_user', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btntambah'])) {
									$id_user 				= htmlentities(strip_tags($this->input->post('id_user')));
									$id_kat_proyek 	= htmlentities(strip_tags($this->input->post('id_kat_proyek')));

									$data = array(
										'id_user'				=> $id_user,
										'id_kat_proyek'	=> $id_kat_proyek
									);
									$this->Mcrud->save_proyek($data);

									redirect('admin/ip_user/i/'.$id.'');
							}


							if (isset($_POST['btnupdate'])) {
								/*
								$nama_lengkap 	= htmlentities(strip_tags($this->input->post('nama_lengkap')));
								$nrp 						= htmlentities(strip_tags($this->input->post('nrp')));
								$bagian  				= htmlentities(strip_tags($this->input->post('bagian')));
								$email			 		= htmlentities(strip_tags($this->input->post('email')));
								$username			 	= htmlentities(strip_tags($this->input->post('username')));

								date_default_timezone_set('Asia/Jakarta');
								$tgl_masuk = date('Y-m-d H:m:s');

											$data = array(
												'nama_lengkap'	=> $nama_lengkap,
												'nrp' 		  		=> $nrp,
												'id_bagian' 		=> $bagian,
												'email' 				=> $email,
												'username'			=> $username
											);
											$this->Mcrud->update_user(array('id_user' => $id), $data);

											*/
											$this->session->set_flashdata('msg',
												'
												<div class="alert alert-success alert-dismissible" role="alert">
													 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
														 <span aria-hidden="true">&times;&nbsp;</span>
													 </button>
													 <strong>Sukses!</strong> User berhasil diupdate.
												</div>'
											);
											redirect('admin/ip_user');
							}
					}elseif ($aksi == "h") {
						$this->Mcrud->delete_proyek_by_id_pr($id, $pr);
						$this->session->set_flashdata('msg',
							'
							<div class="alert alert-success alert-dismissible" role="alert">
								 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
									 <span aria-hidden="true">&times;&nbsp;</span>
								 </button>
								 <strong>Sukses!</strong> User berhasil dihapus.
							</div>'
						);
						redirect('admin/ip_user/i/'.$id.'');
					}else{
							$this->load->view('admin/header', $data);
							$this->load->view('admin/proyek_user', $data);
							$this->load->view('admin/footer');
					}

			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function lihat_jk()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_bagian', 'ASC');
			$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

			if ($data['user']->row()->level == "admin") {

							if (isset($_POST['btncari'])) {
									$t_bagian	= $_POST['bagian'];
									$t_kp			= $_POST['kode_proyek'];
									$t_nrp		= $_POST['nrp'];

									$data['tgl_min']	 			= $_POST['tgl1'];
									$data['tgl_now']	 			= $_POST['tgl2'];

									if ($_POST['tgl1'] == '' or $_POST['tgl2'] == '') {
										$tgl = '';
									}else{
										$tgl = "(tbl_jam_kerja.tgl BETWEEN '$_POST[tgl1]' AND '$_POST[tgl2]')";
									}

									if ($t_bagian == '') {
										$bagian = '';
									}else{
										$bagian = "AND tbl_bagian.nama_bagian='$t_bagian'";
									}

									if ($t_kp == '') {
										$kode_proyek = '';
									}else{
										$kode_proyek = "AND tbl_proyek.kode_proyek='$t_kp'";
									}

									if ($t_nrp == '') {
										$nrp = '';
									}else{
										$nrp = "AND tbl_user.nrp='$t_nrp'";
									}

									$query = $this->db->query("SELECT * FROM tbl_jam_kerja
																							INNER JOIN tbl_proyek ON tbl_proyek.id_proyek=tbl_jam_kerja.id_proyek
																							INNER JOIN tbl_user ON tbl_user.id_user=tbl_jam_kerja.id_user
																							INNER JOIN tbl_bagian ON tbl_bagian.id_bagian=tbl_user.id_bagian
																							WHERE $tgl $bagian $kode_proyek $nrp
																							ORDER BY tbl_jam_kerja.tgl DESC
																						");

							}else{
									$t_bagian	= '';
									$t_kp			= '';
									$t_nrp		= '';

									$this->db->order_by('tgl', 'ASC');
									$this->db->limit(1);
									$data['tgl_min']	 			= $this->db->get('tbl_jam_kerja')->row()->tgl;
									$data['tgl_now']	 			= date('d-m-Y');

									$this->db->join('tbl_proyek','tbl_proyek.id_proyek=tbl_jam_kerja.id_proyek');
									$this->db->join('tbl_user','tbl_user.id_user=tbl_jam_kerja.id_user');
									$this->db->join('tbl_bagian','tbl_bagian.id_bagian=tbl_user.id_bagian');
									$this->db->order_by('tgl', 'DESC');
									$query = $this->db->get('tbl_jam_kerja');
							}
							$data['t_jam_kerja']	 			= $query;

							$data['t_bagian']						= $t_bagian;
							$data['t_kode_proyek']			= $t_kp;
							$data['t_nrp']							= $t_nrp;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/lihat_jk', $data);
							$this->load->view('admin/footer');

			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function export_ljk($tgl1='', $tgl2='', $t_bagian='', $t_kp='', $t_nrp='', $aksi='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_bagian', 'ASC');
			$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

			if ($data['user']->row()->level == "admin") {

									if ($tgl1 == '' or $tgl2 == '') {
										$tgl = '';
									}else{
										$tgl = "(tbl_jam_kerja.tgl BETWEEN '$tgl1' AND '$tgl2')";
									}

									if ($t_bagian == '' or $t_bagian == '-') {
										$bagian = '';
									}else{
										$bagian = "AND tbl_bagian.nama_bagian='$t_bagian'";
									}

									if ($t_kp == '' or $t_kp == '-') {
										$kode_proyek = '';
									}else{
										$kode_proyek = "AND tbl_proyek.kode_proyek='$t_kp'";
									}

									if ($t_nrp == '' or $t_nrp == '-') {
										$nrp = '';
									}else{
										$nrp = "AND tbl_user.nrp='$t_nrp'";
									}

									$query = $this->db->query("SELECT * FROM tbl_jam_kerja
																							INNER JOIN tbl_proyek ON tbl_proyek.id_proyek=tbl_jam_kerja.id_proyek
																							INNER JOIN tbl_user ON tbl_user.id_user=tbl_jam_kerja.id_user
																							INNER JOIN tbl_bagian ON tbl_bagian.id_bagian=tbl_user.id_bagian
																							WHERE $tgl $bagian $kode_proyek $nrp
																							ORDER BY tbl_jam_kerja.tgl DESC
																						");

									$data['t_jam_kerja']	 			= $query;

							if ($aksi != 'lembur') {
								$this->load->view('admin/export_ljk', $data);
							}else{
								$this->load->view('admin/export_ljk_lembur', $data);
							}



			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function lihat_jk_lembur()
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_bagian', 'ASC');
			$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

			if ($data['user']->row()->level == "admin") {

							if (isset($_POST['btncari'])) {
									$t_bagian	= $_POST['bagian'];
									$t_kp			= $_POST['kode_proyek'];
									$t_nrp		= $_POST['nrp'];

									$data['tgl_min']	 			= $_POST['tgl1'];
									$data['tgl_now']	 			= $_POST['tgl2'];

									if ($_POST['tgl1'] == '' or $_POST['tgl2'] == '') {
										$tgl = '';
									}else{
										$tgl = "(tbl_jam_kerja.tgl BETWEEN '$_POST[tgl1]' AND '$_POST[tgl2]')";
									}

									if ($t_bagian == '') {
										$bagian = '';
									}else{
										$bagian = "AND tbl_bagian.nama_bagian='$t_bagian'";
									}

									if ($t_kp == '') {
										$kode_proyek = '';
									}else{
										$kode_proyek = "AND tbl_proyek.kode_proyek='$t_kp'";
									}

									if ($t_nrp == '') {
										$nrp = '';
									}else{
										$nrp = "AND tbl_user.nrp='$t_nrp'";
									}

									$query = $this->db->query("SELECT * FROM tbl_jam_kerja
																							INNER JOIN tbl_proyek ON tbl_proyek.id_proyek=tbl_jam_kerja.id_proyek
																							INNER JOIN tbl_user ON tbl_user.id_user=tbl_jam_kerja.id_user
																							INNER JOIN tbl_bagian ON tbl_bagian.id_bagian=tbl_user.id_bagian
																							WHERE $tgl $bagian $kode_proyek $nrp
																							ORDER BY tbl_jam_kerja.tgl DESC
																						");

							}else{
									$t_bagian	= '';
									$t_kp			= '';
									$t_nrp		= '';

									$this->db->order_by('tgl', 'ASC');
									$this->db->limit(1);
									$data['tgl_min']	 			= $this->db->get('tbl_jam_kerja')->row()->tgl;
									$data['tgl_now']	 			= date('d-m-Y');

									$this->db->join('tbl_proyek','tbl_proyek.id_proyek=tbl_jam_kerja.id_proyek');
									$this->db->join('tbl_user','tbl_user.id_user=tbl_jam_kerja.id_user');
									$this->db->join('tbl_bagian','tbl_bagian.id_bagian=tbl_user.id_bagian');
									$this->db->order_by('tgl', 'DESC');
									$query = $this->db->get('tbl_jam_kerja');
							}
							$data['t_jam_kerja']	 			= $query;

							$data['t_bagian']						= $t_bagian;
							$data['t_kode_proyek']			= $t_kp;
							$data['t_nrp']							= $t_nrp;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/lihat_jk_lembur', $data);
							$this->load->view('admin/footer');

			}else{
					$this->load->view('404_content');
			}

		}
	}



	public function tabel_jk($id='',$blnthn='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_bagian', 'ASC');
			$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $blnthn == "" ) {

							$this->db->order_by('nama_proyek', 'ASC');
							$data['proyek']	  		= $this->db->get('tbl_proyek')->result();

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk', $data);
							$this->load->view('admin/footer');
					}else{
							$data['proyek']	  		= $this->db->get_where('tbl_proyek', "id_proyek = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);

							// $this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
							$id_bagian = '';
							if (isset($_POST['btncek'])) {
								$id_bagian = htmlentities(strip_tags($this->input->post('id_bagian')));
								if ($id_bagian != '') {
									$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_user.id_bagian');
									$this->db->where('tbl_bagian.id_bagian', "$id_bagian");
								}
							}
							$this->db->where('tbl_proyek_user.id_proyek', "$id");
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$data['v_id_bagian']	= $id_bagian;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_detail', $data);
							$this->load->view('admin/footer');

							// if (isset($_POST['btncek'])) {
							// 		$bulan = htmlentities(strip_tags($this->input->post('bulan')));
							// 		$tahun = htmlentities(strip_tags($this->input->post('tahun')));
							// 		$t = "$bulan$tahun";
							// 		redirect('admin/tabel_jk/'.$id.'/'.$t.'');
							// }
					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function tabel_jk_user($id='',$blnthn='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $blnthn == "") {

							$this->db->order_by('nama_lengkap', 'DESC');
							$data['t_user']	  		= $this->db->get('tbl_user')->result();

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_user', $data);
							$this->load->view('admin/footer');
					}else{
							$data['t_user']	  		= $this->db->get_where('tbl_user', "id_user = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);
							$nrp = $data['t_user']->nrp;
							$this->db->join('tbl_proyek_user', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							$this->db->where('tbl_proyek_user.nrp', "$nrp");
							$this->db->order_by('nama_proyek', 'ASC');
							$data['t_proyek']  		= $this->db->get('tbl_proyek');

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_user_detail', $data);
							$this->load->view('admin/footer');

							// if (isset($_POST['btncek'])) {
							// 		$bulan = htmlentities(strip_tags($this->input->post('bulan')));
							// 		$tahun = htmlentities(strip_tags($this->input->post('tahun')));
							// 		$t = "$bulan$tahun";
							// 		redirect('admin/tabel_jk/'.$id.'/'.$t.'');
							// }
					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function tabel_jk_bagian($id='',$blnthn='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_proyek', 'ASC');
			$data['proyek']	  		= $this->db->get('tbl_proyek')->result();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $blnthn == "" ) {

							$this->db->order_by('nama_bagian', 'ASC');
							$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_bagian', $data);
							$this->load->view('admin/footer');
					}else{
							$data['bagian']	  		= $this->db->get_where('tbl_bagian', "id_bagian = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);


								$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
								$this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							$id_proyek = '';
							if (isset($_POST['btncek'])) {
								$id_proyek = htmlentities(strip_tags($this->input->post('id_proyek')));
								if ($id_proyek != '') {
									$this->db->where('tbl_proyek.id_proyek', "$id_proyek");
								}
							}
							$this->db->where('tbl_user.id_bagian', "$id");
							$this->db->order_by('nama_proyek', 'ASC');
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$data['v_id_proyek']	= $id_proyek;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_bagian_detail', $data);
							$this->load->view('admin/footer');

							// if (isset($_POST['btncek'])) {
							// 		$bulan = htmlentities(strip_tags($this->input->post('bulan')));
							// 		$tahun = htmlentities(strip_tags($this->input->post('tahun')));
							// 		$t = "$bulan$tahun";
							// 		redirect('admin/tabel_jk/'.$id.'/'.$t.'');
							// }
					}
			}else{
					$this->load->view('404_content');
			}

		}
	}

	public function tabel_jk_lembur($id='',$blnthn='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$this->db->order_by('nama_proyek', 'ASC');
			$data['proyek']	  		= $this->db->get('tbl_proyek')->result();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $blnthn == "" ) {

							$this->db->order_by('nama_bagian', 'ASC');
							$data['bagian']	  		= $this->db->get('tbl_bagian')->result();

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_lembur', $data);
							$this->load->view('admin/footer');
					}else{
							$data['bagian']	  		= $this->db->get_where('tbl_bagian', "id_bagian = '$id'")->row();

								$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
								$this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							$id_proyek = '';
							if (isset($_POST['btncek'])) {
								$id_proyek = htmlentities(strip_tags($this->input->post('id_proyek')));
								if ($id_proyek != '') {
									$this->db->where('tbl_proyek.id_proyek', "$id_proyek");
								}
							}
							$this->db->where('tbl_user.id_bagian', "$id");
							$this->db->order_by('nama_proyek', 'ASC');
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$data['v_id_proyek']	= $id_proyek;

							$this->load->view('admin/header', $data);
							$this->load->view('admin/tabel_jk_lembur_detail', $data);
							$this->load->view('admin/footer');

					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function grafik($id='',$thn='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{

			if ($id == '' AND $thn == '') {
				$this->load->view('404_content');
			}

			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();
			$data['proyek']			  = $this->db->get('tbl_proyek');
			$data['get_bagian']	  = $this->Mcrud->get_bagian();

			if ($data['user']->row()->level == "admin") {

							$this->load->view('admin/header', $data);
							$this->load->view('admin/grafik', $data);
							$this->load->view('admin/footer');

							if (isset($_POST['btncek'])) {
									$proyek = htmlentities(strip_tags($this->input->post('proyek')));
									$bulan = htmlentities(strip_tags($this->input->post('bulan')));
									$tahun = htmlentities(strip_tags($this->input->post('tahun')));
									$t = "$bulan-$tahun";
									redirect('admin/grafik/'.$proyek.'/'.$t.'');
							}


			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function export_jk($id='', $bln_1='', $bln_2='', $id_bagian='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $bln_1 == "" or $bln_2 == "") {

						redirect('admin/tabel_jk/'.$id.'/'.$bln_1.'');

					}else{
							$data['proyek']	  		= $this->db->get_where('tbl_proyek', "id_proyek = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);
							$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
							if ($id_bagian != '') {
								$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_user.id_bagian');
								$this->db->where('tbl_bagian.id_bagian', "$id_bagian");
							}
							$this->db->where('tbl_proyek_user.id_proyek', "$id");
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$this->load->view('admin/export_jk', $data);

					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function export_jk_user($id='', $bln_1='', $bln_2='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $bln_1 == "" or $bln_2 == "") {

						redirect('admin/tabel_jk_user/'.$id.'/'.$bln_1.'');

					}else{
						$data['t_user']	  		= $this->db->get_where('tbl_user', "id_user = '$id'")->row();
						// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);
						$nrp = $data['t_user']->nrp;
						$this->db->join('tbl_proyek_user', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
						$this->db->where('tbl_proyek_user.nrp', "$nrp");
						$this->db->order_by('nama_proyek', 'ASC');
						$data['t_proyek']  		= $this->db->get('tbl_proyek');

						$this->load->view('admin/export_jk_user', $data);

					}
			}else{
					$this->load->view('404_content');
			}

		}
	}

	public function export_jk_bagian($id='', $bln_1='', $bln_2='', $id_proyek='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $bln_1 == "" or $bln_2 == "") {

						redirect('admin/tabel_jk_bagian/'.$id.'/'.$bln_1.'');

					}else{
							$data['bagian']	  		= $this->db->get_where('tbl_bagian', "id_bagian = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);
							$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
							$this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							if ($id_proyek != '') {
								$this->db->where('tbl_proyek.id_proyek', "$id_proyek");
							}
							$this->db->where('tbl_user.id_bagian', "$id");
							$this->db->order_by('nama_proyek', 'ASC');
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$this->load->view('admin/export_jk_bagian', $data);

					}
			}else{
					$this->load->view('404_content');
			}

		}
	}

	public function export_jk_lembur($id='', $bln_1='', $bln_2='', $id_proyek='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
					if ($id == "" or $bln_1 == "" or $bln_2 == "") {

						redirect('admin/tabel_jk_lembur/'.$id.'/'.$bln_1.'');

					}else{
							$data['bagian']	  		= $this->db->get_where('tbl_bagian', "id_bagian = '$id'")->row();
							// $data['jam_pertgl']	  = $this->Mcrud->get_jam_proyek($id, $blnthn);
							$this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
							$this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
							if ($id_proyek != '') {
								$this->db->where('tbl_proyek.id_proyek', "$id_proyek");
							}
							$this->db->where('tbl_user.id_bagian', "$id");
							$this->db->order_by('nama_proyek', 'ASC');
							$this->db->order_by('nama_lengkap', 'ASC');
							$data['t_user']	 			= $this->db->get('tbl_user');

							$this->load->view('admin/export_jk_lembur', $data);

					}
			}else{
					$this->load->view('404_content');
			}

		}
	}


	public function pesan($aksi='', $id='')
	{
		$ceks = $this->session->userdata('Jam_Kerja@Proyek-2017');
		$id_user = $this->session->userdata('id_user@Proyek-2017');

		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);
			$data['level_users']  = $this->Mcrud->get_level_users();
			$data['users']  		  = $this->Mcrud->get_users();

			if ($data['user']->row()->level == "admin") {
						if ($aksi == '') {
							$this->db->order_by('id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('tbl_pesan.ket' => "pesan"))->result();

								$this->load->view('admin/header', $data);
								$this->load->view('admin/tabel_pesan', $data);
								$this->load->view('admin/footer');
						}elseif ($aksi == 'b') {
							$this->db->join('tbl_user', 'tbl_user.id_user=tbl_pesan.pengirim');
							$this->db->order_by('tbl_pesan.id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('tbl_pesan.id_pesan' => "$id", 'tbl_pesan.ket' => "pesan"))->row();

								$this->load->view('admin/header', $data);
								$this->load->view('admin/buka_pesan', $data);
								$this->load->view('admin/footer');
						}elseif ($aksi == 'bls') {
							$this->db->join('tbl_user', 'tbl_user.id_user=tbl_pesan.pengirim');
							$this->db->order_by('tbl_pesan.id_pesan', 'DESC');
							$data['t_pesan'] = $this->db->get_where('tbl_pesan', array('tbl_pesan.id_pesan' => "$id", 'tbl_pesan.ket' => "pesan"))->row();

								$this->load->view('admin/header', $data);
								$this->load->view('admin/bls_pesan', $data);
								$this->load->view('admin/footer');

								if (isset($_POST['btnkirim'])) {
									date_default_timezone_set('Asia/Jakarta');
									$tgl = date('d-m-Y H:m:s');

									$isi 	= htmlentities(strip_tags($this->input->post('isi')));

										$data = array(
											'pengirim'			=> $id_user,
											'penerima'			=> $data['t_pesan']->pengirim,
											'isi'						=> $isi,
											'id_parent'			=> $id,
											'tgl_pesan'			=> $tgl,
											'ket'						=> 'komentar'
										);
										$this->db->insert('tbl_pesan', $data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Pesan berhasil dikirim.
											</div>'
										);
										redirect('admin/pesan');
								}

						}elseif ($aksi == 'h') {
							$this->db->delete('tbl_pesan', array('id_parent' => $id));
							$this->db->delete('tbl_pesan', array('id_pesan' => $id));
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Pesan berhasil dihapus.
								</div>'
							);
							redirect('admin/pesan');
						}else{
							redirect('admin/pesan');
						}
			}else{
					$this->load->view('404_content');
			}
		}
	}

}
