

					<!-- Footer -->
					<div class="footer text-muted text-center">
						&copy; 2017. <a href="">Aplikasi Login Sistem Pengisian Jam Kerja</a>
					</div>
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>
</html>
