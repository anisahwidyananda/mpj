
<script language="JavaScript" type="text/JavaScript">
          var site = "<?php echo site_url();?>";

          $(function(){
              $('.autocomplete').autocomplete({
                  // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                  serviceUrl: site+'/admin/cari_kode_proyek',
                  // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                  onSelect: function (suggestion) {
                      $('#v_p').val(''+suggestion.nama_proyek); // membuat id 'v_nim' untuk ditampilkan
                      $('#v_id_p').val(''+suggestion.id_proyek);
                      // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                  }
              });


              $('#cari').keyup(function(){
                  if ($('#cari').val() == "") {
                      $('#v_p').val('');
                      $('#v_id_p').val('');
                  }
              });

          });

        counter=0;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data=''+
            '<div class="form-group">'+
            ' <input type="search" name="cari[]" id="cari_'+ counterNumber +'" class="form-control autocomplete_'+ counterNumber +'" value="" placeholder="Ketikkan Kode Proyek ['+ counterNumber +']" required>'+
            ' <input type="text" id="v_p_'+ counterNumber +'" class="form-control" placeholder="Nama Proyek ['+ counterNumber +']" readonly required/>'+
            ' <input type="hidden" id="v_id_p_'+ counterNumber +'" name="id_proyek[]" required/>'+
            '</div>'+
            '<div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;

            $('.autocomplete_'+ counterNumber).autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_kode_proyek',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_p_'+ counterNumber).val(''+suggestion.nama_proyek); // membuat id 'v_nim' untuk ditampilkan
                    $('#v_id_p_'+ counterNumber).val(''+suggestion.id_proyek);
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                }
            });


            $('#cari_'+ counterNumber).keyup(function(){
                if ($('#cari_'+ counterNumber).val() == "") {
                    $('#v_p_'+ counterNumber).val('');
                    $('#v_id_p_'+ counterNumber).val('');
                }
            });
            counter++;
        }
</script>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="col-md-3"></div>

    <div class="col-md-6">

    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Isi Keterangan User</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>

        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
              <label class="control-label col-lg-12"><p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> Form untuk menambahkan keterangan bagian <b><?php echo ucwords($nama_bagian); ?></b></p></label>
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="search" name="cari[]" id="cari" class="form-control autocomplete" value="" placeholder="Ketikkan Kode Proyek" required>
                  <input type="text" id="v_p" class="form-control" placeholder="Nama Proyek" readonly required/>
                  <input type="hidden" id="v_id_p" name="id_proyek[]" required/>
                </div>
                <div id="input0"></div>
                <a href="javascript:action();" class="btn btn-warning">Tambah</a>
                <br>
              </div>

              <div class="col-lg-12">
              <hr>
                <a href="admin/keterangan" class="btn btn-default">Kembali</a>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
              </div>
          </form>
        </div>
      </div>
      <!-- /basic datatable -->
    </div>

    </div>
    <!-- /dashboard content -->
