<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-md-3"></div>
      <div class="panel panel-flat col-md-6">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Edit Aktivitas</legend>

              <form class="form-horizontal" action="" method="post">
                <div class="form-group">
                  <!-- <label class="control-label col-lg-2">Nama Bagian</label> -->
                  <div class="col-lg-12">
                    <input type="text" name="no_wbs" class="form-control" value="<?php echo $e_aktivitas->no_wbs;?>" placeholder="1. Isi No. WBS" required>
                    <input type="text" name="nama_aktivitas" class="form-control" value="<?php echo $e_aktivitas->nama_aktivitas;?>" placeholder="2. Isi Aktivitas" required>
                  </div>
                </div>
                <hr>
                <a href="admin/aktivitas" class="btn btn-default"><< Kembali</a>
                <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Update</button>
              </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->
