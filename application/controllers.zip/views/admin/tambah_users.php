<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <?php
            echo $this->session->flashdata('msg');
            ?>
            <fieldset class="content-group">
              <legend class="text-bold">Tambah User</legend>

              <form class="form-horizontal" action="" method="post">
                <div class="form-group">
                  <label class="control-label col-lg-2">Nama</label>
                  <div class="col-lg-10">
                    <input type="text" name="nama_lengkap" class="form-control" value="" required>
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label col-lg-2">NRP</label>
                  <div class="col-lg-10">
                    <input type="text" name="nrp" class="form-control" value="" required>
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label col-lg-2">Bagian</label>
                  <div class="col-lg-10">
                    <select class="form-control" name="bagian" required>
                      <option value="">-- Pilih Bagian --</option>
                      <?php
                      foreach ($bagian as $baris) {
                      ?>
                          <option value="<?php echo $baris->id_bagian; ?>"><?php echo $baris->nama_bagian; ?></option>
                      <?php
                      } ?>
                    </select>
                  </div>
                </div>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
              </form>

            </fieldset>

            <a href="admin/lihat_users" class="btn btn-default"><< Kembali</a>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
