

<?php
$sub_menu = strtolower($this->uri->segment(2));
if ($sub_menu == "grafik" or $sub_menu == "") {
?>
<script type="text/javascript">
$(function() {
  function onClickHandler(date, obj) {
    /**
     * @date is an array which be included dates(clicked date at first index)
     * @obj is an object which stored calendar interal data.
     * @obj.calendar is an element reference.
     * @obj.storage.activeDates is all toggled data, If you use toggle type calendar.
           * @obj.storage.events is all events associated to this date
     */

    var $calendar = obj.calendar;
    var $box = $calendar.parent().siblings('.box').show();
    var text = 'Anda memilih tanggal ';

    if(date[0] !== null) {
      text += date[0].format('DD MMMM YYYY');
    }

    if(date[0] !== null && date[1] !== null) {
      text += ' ~ ';
    } else if(date[0] === null && date[1] == null) {
      text += 'tidak ada';
    }

    if(date[1] !== null) {
      text += date[1].format('DD MMMM YYYY');
    }

    $box.text(text);
  }

  $('.calendar').pignoseCalendar({
    lang: 'ind',
    select: onClickHandler,
    theme: 'blue' // light, dark, blue
  });
});

</script>

  <script src="assets/js/linechart/highcharts.js"></script>
  <script src="assets/js/linechart/exporting.js"></script>
<?php
} ?>
          <!-- Footer -->
          <div class="footer text-muted">
            &copy; 2017. <a href="">Aplikasi Login Sistem Pengisian Jam Kerja</a>
          </div>
          <!-- /footer -->

        </div>
        <!-- /content area -->

      </div>
      <!-- /main content -->

      </div>
      <!-- /page content -->

  </div>
  <!-- /page container -->

</body>

<!-- Mirrored from demo.interface.club/limitless/layout_2/LTR/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Apr 2017 11:59:08 GMT -->
</html>
