<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Edit Proyek</legend>

              <form class="form-horizontal" action="" method="post">
                <label class="control-label col-lg-12"><p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> <b>Keterangan :</b> Tambahkan User pada Proyek <b><?php echo ucwords($nama_proyek); ?></b></p></label>
                <div class="col-lg-12">
                <?php
                $no=1;
                foreach ($e_proyek->result() as $baris) {
                  $baris2 = $this->db->get_where('tbl_user',array('nrp' => $baris->nrp))->row();
                  ?>

                  <script type='text/javascript'>
                          var site = "<?php echo site_url();?>";
                          $(function(){
                              $('.autocomplete_<?php echo $no; ?>').autocomplete({
                                  // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                                  serviceUrl: site+'/admin/cari_nrp',
                                  // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                                  onSelect: function (suggestion) {
                                      $('#v_nrp_<?php echo $no; ?>').val(''+suggestion.nrp); // membuat id 'v_nim' untuk ditampilkan
                                      // $('#v_id_p_u_<?php echo $no; ?>').val(''+suggestion.id_proyek_user); // membuat id 'v_jurusan' untuk ditampilkan
                                  }
                              });
                          });
                  </script>

                  <div class="form-group">
                    <input type="search" name="cari[]" class="form-control autocomplete_<?php echo $no; ?>" value="<?php echo "$baris2->nrp - $baris2->nama_lengkap"; ?>" placeholder="<?php echo $no; ?>. Ketikkan NRP" required>
                    <input type="hidden" id="v_nrp_<?php echo $no; ?>" name="nrp_<?php echo $no; ?>" value="<?php echo $baris->nrp; ?>"/>
                    <input type="hidden" id="v_id_p_u_<?php echo $no; ?>" name="id_p_u_<?php echo $no; ?>" value="<?php echo $baris->id_proyek_user; ?>"/>
                  </div>
                <?php
                $no++;
                } ?>
              </div>

              <div class="col-lg-12">
              <hr>
                <a href="admin/t_ip" class="btn btn-default">Kembali</a>
                <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Update</button>
              </div>
              </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->
