<?php
$thn  = strtolower($this->uri->segment(4)); ?>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->

    <div class="row">

            <script type="text/javascript">
              var chart1; // globally available
            $(document).ready(function() {
                  chart1 = new Highcharts.Chart({
                     chart: {
                        renderTo: 'grafik',
                        type: 'column'
                     },
                     title: {
                        text: 'Grafik Bagian <?php echo $bagian->nama_bagian; ?> [<?php echo $thn; ?>]'
                     },
                     xAxis: {
                        categories: ['Bulan']
                     },
                     yAxis: {
                        title: {
                           text: ''
                        }
                     },
                          series:
                        [
                        <?php
                        foreach ($total as $baris) {
                          $cek_bln = substr($baris->id_pertgl,-7);
                          $cek_bln = substr($cek_bln,0,2);

                          $cek_total = $baris->jam_tgl01 + $baris->jam_tgl02 + $baris->jam_tgl03 + $baris->jam_tgl04 + $baris->jam_tgl05 +
                                       $baris->jam_tgl06 + $baris->jam_tgl07 + $baris->jam_tgl08 + $baris->jam_tgl09 + $baris->jam_tgl10 +
                                       $baris->jam_tgl11 + $baris->jam_tgl12 + $baris->jam_tgl13 + $baris->jam_tgl14 + $baris->jam_tgl15 +
                                       $baris->jam_tgl16 + $baris->jam_tgl17 + $baris->jam_tgl18 + $baris->jam_tgl19 + $baris->jam_tgl20 +
                                       $baris->jam_tgl21 + $baris->jam_tgl22 + $baris->jam_tgl23 + $baris->jam_tgl24 + $baris->jam_tgl25 +
                                       $baris->jam_tgl26 + $baris->jam_tgl27 + $baris->jam_tgl28 + $baris->jam_tgl29 + $baris->jam_tgl30 +
                                       $baris->jam_tgl31;

                          $i = $cek_bln;
                          $total = $cek_total;
                          //for ($i=1; $i <= 12; $i++) {
                            if ($i == 1) {
                                $bln = "Januari";
                            }elseif ($i == 2) {
                                $bln = "Februari";
                            }elseif ($i == 3) {
                                $bln = "Maret";
                            }elseif ($i == 4) {
                                $bln = "April";
                            }elseif ($i == 5) {
                                $bln = "Mei";
                            }elseif ($i == 6) {
                                $bln = "Juni";
                            }elseif ($i == 7) {
                                $bln = "Juli";
                            }elseif ($i == 8) {
                                $bln = "Agustus";
                            }elseif ($i == 9) {
                                $bln = "September";
                            }elseif ($i == 10) {
                                $bln = "Oktober";
                            }elseif ($i == 11) {
                                $bln = "November";
                            }elseif ($i == 12) {
                                $bln = "Desember";
                            }
                        ?>
                              {
                                  name: '<?php echo $bln; ?>',
                                  data: [<?php echo $total; ?>]
                              },
                        <?php
                          //}
                        }?>

                        ]
                  });
               });
            </script>


      <div class="col-md-12">
            <div class="panel panel-primary">
              <div class="panel-heading"><b>
                <div class="col-md-2"><b>Lihat Grafik Perbagian</b></div>
                <form class="form-horizontal" action="" method="post">
                <div class="col-md-1" style="text-align:right;"><b>Tahun</b></div>
                <div class="col-md-2">
                    <select class="form-control" name="tahun">
                      <?php
                      $max = date('Y');
                      for ($i=2016; $i <= $max; $i++) {
                        if ($i == $thn) {
                          $sel = "selected";
                        }else{
                          $sel = "";
                        }
                      ?>
                        <option value="<?php echo $i; ?>" <?php echo $sel; ?>><?php echo $i; ?></option>
                      <?php
                      } ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="btncek" class="btn btn-default">Cek</button>
                </div>
                </form>

                </b></div>
                <div class="panel-body">
                  <div id ="grafik"></div>
                </div>
            </div>


            <div class="col-md-12">
              <a href="admin/grafik" class="btn btn-default" style="float:right;"><< Kembali</a>
            </div>
      </div>

    </div>
    <!-- /dashboard content -->
