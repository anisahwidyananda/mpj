<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">

              <legend class="text-bold">Filter Menurut:</legend>

              <form action="" method="post">
                <div class="col-lg-12">
                  <div class="col-lg-3">
                    <input type="text" name="bagian" class="form-control" value="<?php echo $t_bagian; ?>" placeholder="Pilih Bagian">
                  </div>
                  <div class="col-lg-2">
                    <input type="text" name="kode_proyek" class="form-control" value="<?php echo $t_kode_proyek; ?>" placeholder="Pilih Kode Proyek">
                  </div>
                  <div class="col-lg-2">
                    <input type="text" name="tgl1" class="form-control daterange-single" value="<?php echo $tgl_min; ?>" placeholder="Pilih Tgl-bulan-tahun">
                  </div>
                  <div class="col-lg-2">
                    <input type="text" name="tgl2" class="form-control daterange-single" value="<?php echo $tgl_now; ?>" placeholder="Pilih Tgl-bulan-tahun">
                  </div>
                  <div class="col-lg-2">
                    <input type="text" name="nrp" class="form-control" value="<?php echo $t_nrp; ?>" placeholder="Pilih NRP">
                  </div>
                  <div class="col-lg-1">
                    <input type="submit" name="btncari" class="btn btn-default" value="Cari" placeholder="Cari">
                  </div>
                </div>
              </form>

              <div class="col-lg-12">
              <div class="form-group">
              <br>
              <div class="table-responsive">

              <table border="1" width="100%">
                <tr style="background-color:#f1f1f1;">
                  <th style="text-align:center;min-width:100px;"><b>Tanggal Input</b></th>
                  <th style="text-align:center;min-width:100px;"><b>Nama</b></th>
                  <th style="text-align:center;min-width:50px;"><b>NRP</b></th>
                  <th style="text-align:center;padding:10px;"><b>Bagian</b></th>
                  <th style="text-align:center;padding:10px;"><b>Kode Proyek</b></th>
                  <th style="text-align:center;padding:10px;"><b>Nama Proyek</b></th>
                  <th style="text-align:center;padding:10px;"><b>Jumlah Jam</b></th>
                  <th style="text-align:center;padding:10px;"><b>No. WBS</b></th>
                  <th style="text-align:center;padding:10px;"><b>Aktivitas</b></th>
                  <th style="text-align:center;padding:10px;"><b>Histori Hari Ini</b></th>
                </tr>
                <?php
                foreach ($t_jam_kerja->result() as $baris) {?>
                  <tr>
                    <td>&nbsp;<?php echo $baris->tgl; ?></td>
                    <td>&nbsp;<?php echo $baris->nama_lengkap; ?></td>
                    <td>&nbsp;<?php echo $baris->nrp; ?></td>
                    <td>&nbsp;<?php echo $baris->nama_bagian; ?></td>
                    <td>&nbsp;<?php echo $baris->kode_proyek; ?></td>
                    <td>&nbsp;<?php echo $baris->nama_proyek; ?></td>
                    <td>&nbsp;<?php echo $baris->jumlah_jam; ?></td>
                    <td>&nbsp;<?php echo $baris->no_wbs; ?></td>
                    <td>&nbsp;<?php echo $baris->aktivitas; ?></td>
                    <td>&nbsp;<?php echo $baris->ket; ?></td>
                  </tr>
                <?php
                }

                if ($t_jam_kerja->num_rows() == 0) {?>
                  <tr>
                    <th colspan="10" style="background-color:pink;text-align:center;">
                      <h2>
                        <?php
                        if (isset($_POST['btncari'])) {
                          echo "Pencarian tidak ditemukan";
                        }else{
                          echo "Data Kosong";
                        } ?>
                      </h2>
                    </th>
                  </tr>
                <?php
                }?>
              </table>

              <?php
              if ($t_bagian == '') {
                  $t_bagian = '-';
              }
              if ($t_kode_proyek == '') {
                  $t_kode_proyek = '-';
              }
              if ($t_nrp == '') {
                  $t_nrp = '-';
              } ?>
              <a href="admin/export_ljk/<?php echo "$tgl_min/$tgl_now/$t_bagian/$t_kode_proyek/$t_nrp"; ?>" class="btn btn-success">Export to Excel</a>
              </div>

            </fieldset>
          </div>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
