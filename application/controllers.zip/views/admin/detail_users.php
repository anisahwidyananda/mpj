<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Detail User</legend>

              <table width="100%">
                  <tr>
                    <td width="100">Nama</td>
                    <td>: <?php echo $p_user->nama_lengkap; ?></td>
                  </tr>
                  <tr>
                    <td width="100">NRP</td>
                    <td>: <?php echo $p_user->nrp; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Bagian</td>
                    <td>: <?php echo $p_user->nama_bagian; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Email</td>
                    <td>: <?php echo $p_user->email; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Username</td>
                    <td>: <?php echo $p_user->username; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Tanggal Daftar</td>
                    <td>: <?php echo $p_user->tgl_daftar; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Terakhir Login</td>
                    <td>: <?php echo $p_user->terakhir_login; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Status</td>
                    <td>:
                      <?php
                          if($p_user->status == "belum"){ ?>
                            <label class='label label-danger label-lg'>Belum Terdaftar</label>
                          <?php
                          }elseif ($p_user->status == "proses") { ?>
                            <label class='label label-warning label-lg'>Proses . . .</label>
                          <?php
                          }else{ ?>
                            <label class='label label-success label-lg'>Terdaftar</label>
                          <?php
                          } ?>
                    </td>
                  </tr>
              </table>
            </fieldset>

            <a href="admin/lihat_users" class="btn btn-default"><< Kembali</a>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
