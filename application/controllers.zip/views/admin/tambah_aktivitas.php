
<script language="JavaScript" type="text/JavaScript">
        counter=2;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data=''+
            '<div class="form-group">'+
            ' <input type="text" name="no_wbs[]" class="form-control" value="" placeholder="1. Isi No. WBS ['+ counterNumber +']" required>'+
            ' <input type="text" name="nama_aktivitas[]" class="form-control" value="" placeholder="2. Isi Aktivitas ['+ counterNumber +']" required>'+
            '</div>'+
            '<div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;
            counter++;
        }
</script>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="col-md-3"></div>

    <div class="col-md-6">

    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Isi Aktivitas User</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>

        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
              <label class="control-label col-lg-12"><p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> <b>Keterangan :</b> Form untuk menambahkan aktivitas bagian <b><?php echo ucwords($nama_bagian); ?></b></p></label>
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="text" name="no_wbs[]" class="form-control" value="" placeholder="1. Isi No. WBS [1]" required>
                  <input type="text" name="nama_aktivitas[]" class="form-control" value="" placeholder="2. Isi Aktivitas [1]" required>
                </div>
                <div class="form-group">
                  <input type="text" name="no_wbs[]" class="form-control" value="" placeholder="1. Isi No. WBS [2]" required>
                  <input type="text" name="nama_aktivitas[]" class="form-control" value="" placeholder="2. Isi Aktivitas [2]" required>
                </div>
                <div class="form-group">
                  <input type="text" name="no_wbs[]" class="form-control" value="" placeholder="1. Isi No. WBS [3]" required>
                  <input type="text" name="nama_aktivitas[]" class="form-control" value="" placeholder="2. Isi Aktivitas [3]" required>
                </div>
                <div id="input2"></div>
                <a href="javascript:action();" class="btn btn-warning">Tambah</a>
                <br>
              </div>

              <div class="col-lg-12">
              <hr>
                <a href="admin/aktivitas" class="btn btn-default">Kembali</a>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
              </div>
          </form>
        </div>
      </div>
      <!-- /basic datatable -->
    </div>

    </div>
    <!-- /dashboard content -->
