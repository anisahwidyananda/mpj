<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Lihat Tabel Jam Kerja Per Proyek</legend>
              <?php
              if ($t_user->nama_lengkap == '') {
                redirect('admin/tabel_jk_user');
              } ?>
              <b><?php echo ucwords($t_user->nama_lengkap); ?>:</b> <br>
              <br>
              <form class="form-horizontal" action="" method="post">
              <div class="form-group">
                <label class="control-label col-lg-1">Pilih Bulan:</label>
                <div class="col-lg-2">
                  <input type="text" name="tgl1" class="form-control daterange-single" value="<?php if (isset($_POST['tgl1'])) { echo $_POST['tgl1'];}else{ echo '01-'.date('m-Y');} ?>" placeholder="Masukkan Tanggal Proyek yang dibuat" required="">
                  <!-- <select class="form-control" name="bulan">
                    <?php
                    $tgl  = strtolower($this->uri->segment(4));
                    $bln  = substr($tgl,0,2);
                    ?>
                      <option value="01" <?php if ($bln == "01") { echo "selected"; } ?>>Januari</option>
                      <option value="02" <?php if ($bln == "02") { echo "selected"; } ?>>Februari</option>
                      <option value="03" <?php if ($bln == "03") { echo "selected"; } ?>>Maret</option>
                      <option value="04" <?php if ($bln == "04") { echo "selected"; } ?>>April</option>
                      <option value="05" <?php if ($bln == "05") { echo "selected"; } ?>>Mei</option>
                      <option value="06" <?php if ($bln == "06") { echo "selected"; } ?>>Juni</option>
                      <option value="07" <?php if ($bln == "07") { echo "selected"; } ?>>Juli</option>
                      <option value="08" <?php if ($bln == "08") { echo "selected"; } ?>>Agustus</option>
                      <option value="09" <?php if ($bln == "09") { echo "selected"; } ?>>September</option>
                      <option value="10" <?php if ($bln == 10) { echo "selected"; } ?>>Oktober</option>
                      <option value="11" <?php if ($bln == 11) { echo "selected"; } ?>>November</option>
                      <option value="12" <?php if ($bln == 12) { echo "selected"; } ?>>Desember</option>
                  </select> -->
                </div>
                <label class="control-label col-lg-1" style="margin-right:-46px;">s/d</label>
                <div class="col-lg-2">
                  <input type="text" name="tgl2" class="form-control daterange-single" value="<?php if (isset($_POST['tgl2'])) { echo $_POST['tgl2'];} ?>" placeholder="Masukkan Tanggal Proyek yang dibuat" required="">
                  <!-- <select class="form-control" name="tahun">
                    <?php
                    $max = date('Y');
                    $tgl  = strtolower($this->uri->segment(4));
                    $thn  = substr($tgl,2,6);
                    for ($i=2016; $i <= $max; $i++) {
                      if ($i == $thn) {
                        $sel = "selected";
                      }else{
                        $sel = "";
                      }
                    ?>
                      <option value="<?php echo $i; ?>" <?php echo $sel; ?>><?php echo $i; ?></option>
                    <?php
                    } ?>
                  </select> -->
                </div>
                <button type="submit" name="btncek" class="btn btn-default">Cek</button>
              </div>
              </form>
              <br>
              <div class="table-responsive">
                <?php

                if (isset($_POST['btncek'])) {
                    $tgl1 = htmlentities(strip_tags($this->input->post('tgl1')));
                    $tgl2 = htmlentities(strip_tags($this->input->post('tgl2')));
                }else{
                    $tgl1 = '01-'.date('m-Y');
                    $tgl2 = date('d-m-Y');
                }

                $tgl_1 = substr($tgl1,0,2);
                $bln_1 = substr($tgl1,3,7);
                // $thn_1 = substr($tgl1,8,12);

                $tgl_2 = substr($tgl2,0,2);
                $bln_2 = substr($tgl2,3,7);
                // $thn_2 = substr($tgl2,6,10);

                 ?>
              <table border="1" width="100%">
                <tr style="background-color:#f1f1f1;">
                  <!--<th rowspan="2" style="text-align:center;width:30px;"><b>No.</b></th>-->
                  <th rowspan="2" style="text-align:center;min-width:100px;"><b>Proyek</b></th>
                  <th colspan="<?= $tgl_2; ?>" style="text-align:center;padding:10px;"><b>Jam Kerja Per tanggal (Jam)</b></th>
                  <th rowspan="2" style="text-align:center;padding:10px;"><b>TOTAL</b></th>
                </tr>
                <tr style="background-color:#f1f1f1;">
                  <?php
                  for ($i=$tgl_1; $i <= $tgl_2; $i++) {
                    if ($i < 10) {
                      if ($tgl_1 != $i) {
                        $i = '0'.$i;
                      }
                    }
                  ?>
                   <th style="text-align:center;"><b><?php echo $i; ?></b></th>
                  <?php
                  } ?>
                </tr>
                <?php
                error_reporting(0);
                $no = 1;
                $total_perproyek = 0;
                $total = 0;
                $u = 0;

                $id     = strtolower($this->uri->segment(3));
                // $blnthn = strtolower($this->uri->segment(4));
                //
                // $bln = substr($blnthn,0,2);
                // $thn = substr($blnthn,2,6);

                foreach ($t_proyek->result() as $row) {

                  $id_p   = $row->id_proyek;

                  $bln_thn = "$id-$id_p-$bln_2";

                    $baris = $this->db->query("SELECT * FROM tbl_pertgl
                                                INNER JOIN tbl_jam_kerja ON tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl
                                                WHERE tbl_pertgl.id_pertgl='$bln_thn'")->row();


                ?>
                  <tr style="text-align:center;">
                    <td style="text-align:left;">&nbsp; <?php echo ucwords($row->nama_proyek);?></td>
                    <?php
                    for ($i=$tgl_1; $i <= $tgl_2; $i++) {
                      if ($i < 10) {
                        if ($tgl_1 != $i) {
                          $i = '0'.$i;
                        }
                      }
                      $u = "jam_tgl$i";

                        $total_perproyek = substr($baris->$u, 0,2) + $total_perproyek;
                        $total = substr($baris->$u, 0,2) + $total;
                      ?>
                        <td style="<?php if (strlen($baris->$u) > 2) { echo "background-color:red;color:white;";} ?>"><?php if ($baris->$u == null) { echo "-"; }else{echo substr($baris->$u, 0,2) ;} ?></td>
                    <?php
                    }
                    ?>
                    <td><b><?php echo $total_perproyek; ?></b></td>
                  </tr>
                <?php
                    $total_perproyek = 0;
                    $total = $total;
                } ?>
                  <tr>
                    <td style="text-align:center;"><b>TOTAL</b></td>
                    <?php
                    $sum   = 0;

                              for ($j=$tgl_1; $j <= $tgl_2; $j++) {
                                if ($j < 10) {
                                  if ($tgl_1 != $j) {
                                    $j = '0'.$j;
                                  }
                                }
                                $this->db->select_sum("tbl_pertgl.jam_tgl$j");
                              }
                              //  $this->db->join('tbl_jam_kerja', 'tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl');
                              //  $this->db->where('tbl_jam_kerja.id_user', "$id");
                               $this->db->like('tbl_pertgl.id_pertgl', "$id", 'after');
                               $this->db->like('tbl_pertgl.id_pertgl', "$bln_2", 'before');
                      $baris2 = $this->db->get('tbl_pertgl')->row();



                      for ($i=$tgl_1; $i <= $tgl_2; $i++) {
                        if ($i < 10) {
                          if ($tgl_1 != $i) {
                            $i = '0'.$i;
                          }
                        }
                        $u = "jam_tgl$i";

                      ?>
                      <td style="text-align:center;<?php if (strlen($baris2->$u) > 2) { echo "background-color:red;color:white;";} ?>"><?php if ($baris2->$u == null) { echo "-"; }else{echo substr($baris2->$u, 0,2) ;} ?></td>
                      <?php

                        // $total = substr($baris->$u, 0,2) + $total;
                      } ?>
                    <td style="text-align:center;"><b><?php echo $total; ?></b></td>
                  </tr>
              </table>

              <a href="admin/export_jk_user/<?php echo "$id/$tgl1/$tgl2";?>" class="btn btn-success">Export to Excel</a>
              </div>

            </fieldset>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
