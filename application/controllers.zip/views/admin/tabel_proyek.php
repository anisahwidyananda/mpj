
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->

    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Tabel Proyek</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

          <?php
          echo $this->session->flashdata('msg');
          ?>

        </div>
        <hr style="margin:0px;">
          <div class="panel-body">
            <table class="table datatable-basic" width="100%">
              <thead>
                <tr>
                  <th width="30px;">No.</th>
                  <th>Kode Proyek</th>
                  <th>Nama Proyek</th>
                  <th>Tanggal dibuat</th>
                  <th>Nama Sekolah</th>
                  <th>Total User</th>
                  <th class="text-center" width="26%"></th>
                </tr>
              </thead>
              <tbody>
                  <?php
                  $no = 1;
                  foreach ($proyek as $baris) {
                    $total_user = $this->db->get_where('tbl_proyek_user', array('id_proyek' => $baris->id_proyek))->num_rows();
                  ?>
                    <tr>
                      <td><?php echo $no.'.'; ?></td>
                      <td><?php echo $baris->kode_proyek; ?></td>
                      <td><?php echo $baris->nama_proyek; ?></td>
                      <td><?php echo date('d-m-Y', strtotime($baris->tgl_proyek)); ?></td>
                      <td><?php echo $baris->nama_sekolah; ?></td>
                      <td><?php echo $total_user; ?></td>
                      <td>
                        <a href="admin/t_ip/t/<?php echo $baris->id_proyek; ?>" class="btn btn-info">Tambah User</a>
                        <a href="admin/t_ip/e/<?php echo $baris->id_proyek; ?>" class="btn btn-success">Edit</a>
                        <a href="admin/t_ip/h/<?php echo $baris->id_proyek; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                      </td>
                    </tr>
                  <?php
                  $no++;
                  } ?>
              </tbody>
            </table>

            <hr>

            <a href="admin/ip" class="btn btn-default">Tambah Proyek</a>

          </div>

      </div>
    </div>
