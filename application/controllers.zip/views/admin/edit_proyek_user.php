<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Edit User</legend>

            <form class="form-horizontal" action="" method="post">
              <div class="form-group">
                <label class="control-label col-lg-2">Nama</label>
                <div class="col-lg-10">
                  <input type="text" name="nama_lengkap" class="form-control" value="<?php echo $e_user->nama_lengkap; ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">NRP</label>
                <div class="col-lg-10">
                  <input type="text" name="nrp" class="form-control" value="<?php echo $e_user->nrp; ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Bagian</label>
                <div class="col-lg-10">
                  <input type="text" name="bagian" class="form-control" value="<?php echo $e_user->nama_bagian; ?>" readonly>
                  <!--
                  <select class="form-control" name="bagian" readonly>
                    <?php
                    foreach ($bagian as $baris) {
                        if ($baris->id_bagian == $e_user->id_bagian) {
                          $aktif = "select";
                        }else{
                          $aktif = "";
                        }
                    ?>
                        <option value="<?php echo $baris->id_bagian; ?>" selected="<?php echo $aktif; ?>"><?php echo $baris->nama_bagian; ?></option>
                    <?php
                    } ?>
                  </select>
                -->
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Isi Proyek</label>
                <div class="col-lg-10">
                  <?php
                  if ($cek_proyek == 0) {
                    echo "-";
                  }else{
                    foreach ($get_proyek as $baris) {
                        echo '- '.$baris->nama_proyek.' <a href="admin/ip_user/h/'.$e_user->id_user.'/'.$baris->id_kat_proyek.'" title="Hapus">x</a> <br>';
                    }
                  }?>

                </div>
              </div>

              <br>
              <hr>
              <a href="admin/ip_user" class="btn btn-default"><< Kembali</a>
              <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Simpan</button>
              <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#tproyek" style="float:right;margin-right:10px;">
                Tambah Proyek
              </button>
            </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->


<div class="modal fade" id="tproyek" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="" method="post">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah Proyek User</h4>
      </div>
      <hr>
      <div class="modal-body">
        <input type="hidden" name="id_user" value="<?php echo $e_user->id_user; ?>">
        <div class="form-group">
          <label class="control-label col-lg-3">Nama Proyek</label>
          <div class="col-lg-9">
            <select class="form-control" name="id_kat_proyek">
              <option value="">-- Pilih Proyek --</option>
              <?php
              foreach ($get_kat_proyek as $baris) {?>
                  <option value="<?php echo $baris->id_kat_proyek; ?>"><?php echo $baris->nama_proyek; ?></option>
              <?php
              } ?>
            </select>
          </div>
        </div>
      </div>
      <hr>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary" name="btntambah">Tambah</button>
      </div>
      </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
