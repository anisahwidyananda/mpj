<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=export_jk_lembur.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Export Jam Kerja Lembur</title>
  </head>
  <body>

    <?php
    $tgl1 = strtolower($this->uri->segment(4));
    $tgl2 = strtolower($this->uri->segment(5));
    $tgl_1 = substr($tgl1,0,2);
    $bln_1 = substr($tgl1,3,7);
    // $thn_1 = substr($tgl1,8,12);

    $tgl_2 = substr($tgl2,0,2);
    $bln_2 = substr($tgl2,3,7);
    // $thn_2 = substr($tgl2,6,10);
     ?>

     <table border="1" width="100%">
       <tr style="background-color:#f1f1f1;">
         <!--<th rowspan="2" style="text-align:center;width:30px;"><b>No.</b></th>-->
         <th rowspan="2" style="text-align:center;min-width:100px;"><b>Kode Proyek</b></th>
         <th rowspan="2" style="text-align:center;min-width:100px;"><b>Nama Proyek</b></th>
         <th rowspan="2" style="text-align:center;min-width:100px;"><b>Nama</b></th>
         <th rowspan="2" style="text-align:center;min-width:10px;"><b>NRP</b></th>
         <th colspan="<?= $tgl_2; ?>" style="text-align:center;padding:10px;"><b>Jam Kerja Per tanggal (Jam)</b></th>
         <th rowspan="2" style="text-align:center;padding:10px;"><b>TOTAL</b></th>
       </tr>
       <tr style="background-color:#f1f1f1;">
         <?php
         for ($i=$tgl_1; $i <= $tgl_2; $i++) {
           if ($i < 10) {
             if ($tgl_1 != $i) {
               $i = '0'.$i;
             }
           }
         ?>
          <th style="text-align:center;"><b><?php echo $i; ?></b></th>
         <?php
         } ?>
       </tr>
       <?php
       error_reporting(0);
       $no = 0;
       $total_perproyek = 0;
       $total = 0;
       $u = 0;
       $total_jam01 = 0;
       $total_jam02 = 0;
       $total_jam03 = 0;
       $total_jam04 = 0;
       $total_jam05 = 0;
       $total_jam06 = 0;
       $total_jam07 = 0;
       $total_jam08 = 0;
       $total_jam09 = 0;
       $total_jam10 = 0;

       $total_jam11 = 0;
       $total_jam12 = 0;
       $total_jam13 = 0;
       $total_jam14 = 0;
       $total_jam15 = 0;
       $total_jam16 = 0;
       $total_jam17 = 0;
       $total_jam18 = 0;
       $total_jam19 = 0;
       $total_jam20 = 0;

       $total_jam21 = 0;
       $total_jam22 = 0;
       $total_jam23 = 0;
       $total_jam24 = 0;
       $total_jam25 = 0;
       $total_jam26 = 0;
       $total_jam27 = 0;
       $total_jam28 = 0;
       $total_jam29 = 0;
       $total_jam30 = 0;

       $total_jam31 = 0;

       foreach ($t_user->result() as $row) {
         $no ++;
         $id_u   = $row->id_user;
         $id_p   = $row->id_proyek;
         $id     = strtolower($this->uri->segment(3));

           $baris = $this->db->query("SELECT * FROM tbl_pertgl
                                       INNER JOIN tbl_jam_kerja ON tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl
                                       WHERE tbl_pertgl.id_pertgl='$id_u-$id_p-$bln_2'")->row();

                                       // tbl_user.id_bagian='$id' AND tbl_proyek.id_proyek='$id_p' AND
                                       // INNER JOIN tbl_user ON tbl_user.id_user=tbl_jam_kerja.id_user
                                       // INNER JOIN tbl_proyek_user ON tbl_proyek_user.nrp=tbl_user.nrp
                                       // INNER JOIN tbl_proyek ON tbl_proyek.id_proyek=tbl_proyek_user.id_proyek

           $this->db->join('tbl_proyek_user', 'tbl_proyek_user.nrp=tbl_user.nrp');
           $this->db->join('tbl_proyek', 'tbl_proyek.id_proyek=tbl_proyek_user.id_proyek');
           $this->db->where('tbl_user.id_bagian', "$id");
           $this->db->where('tbl_proyek.id_proyek', "$id_p");
           $baris2 = $this->db->get('tbl_user');
           $jml_baris2 = $baris2->num_rows();


           if ($baris2->row()->id_user != $id_u) {
             $no = 1;
             $total = 0;

             $total_jam01 = 0;
             $total_jam02 = 0;
             $total_jam03 = 0;
             $total_jam04 = 0;
             $total_jam05 = 0;
             $total_jam06 = 0;
             $total_jam07 = 0;
             $total_jam08 = 0;
             $total_jam09 = 0;
             $total_jam10 = 0;

             $total_jam11 = 0;
             $total_jam12 = 0;
             $total_jam13 = 0;
             $total_jam14 = 0;
             $total_jam15 = 0;
             $total_jam16 = 0;
             $total_jam17 = 0;
             $total_jam18 = 0;
             $total_jam19 = 0;
             $total_jam20 = 0;

             $total_jam21 = 0;
             $total_jam22 = 0;
             $total_jam23 = 0;
             $total_jam24 = 0;
             $total_jam25 = 0;
             $total_jam26 = 0;
             $total_jam27 = 0;
             $total_jam28 = 0;
             $total_jam29 = 0;
             $total_jam30 = 0;

             $total_jam31 = 0;
           }
       ?>
         <tr style="text-align:center;">
           <td style="text-align:left;">&nbsp; <?php if ($no == 1) { echo strtoupper($row->kode_proyek);}?></td>
           <td style="text-align:left;">&nbsp; <?php if ($no == 1) { echo strtoupper($row->nama_proyek);}?></td>
           <td style="text-align:left;">&nbsp; <?php echo ucwords($row->nama_lengkap);?></td>
           <td style="text-align:left;">&nbsp; <?php echo $row->nrp;?></td>
           <?php
           for ($i=$tgl_1; $i <= $tgl_2 ; $i++) {
             if ($i < 10) {
               if ($tgl_1 != $i) {
                 $i = '0'.$i;
               }
             }
             $u = "jam_tgl$i";

               $jml_lembur = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "$i-$bln_2"))->num_rows();

               if ($jml_lembur != 0) {
                 $total_perproyek = substr($baris->$u, 0,2) + $total_perproyek;
                 $total = substr($baris->$u, 0,2) + $total;
               }


             ?>
               <td style="<?php if (strlen($baris->$u) > 2 AND $jml_lembur != 0) { /*echo "background-color:red;color:white;";*/} ?>"><?php if ($baris->$u == null or $jml_lembur == 0) { echo "-"; }else{echo substr($baris->$u, 0,2) ;} ?></td>
           <?php
           } ?>
               <td><b><?php echo $total_perproyek; ?></b></td>
         </tr>
       <?php
       $total_perproyek = 0;

       $jml_lembur01 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "01-$bln_2"))->num_rows();
         if($jml_lembur01 != 0){ $total_jam01 = substr($baris->jam_tgl01, 0,2) + $total_jam01;}

       $jml_lembur02 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "02-$bln_2"))->num_rows();
         if($jml_lembur02 != 0 ){ $total_jam02 = substr($baris->jam_tgl02, 0,2) + $total_jam02;}

       $jml_lembur03 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "03-$bln_2"))->num_rows();
         if($jml_lembur03 != 0 ){ $total_jam03 = substr($baris->jam_tgl03, 0,2) + $total_jam03;}

       $jml_lembur04 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "04-$bln_2"))->num_rows();
         if($jml_lembur04 != 0 ){ $total_jam04 = substr($baris->jam_tgl04, 0,2) + $total_jam04;}

       $jml_lembur05 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "05-$bln_2"))->num_rows();
         if($jml_lembur05 != 0 ){ $total_jam05 = substr($baris->jam_tgl05, 0,2) + $total_jam05;}

       $jml_lembur06 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "06-$bln_2"))->num_rows();
         if($jml_lembur06 != 0 ){ $total_jam06 = substr($baris->jam_tgl06, 0,2) + $total_jam06;}

       $jml_lembur07 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "07-$bln_2"))->num_rows();
         if($jml_lembur07 != 0 ){ $total_jam07 = substr($baris->jam_tgl07, 0,2) + $total_jam07;}

       $jml_lembur08 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "08-$bln_2"))->num_rows();
         if($jml_lembur08 != 0 ){ $total_jam08 = substr($baris->jam_tgl08, 0,2) + $total_jam08;}

       $jml_lembur09 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "09-$bln_2"))->num_rows();
         if($jml_lembur09 != 0 ){ $total_jam09 = substr($baris->jam_tgl09, 0,2) + $total_jam09;}

       $jml_lembur10 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "10-$bln_2"))->num_rows();
         if($jml_lembur10 != 0 ){ $total_jam10 = substr($baris->jam_tgl10, 0,2) + $total_jam10;}

       $jml_lembur11 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "11-$bln_2"))->num_rows();
         if($jml_lembur11 != 0 ){ $total_jam11 = substr($baris->jam_tgl11, 0,2) + $total_jam11;}

       $jml_lembur12 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "12-$bln_2"))->num_rows();
         if($jml_lembur12 != 0 ){ $total_jam12 = substr($baris->jam_tgl12, 0,2) + $total_jam12;}

       $jml_lembur13 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "13-$bln_2"))->num_rows();
         if($jml_lembur13 != 0 ){ $total_jam13 = substr($baris->jam_tgl13, 0,2) + $total_jam13;}

       $jml_lembur14 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "14-$bln_2"))->num_rows();
         if($jml_lembur14 != 0 ){ $total_jam14 = substr($baris->jam_tgl14, 0,2) + $total_jam14;}

       $jml_lembur15 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "15-$bln_2"))->num_rows();
         if($jml_lembur15 != 0 ){ $total_jam15 = substr($baris->jam_tgl15, 0,2) + $total_jam15;}

       $jml_lembur16 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "16-$bln_2"))->num_rows();
         if($jml_lembur16 != 0 ){ $total_jam16 = substr($baris->jam_tgl16, 0,2) + $total_jam16;}

       $jml_lembur17 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "17-$bln_2"))->num_rows();
         if($jml_lembur17 != 0 ){ $total_jam17 = substr($baris->jam_tgl17, 0,2) + $total_jam17;}

       $jml_lembur18 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "18-$bln_2"))->num_rows();
         if($jml_lembur18 != 0 ){ $total_jam18 = substr($baris->jam_tgl18, 0,2) + $total_jam18;}

       $jml_lembur19 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "19-$bln_2"))->num_rows();
         if($jml_lembur19 != 0 ){ $total_jam19 = substr($baris->jam_tgl19, 0,2) + $total_jam19;}

       $jml_lembur20 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "20-$bln_2"))->num_rows();
         if($jml_lembur20 != 0 ){ $total_jam20 = substr($baris->jam_tgl20, 0,2) + $total_jam20;}

       $jml_lembur21 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "21-$bln_2"))->num_rows();
         if($jml_lembur21 != 0 ){ $total_jam21 = substr($baris->jam_tgl21, 0,2) + $total_jam21;}

       $jml_lembur22 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "22-$bln_2"))->num_rows();
         if($jml_lembur22 != 0 ){ $total_jam22 = substr($baris->jam_tgl22, 0,2) + $total_jam22;}

       $jml_lembur23 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "23-$bln_2"))->num_rows();
         if($jml_lembur23 != 0 ){ $total_jam23 = substr($baris->jam_tgl23, 0,2) + $total_jam23;}

       $jml_lembur24 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "24-$bln_2"))->num_rows();
         if($jml_lembur24 != 0 ){ $total_jam24 = substr($baris->jam_tgl24, 0,2) + $total_jam24;}

       $jml_lembur25 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "25-$bln_2"))->num_rows();
         if($jml_lembur25 != 0 ){ $total_jam25 = substr($baris->jam_tgl25, 0,2) + $total_jam25;}

       $jml_lembur26 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "26-$bln_2"))->num_rows();
         if($jml_lembur26 != 0 ){ $total_jam26 = substr($baris->jam_tgl26, 0,2) + $total_jam26;}

       $jml_lembur27 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "27-$bln_2"))->num_rows();
         if($jml_lembur27 != 0 ){ $total_jam27 = substr($baris->jam_tgl27, 0,2) + $total_jam27;}

       $jml_lembur28 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "28-$bln_2"))->num_rows();
         if($jml_lembur28 != 0 ){ $total_jam28 = substr($baris->jam_tgl28, 0,2) + $total_jam28;}

       $jml_lembur29 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "29-$bln_2"))->num_rows();
         if($jml_lembur29 != 0 ){ $total_jam29 = substr($baris->jam_tgl29, 0,2) + $total_jam29;}

       $jml_lembur30 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "30-$bln_2"))->num_rows();
         if($jml_lembur30 != 0 ){ $total_jam30 = substr($baris->jam_tgl30, 0,2) + $total_jam30;}

       $jml_lembur31 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "31-$bln_2"))->num_rows();
         if($jml_lembur31 != 0 ){ $total_jam31 = substr($baris->jam_tgl31, 0,2) + $total_jam31;}


       if ($no == $jml_baris2) {


       // $total_perproyek = 0;
       $total = $total;
        ?>
       <tr style="text-align:center;">
         <td></td>
         <td></td>
         <td style="text-align:left;">&nbsp;<b>TOTAL</b></td>
         <td><b><?php echo $jml_baris2; ?></b></td>
           <!-- <td style="text-align:center;"><?php if ($baris2->$u == null) { echo "-"; }else{echo substr($baris2->$u, 0,2) ;} ?></td> -->
           <?php if ($tgl_2 >= "01"){ ?><td><?php echo $total_jam01; ?></td><?php } ?>
           <?php if ($tgl_2 >= "02"){ ?><td><?php echo $total_jam02; ?></td><?php } ?>
           <?php if ($tgl_2 >= "03"){ ?><td><?php echo $total_jam03; ?></td><?php } ?>
           <?php if ($tgl_2 >= "04"){ ?><td><?php echo $total_jam04; ?></td><?php } ?>
           <?php if ($tgl_2 >= "05"){ ?><td><?php echo $total_jam05; ?></td><?php } ?>
           <?php if ($tgl_2 >= "06"){ ?><td><?php echo $total_jam06; ?></td><?php } ?>
           <?php if ($tgl_2 >= "07"){ ?><td><?php echo $total_jam07; ?></td><?php } ?>
           <?php if ($tgl_2 >= "08"){ ?><td><?php echo $total_jam08; ?></td><?php } ?>
           <?php if ($tgl_2 >= "09"){ ?><td><?php echo $total_jam09; ?></td><?php } ?>
           <?php if ($tgl_2 >= "10"){ ?><td><?php echo $total_jam10; ?></td><?php } ?>

           <?php if ($tgl_2 >= "11"){ ?><td><?php echo $total_jam11; ?></td><?php } ?>
           <?php if ($tgl_2 >= "12"){ ?><td><?php echo $total_jam12; ?></td><?php } ?>
           <?php if ($tgl_2 >= "13"){ ?><td><?php echo $total_jam13; ?></td><?php } ?>
           <?php if ($tgl_2 >= "14"){ ?><td><?php echo $total_jam14; ?></td><?php } ?>
           <?php if ($tgl_2 >= "15"){ ?><td><?php echo $total_jam15; ?></td><?php } ?>
           <?php if ($tgl_2 >= "16"){ ?><td><?php echo $total_jam16; ?></td><?php } ?>
           <?php if ($tgl_2 >= "17"){ ?><td><?php echo $total_jam17; ?></td><?php } ?>
           <?php if ($tgl_2 >= "18"){ ?><td><?php echo $total_jam18; ?></td><?php } ?>
           <?php if ($tgl_2 >= "19"){ ?><td><?php echo $total_jam19; ?></td><?php } ?>
           <?php if ($tgl_2 >= "20"){ ?><td><?php echo $total_jam20; ?></td><?php } ?>

           <?php if ($tgl_2 >= "21"){ ?><td><?php echo $total_jam21; ?></td><?php } ?>
           <?php if ($tgl_2 >= "22"){ ?><td><?php echo $total_jam22; ?></td><?php } ?>
           <?php if ($tgl_2 >= "23"){ ?><td><?php echo $total_jam23; ?></td><?php } ?>
           <?php if ($tgl_2 >= "24"){ ?><td><?php echo $total_jam24; ?></td><?php } ?>
           <?php if ($tgl_2 >= "25"){ ?><td><?php echo $total_jam25; ?></td><?php } ?>
           <?php if ($tgl_2 >= "26"){ ?><td><?php echo $total_jam26; ?></td><?php } ?>
           <?php if ($tgl_2 >= "27"){ ?><td><?php echo $total_jam27; ?></td><?php } ?>
           <?php if ($tgl_2 >= "28"){ ?><td><?php echo $total_jam28; ?></td><?php } ?>
           <?php if ($tgl_2 >= "29"){ ?><td><?php echo $total_jam29; ?></td><?php } ?>
           <?php if ($tgl_2 >= "30"){ ?><td><?php echo $total_jam30; ?></td><?php } ?>

           <?php if ($tgl_2 >= "31"){ ?><td><?php echo $total_jam31; ?></td><?php } ?>
           <?php
             // $total = substr($baris->$u, 0,2) + $total;
           // } ?>
         <td style="text-align:center;"><b><?php echo $total; ?></b></td>
       </tr>
       <?php
         }
       } ?>
     </table>

  </body>
</html>
