<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Lihat Proyek User</legend>

              <table width="100%">
                  <tr>
                    <td width="100">Nama</td>
                    <td>: <?php echo $p_user->nama_lengkap; ?></td>
                  </tr>
                  <tr>
                    <td width="100">NRP</td>
                    <td>: <?php echo $p_user->nrp; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Bagian</td>
                    <td>: <?php echo $p_user->nama_bagian; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Proyek</td>
                    <td>
                      <?php
                      if ($cek_proyek == 0) {
                        echo "-";
                      }else{
                        foreach ($get_proyek as $baris) {
                            echo ": $baris->nama_proyek <br>";
                        }
                      }?>
                    </td>
                  </tr>
              </table>
            </fieldset>

            <a href="admin/ip_user" class="btn btn-default"><< Kembali</a>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
