<?php
  $cek    = $user->row();
  $id_user = $cek->id_user;
  $nama    = $cek->nama_lengkap;
  $nrp     = $cek->nrp;

  $tgl = date('m-Y');
?>

<!-- Main content -->
<div class="content-wrapper">
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat bg-info">
        <div class="panel-heading">
          <h3 class="panel-title">
            <center>Selamat Datang, <?php echo ucwords($nama); ?></center>
          </h3>
        </div>
      </div>
      <!-- /basic datatable -->

      <div class="row">
        <div class="col-lg-12">

          <!-- Quick stats boxes -->
          <div class="row">
            <div class="col-lg-4">

              <!-- Current server load -->
              <div class="panel bg-teal-400">
                <div class="panel-body">

                  <h3 class="no-margin"><?php echo $this->db->query("SELECT * FROM tbl_jam_kerja WHERE id_user='$id_user' AND tgl LIKE '%$tgl'")->num_rows(); ?></h3>
                  Jam Kerja Bulan ini
                </div>

                <div id="server-load"></div>
              </div>
              <!-- /current server load -->

            </div>

            <div class="col-lg-4">

              <!-- Current server load -->
              <div class="panel bg-orange-400">
                <div class="panel-body">

                  <h3 class="no-margin"><?php echo $this->db->query("SELECT * FROM tbl_proyek_user WHERE nrp='$nrp'")->num_rows(); ?></h3>
                  Jumlah Proyek yang ditangani
                </div>

                <div id="server-load"></div>
              </div>
              <!-- /current server load -->

            </div>

            <div class="col-lg-4">

              <!-- Today's revenue -->
              <div class="panel bg-pink-400">
                <div class="panel-body">

                  <h3 class="no-margin"><?php echo $this->db->query("SELECT * FROM tbl_jam_kerja WHERE status='telat' AND id_user='$id_user'")->num_rows(); ?></h3>
                  Banyak Jam Kerja Telat
                </div>

                <div id="today-revenue"></div>
              </div>
              <!-- /today's revenue -->

            </div>
          </div>
          <!-- /quick stats boxes -->

          <div class="row">
            <div class="col-lg-6">

              <div class="calendar"></div>
              <div class="box"></div>
              <br>
            </div>
            <div class="col-lg-6">

              <div class="panel panel-flat">
                <div class="panel-heading">

                  <?php
                  echo $this->session->flashdata('msg');
                  ?>
                  <h3 class="panel-title">
                    Tulis Pesan ke Admin <a href="users/pesan" class="btn btn-default"><i class="icon-envelope"></i> Kotak Masuk</a>
                  </h3>
                  <hr style="margin:0px;">
                </div>
                <div class="panel-body">
                  <form action="" method="post">
                    <textarea name="isi" class="form-control" rows="8" cols="80" placeholder="Tulis Pesan Anda . . ." required></textarea>
                    <input type="submit" name="btnkirim" class="btn btn-primary" value="Kirim" style="float:right;">
                    <br><br>
                  </form>

                </div>
              </div>

            </div>

            <br>
          </div>

        </div>


      </div>

    </div>
    <!-- /dashboard content -->


    <script type="text/javascript">
    $(function() {
      function onClickHandler(date, obj) {
        /**
         * @date is an array which be included dates(clicked date at first index)
         * @obj is an object which stored calendar interal data.
         * @obj.calendar is an element reference.
         * @obj.storage.activeDates is all toggled data, If you use toggle type calendar.
               * @obj.storage.events is all events associated to this date
         */

        var $calendar = obj.calendar;
        var $box = $calendar.parent().siblings('.box').show();
        var text = 'Anda memilih tanggal ';

        if(date[0] !== null) {
          text += date[0].format('DD MMMM YYYY');
        }

        if(date[0] !== null && date[1] !== null) {
          text += ' ~ ';
        } else if(date[0] === null && date[1] == null) {
          text += 'tidak ada';
        }

        if(date[1] !== null) {
          text += date[1].format('DD MMMM YYYY');
        }

        $box.text(text);
      }

      $('.calendar').pignoseCalendar({
        lang: 'ind',
        select: onClickHandler,
        theme: 'blue' // light, dark, blue
      });
    });

    </script>
