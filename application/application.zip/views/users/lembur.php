
<script type='text/javascript'>
        var site = "<?php echo site_url();?>";


        $(function(){

            $('.autocomplete').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/users/cari_proyek_user',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_kd_p').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                    $.ajax({
                      url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                      type : "GET",
                      beforeSend: function() {
                          $('#sel_proyek').attr('disabled', true);
                      },
                      success: function(data){
                          $('#sel_proyek').attr('disabled', false);
                          $('#sel_proyek').html(data);
                          $('#sel_proyek').focus();
                      }
                    });

                }
            });


            $('#cari').keyup(function(){
                if ($('#cari').val() == "") {
                    $('#v_kd_p').val('');
                    $('#sel_proyek').html('<option value="">-- Pilih Proyek --</option>');
                }
            });


            $('.v_aktivitas').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/users/cari_aktivitas',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_no_wbsx').val(''+suggestion.no_wbs);
                    $('#v_no_wbs').val(''+suggestion.no_wbs);
                }
            });

            $('#aktivitas').keyup(function(){
                if ($('#aktivitas').val() == "") {
                    $('#v_no_wbsx').val('');
                    $('#v_no_wbs').val('');
                }
            });

        });


        counter=0;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data=''+
            '<div class="col-md-12"><hr>'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Kode Proyek ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="search" name="caril[]" id="cari_'+ counterNumber +'" class="form-control autocomplete_'+ counterNumber +'" value="" placeholder="Ketikkan Kode Proyek ['+ counterNumber +']" required>'+
            '        <input type="hidden" id="v_kd_p_'+ counterNumber +'" name="kode_proyekl[]"/>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Pilih Proyek ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '         <select class="form-control" name="id_proyekl[]" id="sel_proyek_'+ counterNumber +'" required>'+
            '             <option value="">-- Pilih Proyek --</option>'+
            '         </select>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Aktivitas ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="aktivitasl[]" class="form-control v_aktivitas_'+ counterNumber +'" value="" placeholder="Isi Aktivitas ['+ counterNumber +']" id="aktivitas_'+ counterNumber +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">No. WBS ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="no_wbsxl[]" class="form-control" value="" placeholder="No. WBS ['+ counterNumber +']" id="v_no_wbsx_'+ counterNumber +'" required readonly>'+
            '        <input type="hidden" name="no_wbsl[]" class="form-control" value="" placeholder="No. WBS" id="v_no_wbs_'+ counterNumber +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '     <label class="control-label col-lg-2">Jumlah Jam ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '       <input type="number" name="jaml[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam ['+ counterNumber +']">'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">History Hari ini ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <textarea name="ketl[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan ['+ counterNumber +']"></textarea>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;

            $('.autocomplete_'+ counterNumber +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/users/cari_proyek_user',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_kd_p_'+ counterNumber +'').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                    $.ajax({
                      url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                      type : "GET",
                      beforeSend: function() {
                          $('#sel_proyek_'+ counterNumber +'').attr('disabled', true);
                      },
                      success: function(data){
                          $('#sel_proyek_'+ counterNumber +'').attr('disabled', false);
                          $('#sel_proyek_'+ counterNumber +'').html(data);
                          $('#sel_proyek_'+ counterNumber +'').focus();
                      }
                    });

                }

            });


            $('#cari_'+ counterNumber +'').keyup(function(){
                if ($('#cari_'+ counterNumber +'').val() == "") {
                    $('#v_kd_p_'+ counterNumber +'').val('');
                }
            });

            $('.v_aktivitas_'+ counterNumber +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/users/cari_aktivitas',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_no_wbsx_'+ counterNumber +'').val(''+suggestion.no_wbs);
                    $('#v_no_wbs_'+ counterNumber +'').val(''+suggestion.no_wbs);
                }
            });

            $('#aktivitas_'+ counterNumber +'').keyup(function(){
                if ($('#aktivitas_'+ counterNumber +'').val() == "") {
                    $('#v_no_wbsx_'+ counterNumber +'').val('');
                    $('#v_no_wbs_'+ counterNumber +'').val('');
                }
            });

            counter++;
        }
</script>

<?php
$cek = $user->row();
?>
<!-- Main content -->
<div class="content-wrapper">
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">
        <?php
        echo $this->session->flashdata('msg');
        ?>
          <div class="panel-body">
            <div class="pesan"></div>

            <fieldset class="content-group">
              <legend class="text-bold">Isi Jam Kerja Lembur</legend>
              <form class="form-horizontal jam_kerja" action="#" method="post">
                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Tanggal</label>
                      <div class="col-lg-10 input-group">
                        <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                        <input type="hidden" name="model" id="mode" value="auto">
                        <input type="text" name="tgll" class="form-control daterange-single" id="datepicker" value="<?php echo date('d-m-Y'); ?>" maxlength="10" required onchange="cek_tgl()" placeholder="Masukkan Tanggal">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Nama</label>
                      <div class="col-lg-10">
                        : <label><?php echo ucwords($cek->nama_lengkap); ?></label>
                        <input type="hidden" name="id_userl" id="id_user" class="form-control" value="<?php echo $cek->id_user; ?>">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">NRP</label>
                      <div class="col-lg-10">
                        : <label><?php echo $cek->nrp; ?></label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Bagian</label>
                      <div class="col-lg-10">
                        : <label><?php echo strtoupper($cek_bagian->nama_bagian); ?></label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Kode Proyek</label>
                      <div class="col-lg-10">
                        <input type="search" name="caril[]" id="cari" class="form-control autocomplete" value="" placeholder="Ketikkan Kode Proyek" required>
                        <input type="hidden" id="v_kd_p" name="kode_proyekl[]"/>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Pilih Proyek</label>
                      <div class="col-lg-10">
                         <select class="form-control" name="id_proyekl[]" id="sel_proyek" required>
                             <option value="">-- Pilih Proyek --</option>
                         </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Aktivitas</label>
                      <div class="col-lg-10">
                        <input type="text" name="aktivitasl[]" class="form-control v_aktivitas" value="" placeholder="Isi Aktivitas" id="aktivitas" required>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">No. WBS</label>
                      <div class="col-lg-10">
                        <input type="text" name="no_wbsxl[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbsx' required readonly>
                        <input type="hidden" name="no_wbsl[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbs' required>
                        <!-- <select class="form-control" name="no_wbs" required>
                          <option value="">-- Pilih No. WBS --</option>
                          <?php
                          for ($i=1; $i <= 100; $i++) {
                          ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                          <?php
                          } ?>
                        </select> -->
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Jumlah Jam</label>
                      <div class="col-lg-10">
                        <input type="number" name="jaml[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">History Hari ini</label>
                      <div class="col-lg-10">
                        <textarea name="ketl[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan"></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                <div id="input0"></div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2"></label>
                      <div class="col-lg-10">
                        <hr>
                        <a href="javascript:action();" class="btn btn-warning">Tambah</a>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Lain - Lain</label>
                      <div class="col-lg-10">
                        <!-- <textarea name="ket" class="form-control" rows="4" cols="80" required></textarea> -->
                        <!-- <select class="form-control" name="ket" required>
                          <option value="">-- Pilih --</option>
                          <option value="MEETING">MEETING</option>
                          <option value="CEK DRAWING">CEK DRAWING</option>
                          <option value="SUPERVISI">SUPERVISI</option>
                          <option value="PERJALANAN">PERJALANAN</option>
                          <option value="MEETING NON PROYEK (TEKNIS)">MEETING NON PROYEK (TEKNIS)</option>
                          <option value="MEETING NON PROYEK (NON TEKNIS)">MEETING NON PROYEK (NON TEKNIS)</option>
                          <option value="LAIN-LAIN">LAIN-LAIN</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div> -->

                <br>
                <hr>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;" id='btnsimpan'>Simpan</button>

              </form>

            </fieldset>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->

<script type="text/javascript">
  $('.pesan').hide();

  function cek_tgl(){
    var tgl_now = "<?php echo date('d-m-Y'); ?>";
    var tgl     = $('#datepicker');

    // if (tgl.val() >= tgl_now) {
    //   $('#nama').show();
    // }else{
    //   $('#nama').hide();
    // }

    if(tgl.val() != ''){

       $.ajax({
         type : 'POST',
         data : 'tgl='+tgl.val(),
         url  : '<?php echo base_url(); ?>users/cek_tgl_fl',
         cache: false,
         dataType: "JSON",
         beforeSend: function() {
             $('.pesan').hide();
         },
         success: function(data){

           if (data.status == true) {
             $(".pesan").hide();
             $(".pesan").html('');
           }else{
             $(".pesan").show();
             $(".pesan").html(data.pesan);
           }

         }
       });
    }
  }


  $(document).ready(function() {
    $('#btnsimpan').click(function(){
       var id_user    = $('[name="id_userl"]');
       var tgl        = $('[name="tgll"]');
       var no_wbs     = $('[name="no_wbsl"]');
       var cari       = $('[name="caril"]');
       var aktivitas  = $('[name="aktivitasl"]');
       var jam        = $('[name="jaml"]');
       var ket        = $('[name="ketl"]');

       if(id_user.val() != '' && tgl.val() != '' && no_wbs.val() != '' && cari.val() != '' && aktivitas.val() != '' && jam.val() != '' && ket.val() != ''){

            $.ajax({
              type : 'POST',
              data :$('.jam_kerja').serialize(),
              url  : '<?php echo base_url(); ?>users/simpan_jk_fl',
              cache: false,
              dataType: "JSON",
              beforeSend: function() {
                  $(".pesan").hide();
                  $(".pesan").html('');
                  $('#btnsimpan').html('Proses... <i class="icon-spinner6 position-right"></i>');
                  $('#btnsimpan').attr('disabled',true);
              },
              success: function(data){

                if (data.status == true) {
                  $('.jam_kerja')[0].reset();
                  $('[name="id_proyekl[]"]').html('<option value="">-- Pilih Proyek --</option>');
                }

                $(".pesan").show();
                $(".pesan").html(data.pesan);

                  $('#btnsimpan').html('Simpan');
                  $('#btnsimpan').attr('disabled',false);

                  $('[name="tgll"]').focus();

              }
            });

       }
       //return false;
      });

  });
</script>
