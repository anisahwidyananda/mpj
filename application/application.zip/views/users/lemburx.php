

<?php
$cek = $user->row();
?>
<!-- Main content -->
<div class="content-wrapper">
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">
        <?php
        echo $this->session->flashdata('msg');
        ?>
          <div class="panel-body">
            <div class="pesan"></div>

            <fieldset class="content-group">
              <legend class="text-bold">Isi Jam Kerja</legend>
              <form class="form-horizontal fl" action="#" method="post">
                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Tanggal</label>
                      <div class="col-lg-10 input-group">
                        <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                        <input type="hidden" name="mode" id="mode" value="auto">
                        <input type="text" name="tgl" class="form-control daterange-single" id="datepicker" value="<?php echo date('d-m-Y'); ?>" maxlength="10" required onchange="cek_tgl()" placeholder="Masukkan Tanggal">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Nama</label>
                      <div class="col-lg-10">
                        : <label><?php echo ucwords($cek->nama_lengkap); ?></label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">NRP</label>
                      <div class="col-lg-10">
                        : <label><?php echo $cek->nrp; ?></label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Bagian</label>
                      <div class="col-lg-10">
                        : <label><?php echo strtoupper($cek_bagian->nama_bagian); ?></label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2"></label>
                      <div class="col-lg-10">
                        <label> Apakah anda yakin hari ini lembur :</label> <br>
                        <label><input type="radio" name="pilih" value="Ya" required> Ya </label><br>
                        <label><input type="radio" name="pilih" value="Tidak" required> Tidak </label>
                      </div>
                    </div>
                  </div>
                </div>

                <br>
                <hr>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;" id='btnsimpan'>Simpan</button>

              </form>

            </fieldset>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->

<script type="text/javascript">
  $('.pesan').hide();

  function cek_tgl(){
    var tgl_now = "<?php echo date('d-m-Y'); ?>";
    var tgl     = $('#datepicker');

    // if (tgl.val() >= tgl_now) {
    //   $('#nama').show();
    // }else{
    //   $('#nama').hide();
    // }

    if(tgl.val() != ''){

       $.ajax({
         type : 'POST',
         data : 'tgl='+tgl.val(),
         url  : '<?php echo base_url(); ?>users/cek_tgl_fl',
         cache: false,
         dataType: "JSON",
         beforeSend: function() {
             $('.pesan').hide();
         },
         success: function(data){

           if (data.status == true) {
             $(".pesan").hide();
             $(".pesan").html('');
           }else{
             $(".pesan").show();
             $(".pesan").html(data.pesan);
           }

         }
       });
    }
  }


  $(document).ready(function() {
    $('#btnsimpan').click(function(){
       var tgl        = $('[name="tgl"]');
       var pilih      = $('[name="pilih"]');

       if(tgl.val() != '' && pilih.val() != '' && $('input:radio[name=pilih]:checked').length != 0){

            $.ajax({
              type : 'POST',
              data :$('.fl').serialize(),
              url  : '<?php echo base_url(); ?>users/simpan_fl',
              cache: false,
              dataType: "JSON",
              beforeSend: function() {
                  $(".pesan").hide();
                  $(".pesan").html('');
                  $('#btnsimpan').html('Proses... <i class="icon-spinner6 position-right"></i>');
                  $('#btnsimpan').attr('disabled',true);
              },
              success: function(data){

                if (data.status == true) {
                  $('.fl')[0].reset();
                }

                $(".pesan").show();
                $(".pesan").html(data.pesan);

                  $('#btnsimpan').html('Simpan');
                  $('#btnsimpan').attr('disabled',false);

                  $('[name="tgl"]').focus();

              }
            });

       }
       //return false;
      });

  });
</script>
