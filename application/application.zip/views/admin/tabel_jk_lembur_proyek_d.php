<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">

              <form class="form-horizontal" action="" method="post">
              <legend class="text-bold">Lihat Tabel Jam Kerja Lembur Per Proyek</legend>
              <?php
              if ($proyek->nama_proyek == '') {
                redirect('admin/tabel_jk');
              } ?>
              <b>Proyek <?php echo ucwords($proyek->nama_proyek); ?>:</b> <br><br>
              <div class="col-lg-3">
                <select class="form-control" name="id_bagian">
                  <option value="">-- Pilih Bagian --</option>
                  <?php
                  foreach ($bagian as $baris) {?>
                    <option value="<?php echo $baris->id_bagian; ?>" <?php if ($v_id_bagian == $baris->id_bagian){echo "selected";} ?>><?php echo $baris->nama_bagian; ?></option>
                  <?php
                  } ?>
                </select>
              </div>
              <div class="col-lg-12"><br></div>
              <br>

              <div class="form-group">
                <label class="control-label col-lg-2">Pilih Tanggal:</label>
                <div class="col-lg-2">
                  <input type="text" name="tgl1" class="form-control daterange-single" value="<?php if (isset($_POST['tgl1'])) { echo $_POST['tgl1'];}else{ echo '01-'.date('m-Y');} ?>" placeholder="Masukkan Tanggal Proyek yang dibuat" required="">
                  <!-- <select class="form-control" name="bulan">
                    <?php
                    $tgl  = strtolower($this->uri->segment(4));
                    $bln  = substr($tgl,0,2);
                    ?>
                      <option value="01" <?php if ($bln == "01") { echo "selected"; } ?>>Januari</option>
                      <option value="02" <?php if ($bln == "02") { echo "selected"; } ?>>Februari</option>
                      <option value="03" <?php if ($bln == "03") { echo "selected"; } ?>>Maret</option>
                      <option value="04" <?php if ($bln == "04") { echo "selected"; } ?>>April</option>
                      <option value="05" <?php if ($bln == "05") { echo "selected"; } ?>>Mei</option>
                      <option value="06" <?php if ($bln == "06") { echo "selected"; } ?>>Juni</option>
                      <option value="07" <?php if ($bln == "07") { echo "selected"; } ?>>Juli</option>
                      <option value="08" <?php if ($bln == "08") { echo "selected"; } ?>>Agustus</option>
                      <option value="09" <?php if ($bln == "09") { echo "selected"; } ?>>September</option>
                      <option value="10" <?php if ($bln == 10) { echo "selected"; } ?>>Oktober</option>
                      <option value="11" <?php if ($bln == 11) { echo "selected"; } ?>>November</option>
                      <option value="12" <?php if ($bln == 12) { echo "selected"; } ?>>Desember</option>
                  </select> -->
                </div>
                <label class="control-label col-lg-1" style="margin-right:-46px;">s/d</label>
                <div class="col-lg-2">
                  <input type="text" name="tgl2" class="form-control daterange-single" value="<?php if (isset($_POST['tgl2'])) { echo $_POST['tgl2'];} ?>" placeholder="Masukkan Tanggal Proyek yang dibuat" required="">
                  <!-- <select class="form-control" name="tahun">
                    <?php
                    $max = date('Y');
                    $tgl  = strtolower($this->uri->segment(4));
                    $thn  = substr($tgl,2,6);
                    for ($i=2016; $i <= $max; $i++) {
                      if ($i == $thn) {
                        $sel = "selected";
                      }else{
                        $sel = "";
                      }
                    ?>
                      <option value="<?php echo $i; ?>" <?php echo $sel; ?>><?php echo $i; ?></option>
                    <?php
                    } ?>
                  </select> -->
                </div>
                <button type="submit" name="btncek" class="btn btn-default">Cek</button>
              </div>
              </form>
              <br>
              <div class="table-responsive">

                <?php

                if (isset($_POST['btncek'])) {
                    $tgl1 = htmlentities(strip_tags($this->input->post('tgl1')));
                    $tgl2 = htmlentities(strip_tags($this->input->post('tgl2')));
                }else{
                    $tgl1 = '01-'.date('m-Y');
                    $tgl2 = date('d-m-Y');
                }

                $tgl_1 = substr($tgl1,0,2);
                $bln_1 = substr($tgl1,3,7);
                // $thn_1 = substr($tgl1,8,12);

                $tgl_2 = substr($tgl2,0,2);
                $bln_2 = substr($tgl2,3,7);
                // $thn_2 = substr($tgl2,6,10);

                $start_date = new DateTime("$tgl1");
                $end_date = new DateTime("$tgl2");
                $interval = $start_date->diff($end_date);
                $jk_cols  = $interval->days + 1; // hasil hari


                 ?>
              <table border="1" width="100%">
                <tr style="background-color:#f1f1f1;">
                  <!--<th rowspan="2" style="text-align:center;width:30px;"><b>No.</b></th>-->
                  <th rowspan="2" style="text-align:center;min-width:100px;"><b>Nama</b></th>
                  <th rowspan="2" style="text-align:center;min-width:10px;"><b>NRP</b></th>
                  <th colspan="<?= $jk_cols; ?>" style="text-align:center;padding:10px;"><b>Jam Kerja Per tanggal (Jam)</b></th>
                  <th rowspan="2" style="text-align:center;padding:10px;"><b>TOTAL</b></th>
                </tr>
                <tr style="background-color:#f1f1f1;">
                  <?php
                  for ($i=$tgl_1; $i <= $tgl_2; $i++) {
                    if ($i < 10) {
                      if ($tgl_1 != $i) {
                        $i = '0'.$i;
                      }
                    }
                  ?>
                   <th style="text-align:center;"><b><?php echo $i; ?></b></th>
                  <?php
                  } ?>
                </tr>
                <?php
                error_reporting(0);
                $no = 1;
                $total_perproyek = 0;
                $total = 0;
                $u = 0;
                $total_jam01 = 0;
                $total_jam02 = 0;
                $total_jam03 = 0;
                $total_jam04 = 0;
                $total_jam05 = 0;
                $total_jam06 = 0;
                $total_jam07 = 0;
                $total_jam08 = 0;
                $total_jam09 = 0;
                $total_jam10 = 0;

                $total_jam11 = 0;
                $total_jam12 = 0;
                $total_jam13 = 0;
                $total_jam14 = 0;
                $total_jam15 = 0;
                $total_jam16 = 0;
                $total_jam17 = 0;
                $total_jam18 = 0;
                $total_jam19 = 0;
                $total_jam20 = 0;

                $total_jam21 = 0;
                $total_jam22 = 0;
                $total_jam23 = 0;
                $total_jam24 = 0;
                $total_jam25 = 0;
                $total_jam26 = 0;
                $total_jam27 = 0;
                $total_jam28 = 0;
                $total_jam29 = 0;
                $total_jam30 = 0;

                $total_jam31 = 0;

                foreach ($t_user->result() as $row) {

                  $id_u   = $row->id_user;
                  $id     = strtolower($this->uri->segment(3));
                  // $blnthn = strtolower($this->uri->segment(4));

                  // $bln = substr($blnthn,0,2);
                  // $thn = substr($blnthn,2,6);
                  // $bln_thn = "$id_u-$id-$bln-$thn";

                    // $baris = $this->db->query("SELECT * FROM tbl_pertgl
                    //                             INNER JOIN tbl_jam_kerja ON tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl
                    //                             WHERE tbl_pertgl.id_pertgl='$bln_thn'")->row();

                    $bln_thn = "$id_u-$id-$bln_2";

                    $baris = $this->db->query("SELECT * FROM tbl_pertgl
                                                INNER JOIN tbl_jam_kerja ON tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl
                                                WHERE tbl_pertgl.id_pertgl='$bln_thn'")->row();
                                                // WHERE id_user='$id_u' AND id_proyek='$id' AND (tbl_jam_kerja.tgl BETWEEN '$tgl1' AND '$tgl2')")->row();
                ?>
                  <tr style="text-align:center;">
                    <td style="text-align:left;">&nbsp; <?php echo ucwords($row->nama_lengkap);?></td>
                    <td style="text-align:left;">&nbsp; <?php echo $row->nrp;?></td>
                    <?php
                    for ($i=$tgl_1; $i <= $tgl_2 ; $i++) {
                      if ($i < 10) {
                        if ($tgl_1 != $i) {
                          $i = '0'.$i;
                        }
                      }
                      $u = "jam_tgl$i";

                      $jml_lembur = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "$i-$bln_2"))->num_rows();

                      if ($jml_lembur != 0) {
                        $total_perproyek = substr($baris->$u, 0,2) + $total_perproyek;
                        $total = substr($baris->$u, 0,2) + $total;
                      }
                      ?>
                        <td style="<?php if (strlen($baris->$u) > 2 AND $jml_lembur != 0) { echo "background-color:red;color:white;";} ?>"><?php if ($baris->$u == null or $jml_lembur == 0) { echo "-"; }else{echo substr($baris->$u, 0,2) ;} ?></td>
                    <?php
                    } ?>
                        <td><b><?php echo $total_perproyek; ?></b></td>
                  </tr>
                <?php
                $jml_lembur01 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "01-$bln_2"))->num_rows();
                  if($jml_lembur01 != 0){ $total_jam01 = substr($baris->jam_tgl01, 0,2) + $total_jam01;}

                $jml_lembur02 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "02-$bln_2"))->num_rows();
                  if($jml_lembur02 != 0 ){ $total_jam02 = substr($baris->jam_tgl02, 0,2) + $total_jam02;}

                $jml_lembur03 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "03-$bln_2"))->num_rows();
                  if($jml_lembur03 != 0 ){ $total_jam03 = substr($baris->jam_tgl03, 0,2) + $total_jam03;}

                $jml_lembur04 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "04-$bln_2"))->num_rows();
                  if($jml_lembur04 != 0 ){ $total_jam04 = substr($baris->jam_tgl04, 0,2) + $total_jam04;}

                $jml_lembur05 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "05-$bln_2"))->num_rows();
                  if($jml_lembur05 != 0 ){ $total_jam05 = substr($baris->jam_tgl05, 0,2) + $total_jam05;}

                $jml_lembur06 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "06-$bln_2"))->num_rows();
                  if($jml_lembur06 != 0 ){ $total_jam06 = substr($baris->jam_tgl06, 0,2) + $total_jam06;}

                $jml_lembur07 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "07-$bln_2"))->num_rows();
                  if($jml_lembur07 != 0 ){ $total_jam07 = substr($baris->jam_tgl07, 0,2) + $total_jam07;}

                $jml_lembur08 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "08-$bln_2"))->num_rows();
                  if($jml_lembur08 != 0 ){ $total_jam08 = substr($baris->jam_tgl08, 0,2) + $total_jam08;}

                $jml_lembur09 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "09-$bln_2"))->num_rows();
                  if($jml_lembur09 != 0 ){ $total_jam09 = substr($baris->jam_tgl09, 0,2) + $total_jam09;}

                $jml_lembur10 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "10-$bln_2"))->num_rows();
                  if($jml_lembur10 != 0 ){ $total_jam10 = substr($baris->jam_tgl10, 0,2) + $total_jam10;}

                $jml_lembur11 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "11-$bln_2"))->num_rows();
                  if($jml_lembur11 != 0 ){ $total_jam11 = substr($baris->jam_tgl11, 0,2) + $total_jam11;}

                $jml_lembur12 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "12-$bln_2"))->num_rows();
                  if($jml_lembur12 != 0 ){ $total_jam12 = substr($baris->jam_tgl12, 0,2) + $total_jam12;}

                $jml_lembur13 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "13-$bln_2"))->num_rows();
                  if($jml_lembur13 != 0 ){ $total_jam13 = substr($baris->jam_tgl13, 0,2) + $total_jam13;}

                $jml_lembur14 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "14-$bln_2"))->num_rows();
                  if($jml_lembur14 != 0 ){ $total_jam14 = substr($baris->jam_tgl14, 0,2) + $total_jam14;}

                $jml_lembur15 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "15-$bln_2"))->num_rows();
                  if($jml_lembur15 != 0 ){ $total_jam15 = substr($baris->jam_tgl15, 0,2) + $total_jam15;}

                $jml_lembur16 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "16-$bln_2"))->num_rows();
                  if($jml_lembur16 != 0 ){ $total_jam16 = substr($baris->jam_tgl16, 0,2) + $total_jam16;}

                $jml_lembur17 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "17-$bln_2"))->num_rows();
                  if($jml_lembur17 != 0 ){ $total_jam17 = substr($baris->jam_tgl17, 0,2) + $total_jam17;}

                $jml_lembur18 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "18-$bln_2"))->num_rows();
                  if($jml_lembur18 != 0 ){ $total_jam18 = substr($baris->jam_tgl18, 0,2) + $total_jam18;}

                $jml_lembur19 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "19-$bln_2"))->num_rows();
                  if($jml_lembur19 != 0 ){ $total_jam19 = substr($baris->jam_tgl19, 0,2) + $total_jam19;}

                $jml_lembur20 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "20-$bln_2"))->num_rows();
                  if($jml_lembur20 != 0 ){ $total_jam20 = substr($baris->jam_tgl20, 0,2) + $total_jam20;}

                $jml_lembur21 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "21-$bln_2"))->num_rows();
                  if($jml_lembur21 != 0 ){ $total_jam21 = substr($baris->jam_tgl21, 0,2) + $total_jam21;}

                $jml_lembur22 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "22-$bln_2"))->num_rows();
                  if($jml_lembur22 != 0 ){ $total_jam22 = substr($baris->jam_tgl22, 0,2) + $total_jam22;}

                $jml_lembur23 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "23-$bln_2"))->num_rows();
                  if($jml_lembur23 != 0 ){ $total_jam23 = substr($baris->jam_tgl23, 0,2) + $total_jam23;}

                $jml_lembur24 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "24-$bln_2"))->num_rows();
                  if($jml_lembur24 != 0 ){ $total_jam24 = substr($baris->jam_tgl24, 0,2) + $total_jam24;}

                $jml_lembur25 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "25-$bln_2"))->num_rows();
                  if($jml_lembur25 != 0 ){ $total_jam25 = substr($baris->jam_tgl25, 0,2) + $total_jam25;}

                $jml_lembur26 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "26-$bln_2"))->num_rows();
                  if($jml_lembur26 != 0 ){ $total_jam26 = substr($baris->jam_tgl26, 0,2) + $total_jam26;}

                $jml_lembur27 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "27-$bln_2"))->num_rows();
                  if($jml_lembur27 != 0 ){ $total_jam27 = substr($baris->jam_tgl27, 0,2) + $total_jam27;}

                $jml_lembur28 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "28-$bln_2"))->num_rows();
                  if($jml_lembur28 != 0 ){ $total_jam28 = substr($baris->jam_tgl28, 0,2) + $total_jam28;}

                $jml_lembur29 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "29-$bln_2"))->num_rows();
                  if($jml_lembur29 != 0 ){ $total_jam29 = substr($baris->jam_tgl29, 0,2) + $total_jam29;}

                $jml_lembur30 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "30-$bln_2"))->num_rows();
                  if($jml_lembur30 != 0 ){ $total_jam30 = substr($baris->jam_tgl30, 0,2) + $total_jam30;}

                $jml_lembur31 = $this->db->get_where('tbl_lembur', array('id_user' => "$id_u", 'id_proyek' => "$id_p", 'tgl_lembur' => "31-$bln_2"))->num_rows();
                  if($jml_lembur31 != 0 ){ $total_jam31 = substr($baris->jam_tgl31, 0,2) + $total_jam31;}


                $total_perproyek = 0;
                $total = $total;
                } ?>
                <tr style="text-align:center;">
                  <td><b>TOTAL</b></td>
                  <td><b><?php echo $t_user->num_rows(); ?></b></td>
                  <?php
                  // $sum   = 0;

                            // for ($j=$tgl_1; $j <= $tgl_2 ; $j++) {
                            //   if ($j < 10) {
                            //     if ($tgl_1 != $j) {
                            //       $j = '0'.$j;
                            //     }
                            //   }
                            //   $this->db->select_sum("tbl_pertgl.jam_tgl$j");
                            // }
                            //
                            //
                            //     $this->db->join('tbl_jam_kerja', 'tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl');
                            //     $this->db->join('tbl_user', 'tbl_user.id_user=tbl_jam_kerja.id_user');
                            //     if ($v_id_bagian != '') {
                            //       $this->db->where('tbl_user.id_bagian', "$v_id_bagian");
                            //     }
                              // $this->db->join('tbl_jam_kerja', 'tbl_jam_kerja.id_pertgl=tbl_pertgl.id_pertgl');
                              // $this->db->where('tbl_jam_kerja.id_user', "$id");
                            //  $this->db->like('tbl_pertgl.id_pertgl', "$id");
                    //          $this->db->like('tbl_pertgl.id_pertgl', "$id-$bln_2", 'before');
                    // $baris2 = $this->db->get('tbl_pertgl')->row();



                    // for ($i=$tgl_1; $i <= $tgl_2; $i++) {
                    //   if ($i < 10) {
                    //     if ($tgl_1 != $i) {
                    //       $i = '0'.$i;
                    //     }
                    //   }
                    //   $u = "jam_tgl$i";

                  for ($tgl_sel=$tgl_1; $tgl_sel <=$tgl_2 ; $tgl_sel++) {
                    ?>
                    <!-- <td style="text-align:center;"><?php if ($baris2->$u == null) { echo "-"; }else{echo substr($baris2->$u, 0,2) ;} ?></td> -->
                    <?php if ($tgl_sel == "01"){ ?><td><?php echo $total_jam01; ?></td><?php } ?>
                    <?php if ($tgl_sel == "02"){ ?><td><?php echo $total_jam02; ?></td><?php } ?>
                    <?php if ($tgl_sel == "03"){ ?><td><?php echo $total_jam03; ?></td><?php } ?>
                    <?php if ($tgl_sel == "04"){ ?><td><?php echo $total_jam04; ?></td><?php } ?>
                    <?php if ($tgl_sel == "05"){ ?><td><?php echo $total_jam05; ?></td><?php } ?>
                    <?php if ($tgl_sel == "06"){ ?><td><?php echo $total_jam06; ?></td><?php } ?>
                    <?php if ($tgl_sel == "07"){ ?><td><?php echo $total_jam07; ?></td><?php } ?>
                    <?php if ($tgl_sel == "08"){ ?><td><?php echo $total_jam08; ?></td><?php } ?>
                    <?php if ($tgl_sel == "09"){ ?><td><?php echo $total_jam09; ?></td><?php } ?>
                    <?php if ($tgl_sel == "10"){ ?><td><?php echo $total_jam10; ?></td><?php } ?>

                    <?php if ($tgl_sel == "11"){ ?><td><?php echo $total_jam11; ?></td><?php } ?>
                    <?php if ($tgl_sel == "12"){ ?><td><?php echo $total_jam12; ?></td><?php } ?>
                    <?php if ($tgl_sel == "13"){ ?><td><?php echo $total_jam13; ?></td><?php } ?>
                    <?php if ($tgl_sel == "14"){ ?><td><?php echo $total_jam14; ?></td><?php } ?>
                    <?php if ($tgl_sel == "15"){ ?><td><?php echo $total_jam15; ?></td><?php } ?>
                    <?php if ($tgl_sel == "16"){ ?><td><?php echo $total_jam16; ?></td><?php } ?>
                    <?php if ($tgl_sel == "17"){ ?><td><?php echo $total_jam17; ?></td><?php } ?>
                    <?php if ($tgl_sel == "18"){ ?><td><?php echo $total_jam18; ?></td><?php } ?>
                    <?php if ($tgl_sel == "19"){ ?><td><?php echo $total_jam19; ?></td><?php } ?>
                    <?php if ($tgl_sel == "20"){ ?><td><?php echo $total_jam20; ?></td><?php } ?>

                    <?php if ($tgl_sel == "21"){ ?><td><?php echo $total_jam21; ?></td><?php } ?>
                    <?php if ($tgl_sel == "22"){ ?><td><?php echo $total_jam22; ?></td><?php } ?>
                    <?php if ($tgl_sel == "23"){ ?><td><?php echo $total_jam23; ?></td><?php } ?>
                    <?php if ($tgl_sel == "24"){ ?><td><?php echo $total_jam24; ?></td><?php } ?>
                    <?php if ($tgl_sel == "25"){ ?><td><?php echo $total_jam25; ?></td><?php } ?>
                    <?php if ($tgl_sel == "26"){ ?><td><?php echo $total_jam26; ?></td><?php } ?>
                    <?php if ($tgl_sel == "27"){ ?><td><?php echo $total_jam27; ?></td><?php } ?>
                    <?php if ($tgl_sel == "28"){ ?><td><?php echo $total_jam28; ?></td><?php } ?>
                    <?php if ($tgl_sel == "29"){ ?><td><?php echo $total_jam29; ?></td><?php } ?>
                    <?php if ($tgl_sel == "30"){ ?><td><?php echo $total_jam30; ?></td><?php } ?>

                    <?php if ($tgl_sel == "31"){ ?><td><?php echo $total_jam31; ?></td><?php } ?>
                    <?php
                  }

                      // $total = substr($baris->$u, 0,2) + $total;
                    // } ?>
                  <td style="text-align:center;"><b><?php echo $total; ?></b></td>
                </tr>
              </table>

              <a href="admin/export_jk/<?php echo "$id/$tgl1/$tgl2/$v_id_bagian"; ?>" class="btn btn-success">Export to Excel</a>
              </div>

            </fieldset>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
