<?php
$query = $ep->row(); ?>

<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Edit Proyek <?php echo ucwords($query->nama_proyek); ?></h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>
        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
            <div class="form-group">
              <label class="control-label col-lg-2"><b>Isi Proyek</b></label>
              <div class="col-lg-10">
                <div class="form-group">
                  <input type="text" name="kode_proyek" class="form-control" value="<?php echo $query->kode_proyek; ?>" placeholder="Masukkan Kode Proyek" readonly>
                </div>
                <div class="form-group">
                  <input type="text" name="nama_proyek" class="form-control" value="<?php echo $query->nama_proyek; ?>" placeholder="Masukkan Proyek" required>
                </div>
                <div class="form-group">
                  <input type="text" name="tgl_proyek" class="form-control daterange-single" id="datepicker" value="<?php echo date('d-m-Y', strtotime($query->tgl_proyek)); ?>" maxlength="10" requiredplaceholder="Masukkan Tanggal Proyek yang dibuat">
                  <p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> Tanggal Proyek yang dibuat</p>
                </div>
                <div class="form-group">
                  <input type="text" name="nama_sekolah" class="form-control" value="<?php echo $query->nama_sekolah; ?>" placeholder="Masukkan Nama Sekolah" required>
                </div>
              </div>
            </div>

            <a href="admin/t_ip" class="btn btn-default">Kembali</a>
            <button type="submit" name="btnupdate" class="btn btn-primary" style="float:right;">Update</button>
          </form>
          <hr>

        </div>

      </div>
      <!-- /basic datatable -->
    </div>
    <!-- /dashboard content -->
