<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=export_lihat_jk.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Export Lihar Jam Kerja</title>
  </head>
  <body>

     <table border="1" width="100%">
       <tr style="background-color:#f1f1f1;">
         <th style="text-align:center;min-width:100px;"><b>Tanggal Input</b></th>
         <th style="text-align:center;min-width:100px;"><b>Nama</b></th>
         <th style="text-align:center;min-width:50px;"><b>NRP</b></th>
         <th style="text-align:center;padding:10px;"><b>Bagian</b></th>
         <th style="text-align:center;padding:10px;"><b>Kode Proyek</b></th>
         <th style="text-align:center;padding:10px;"><b>Nama Proyek</b></th>
         <th style="text-align:center;padding:10px;"><b>Jumlah Jam</b></th>
         <th style="text-align:center;padding:10px;"><b>No. WBS</b></th>
         <th style="text-align:center;padding:10px;"><b>Aktivitas</b></th>
         <th style="text-align:center;padding:10px;"><b>Histori Hari Ini</b></th>
       </tr>
       <?php
       foreach ($t_jam_kerja->result() as $baris) {?>
         <tr>
           <td>&nbsp;<?php echo $baris->tgl; ?></td>
           <td>&nbsp;<?php echo $baris->nama_lengkap; ?></td>
           <td>&nbsp;<?php echo $baris->nrp; ?></td>
           <td>&nbsp;<?php echo $baris->nama_bagian; ?></td>
           <td>&nbsp;<?php echo $baris->kode_proyek; ?></td>
           <td>&nbsp;<?php echo $baris->nama_proyek; ?></td>
           <td>&nbsp;<?php echo $baris->jumlah_jam; ?></td>
           <td>&nbsp;<?php echo $baris->no_wbs; ?></td>
           <td>&nbsp;<?php echo $baris->aktivitas; ?></td>
           <td>&nbsp;<?php echo $baris->ket; ?></td>
         </tr>
       <?php
       }

       if ($t_jam_kerja->num_rows() == 0) {?>
         <tr>
           <th colspan="10" style="background-color:pink;text-align:center;">
             <h2>
               <?php
               if (isset($_POST['btncari'])) {
                 echo "Pencarian tidak ditemukan";
               }else{
                 echo "Data Kosong";
               } ?>
             </h2>
           </th>
         </tr>
       <?php
       }?>
     </table>

  </body>
</html>
