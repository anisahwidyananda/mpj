<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Edit Bagian</legend>

              <form class="form-horizontal" action="" method="post">
                <div class="form-group">
                  <label class="control-label col-lg-2">Nama Bagian</label>
                  <div class="col-lg-10">
                    <input type="text" name="nama_bagian" class="form-control" value="<?php echo $e_bagian->nama_bagian; ?>" placeholder="isi bagian" required>
                  </div>
                </div>
                <hr>
                <a href="admin/bagian" class="btn btn-default"><< Kembali</a>
                <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Update</button>
              </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->
