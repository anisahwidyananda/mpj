<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-md-3"></div>
      <div class="panel panel-flat col-md-6">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Lihat Tabel Jam Kerja Per Proyek</legend>

              <b>Pilih Proyek:</b> <br>
              <?php
              $bln = date('m');
              $thn = date('Y');
              $bln_thn = "$bln$thn";
              foreach ($proyek as $baris) {
              ?>
                <div class="col-md-12">
                  <a href="admin/tabel_jk/<?php echo $baris->id_proyek ?>/<?php echo $bln_thn; ?>" class="btn btn-primary btn-lg" style="width:100%;margin:5px;"><?php echo $baris->nama_proyek; ?></a>
                </div>
              <?php
              } ?>
            </fieldset>
            <div class="col-md-12">
              <a href="" class="btn btn-default" style="float:right;">Beranda</a>
            </div>
          </div>

      </div>
    </div>
    <!-- /dashboard content -->
