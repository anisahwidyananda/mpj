<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat col-md-12">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Lihat Grafik Perbagian</legend>

              <?php
              $thn = date('Y');
              $link_id1 = strtolower($this->uri->segment(3));
              $link_id2 = strtolower($this->uri->segment(4));?>

              <script type="text/javascript">
                var chart1; // globally available
              $(document).ready(function() {
                    chart1 = new Highcharts.Chart({
                       chart: {
                          renderTo: 'grafik',
                          type: 'column'
                       },
                       title: {
                          text: 'Grafik Proyek <?php if($link_id1 != 0){echo "$link_id1 ";} ?>Per Bagian  [<?php if($link_id2 != ""){echo "$link_id2";}else{echo $thn;}; ?>]'
                       },
                       xAxis: {
                          categories: ['Bagian']
                       },
                       yAxis: {
                          title: {
                             text: ''
                          }
                       },
                            series:
                          [
                          <?php
                          $cek_total = 0;
                          foreach ($get_bagian as $baris) {
                            $cek_user = $this->db->get_where('tbl_user', "id_bagian = '$baris->id_bagian'")->result();
                            foreach ($cek_user as $baris1) {
                              $this->db->join('tbl_pertgl', 'tbl_pertgl.id_pertgl=tbl_jam_kerja.id_pertgl');
                              $this->db->where('tbl_jam_kerja.id_user', "$baris1->id_user");
                              if ($link_id1 == 0) {
                                $this->db->like('tbl_jam_kerja.id_pertgl', "$link_id2", 'before');
                              }else{
                                $this->db->like('tbl_jam_kerja.id_pertgl', "$link_id1-$link_id2", 'before');
                              }
                              $cek_jam = $this->db->get('tbl_jam_kerja');

                              if ($cek_jam->num_rows() == 0) {
                                $cek_total = 0;
                              }else{
                                $baris2 = $cek_jam->row();
                                $cek_tgl = substr($baris2->id_pertgl,-7);
                                $cek_bln = substr($cek_tgl,0,2);
                                $cek_thn = substr($cek_bln,3,7);

                                $cek_total = $baris2->jam_tgl01 + $baris2->jam_tgl02 + $baris2->jam_tgl03 + $baris2->jam_tgl04 + $baris2->jam_tgl05 +
                                             $baris2->jam_tgl06 + $baris2->jam_tgl07 + $baris2->jam_tgl08 + $baris2->jam_tgl09 + $baris2->jam_tgl10 +
                                             $baris2->jam_tgl11 + $baris2->jam_tgl12 + $baris2->jam_tgl13 + $baris2->jam_tgl14 + $baris2->jam_tgl15 +
                                             $baris2->jam_tgl16 + $baris2->jam_tgl17 + $baris2->jam_tgl18 + $baris2->jam_tgl19 + $baris2->jam_tgl20 +
                                             $baris2->jam_tgl21 + $baris2->jam_tgl22 + $baris2->jam_tgl23 + $baris2->jam_tgl24 + $baris2->jam_tgl25 +
                                             $baris2->jam_tgl26 + $baris2->jam_tgl27 + $baris2->jam_tgl28 + $baris2->jam_tgl29 + $baris2->jam_tgl30 +
                                             $baris2->jam_tgl31 + $cek_total;
                              }

                            }

                            $total = $cek_total;
                          ?>
                                {
                                    name: '<?php echo $baris->nama_bagian; ?>',
                                    data: [<?php echo $total; ?>]
                                },
                          <?php
                            //}
                          }?>

                          ]
                    });
                 });
              </script>


              <form class="form-horizontal" action="" method="post">
                <div class="col-md-1" style="text-align:right;"><b>Pilih Proyek</b></div>
                <div class="col-md-2">
                    <select class="form-control" name="proyek">
                      <option value="0">-- Pilih Proyek --</option>
                      <?php
                      foreach ($proyek->result() as $baris_p) {
                      ?>
                        <option value="<?php echo $baris_p->id_proyek; ?>" <?php if($link_id1 == $baris_p->id_proyek){echo "selected";} ?>><?php echo $baris_p->nama_proyek; ?></option>
                      <?php
                      } ?>
                    </select>
                </div>

                <div class="col-md-1" style="text-align:right;"><b>Bulan</b></div>
                <div class="col-md-2">
                    <select class="form-control" name="bulan" required>
                      <?php
                      $bulan = date('m');
                      for ($i=1; $i <= 12; $i++) {
                        if ($i < 10) {
                          $i = '0'.$i;
                        }

                        if ($i == substr($link_id2,0,2)) {
                          $sel = "selected";
                        }else{
                          $sel = "";
                        }
                      ?>
                        <option value="<?php echo $i; ?>" <?php echo $sel; ?>><?php echo $i; ?></option>
                      <?php
                      }?>
                    </select>
                </div>

                <div class="col-md-1" style="text-align:right;"><b>Tahun</b></div>
                <div class="col-md-2">
                    <select class="form-control" name="tahun" required>
                      <?php
                      $max = date('Y');
                      for ($i=2016; $i <= $max; $i++) {
                        if ($i == substr($link_id2,3,7)) {
                          $sel = "selected";
                        }else{
                          $sel = "";
                        }
                      ?>
                        <option value="<?php echo $i; ?>" <?php echo $sel; ?>><?php echo $i; ?></option>
                      <?php
                      } ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="btncek" class="btn btn-default">Cek</button>
                </div>
              </form>

              </b></div>
              <div class="panel-body">
                <div id ="grafik"></div>
              </div>


                          <div class="col-md-12">
                            <a href="" class="btn btn-default" style="float:right;">Beranda</a>
                          </div>

            </fieldset>



          </div>

      </div>

    </div>
    <!-- /dashboard content -->
