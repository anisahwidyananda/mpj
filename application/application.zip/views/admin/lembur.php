
<script type='text/javascript'>


        $(function(){

          $('.autocomplete_userl').autocomplete({
              // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
              serviceUrl: site+'/admin/cari_user',
              // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
              onSelect: function (suggestion) {
                $('#id_userl').val(''+suggestion.id_user);
                $('#nrpl').val(''+suggestion.nrp);
                $('#bagianl').val(''+suggestion.nama_bagian);

                $('.autocompletel').autocomplete({
                    // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                    serviceUrl: site+'/admin/cari_proyek_user/'+$('#nrpl').val(),
                    // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                    onSelect: function (suggestion) {
                        $('#v_kd_pl').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                        // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                        $.ajax({
                          url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                          type : "GET",
                          beforeSend: function() {
                              $('#sel_proyekl').attr('disabled', true);
                          },
                          success: function(data){
                              $('#sel_proyekl').attr('disabled', false);
                              $('#sel_proyekl').html(data);
                              $('#sel_proyekl').focus();
                          }
                        });

                    }
                });

                $('.v_aktivitasl').autocomplete({
                    // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                    serviceUrl: site+'/admin/cari_aktivitas/'+$('#id_userl').val(),
                    // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                    onSelect: function (suggestion) {
                        $('#v_no_wbsxl').val(''+suggestion.no_wbs);
                        $('#v_no_wbsl').val(''+suggestion.no_wbs);
                    }
                });

              }
          });

          $('.autocomplete_userl').keyup(function(){
              if ($('.autocomplete_userl').val() == "") {
                $('#id_userl').val('');
                $('#nrpl').val('');
                $('#bagianl').val('');
              }
          });

            $('#caril').keyup(function(){
                if ($('#caril').val() == "") {
                    $('#v_kd_pl').val('');
                    $('#sel_proyekl').html('<option value="">-- Pilih Proyek --</option>');
                }
            });

            $('#aktivitasl').keyup(function(){
                if ($('#aktivitasl').val() == "") {
                    $('#v_no_wbsxl').val('');
                    $('#v_no_wbsl').val('');
                }
            });

        });


        counterl=0;
        function actionl(){
            counterNextl=counterl+1;
            counterNumberl=counterNextl+1;

            var datal=''+
            '<div class="col-md-12"><hr>'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Kode Proyek ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="search" name="caril[]" id="caril_'+ counterNumberl +'" class="form-control autocompletel_'+ counterNumberl +'" value="" placeholder="Ketikkan Kode Proyek ['+ counterNumberl +']" required>'+
            '        <input type="hidden" id="v_kd_pl_'+ counterNumberl +'" name="kode_proyekl[]"/>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Pilih Proyek ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '         <select class="form-control" name="id_proyekl[]" id="sel_proyekl_'+ counterNumberl +'" required>'+
            '             <option value="">-- Pilih Proyek --</option>'+
            '         </select>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Aktivitas ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="aktivitasl[]" class="form-control v_aktivitasl_'+ counterNumberl +'" value="" placeholder="Isi Aktivitas ['+ counterNumberl +']" id="aktivitasl_'+ counterNumberl +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">No. WBS ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="no_wbsxl[]" class="form-control" value="" placeholder="No. WBS ['+ counterNumberl +']" id="v_no_wbsxl_'+ counterNumberl +'" required readonly>'+
            '        <input type="hidden" name="no_wbsl[]" class="form-control" value="" placeholder="No. WBS" id="v_no_wbsl_'+ counterNumberl +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '     <label class="control-label col-lg-2">Jumlah Jam ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '       <input type="number" name="jaml[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam ['+ counterNumberl +']">'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">History Hari ini ['+ counterNumberl +']</label>'+
            '      <div class="col-lg-10">'+
            '        <textarea name="ketl[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan ['+ counterNumberl +']"></textarea>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div id="inputl'+counterNextl+'"></div>';

            document.getElementById("inputl"+counterl).innerHTML = datal;

            $('.autocompletel_'+ counterNumberl +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_proyek_user/'+$('#nrpl').val(),
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_kd_pl_'+ counterNumberl +'').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                    $.ajax({
                      url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                      type : "GET",
                      beforeSend: function() {
                          $('#sel_proyekl_'+ counterNumberl +'').attr('disabled', true);
                      },
                      success: function(data){
                          $('#sel_proyekl_'+ counterNumberl +'').attr('disabled', false);
                          $('#sel_proyekl_'+ counterNumberl +'').html(data);
                          $('#sel_proyekl_'+ counterNumberl +'').focus();
                      }
                    });

                }

            });


            $('#caril_'+ counterNumberl +'').keyup(function(){
                if ($('#caril_'+ counterNumberl +'').val() == "") {
                    $('#v_kd_pl_'+ counterNumberl +'').val('');
                }
            });

            $('.v_aktivitasl_'+ counterNumberl +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_aktivitas/'+$('#id_userl').val(),
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_no_wbsxl_'+ counterNumberl +'').val(''+suggestion.no_wbs);
                    $('#v_no_wbsl_'+ counterNumberl +'').val(''+suggestion.no_wbs);
                }
            });

            $('#aktivitasl_'+ counterNumberl +'').keyup(function(){
                if ($('#aktivitasl_'+ counterNumberl +'').val() == "") {
                    $('#v_no_wbsxl_'+ counterNumberl +'').val('');
                    $('#v_no_wbsl_'+ counterNumberl +'').val('');
                }
            });

            counterl++;
        }
</script>

<?php
$cek = $user->row();
?>
              <div class="pesanl"></div>

              <form class="form-horizontal jam_kerjal" action="#" method="post">
                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Tanggal</label>
                      <div class="col-lg-10 input-group">
                        <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                        <input type="hidden" name="model" id="model" value="auto">
                        <input type="text" name="tgll" class="form-control daterange-single" id="datepickerl" value="<?php echo date('d-m-Y'); ?>" maxlength="10" required placeholder="Masukkan Tanggal">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Nama</label>
                      <div class="col-lg-10">
                        <input type="text" name="" class="form-control autocomplete_userl" value="">
                        <input type="hidden" name="id_userl" id="id_userl" class="form-control" value="">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">NRP</label>
                      <div class="col-lg-10">
                        <input type="text" name="" id="nrpl" class="form-control" value="" readonly>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Bagian</label>
                      <div class="col-lg-10">
                        <input type="text" name=""id="bagianl" class="form-control" value="" readonly>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Kode Proyek</label>
                      <div class="col-lg-10">
                        <input type="search" name="caril[]" id="caril" class="form-control autocompletel" value="" placeholder="Ketikkan Kode Proyek" required>
                        <input type="hidden" id="v_kd_pl" name="kode_proyekl[]"/>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Pilih Proyek</label>
                      <div class="col-lg-10">
                         <select class="form-control" name="id_proyekl[]" id="sel_proyekl" required>
                             <option value="">-- Pilih Proyek --</option>
                         </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Aktivitas</label>
                      <div class="col-lg-10">
                        <input type="text" name="aktivitasl[]" class="form-control v_aktivitasl" value="" placeholder="Isi Aktivitas" id="aktivitasl" required>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">No. WBS</label>
                      <div class="col-lg-10">
                        <input type="text" name="no_wbsxl[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbsxl' required readonly>
                        <input type="hidden" name="no_wbsl[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbsl' required>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Jumlah Jam</label>
                      <div class="col-lg-10">
                        <input type="number" name="jaml[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">History Hari ini</label>
                      <div class="col-lg-10">
                        <textarea name="ketl[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan"></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                <div id="inputl0"></div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2"></label>
                      <div class="col-lg-10">
                        <hr>
                        <a href="javascript:actionl();" class="btn btn-warning">Tambah</a>
                      </div>
                    </div>
                  </div>
                </div>

                <br>
                <hr>
                <button type="submit" name="btnsimpanl" class="btn btn-primary" style="float:right;" id='btnsimpanl'>Simpan</button>

              </form>


<script type="text/javascript">
  $('.pesanl').hide();


  $(document).ready(function() {
    $('#btnsimpanl').click(function(){
       var id_userl    = $('[name="id_userl"]');
       var tgll        = $('[name="tgll"]');
       var no_wbsl     = $('[name="no_wbsl"]');
       var caril       = $('[name="caril"]');
       var aktivitasl  = $('[name="aktivitasl"]');
       var jaml        = $('[name="jaml"]');
       var ketl        = $('[name="ketl"]');

       if(id_userl.val() != '' && tgll.val() != '' && no_wbsl.val() != '' && caril.val() != '' && aktivitasl.val() != '' && jaml.val() != '' && ketl.val() != ''){

            $.ajax({
              type : 'POST',
              data :$('.jam_kerjal').serialize(),
              url  : '<?php echo base_url(); ?>users/simpan_jk_fl',
              cache: false,
              dataType: "JSON",
              beforeSend: function() {
                  $(".pesanl").hide();
                  $(".pesanl").html('');
                  $('#btnsimpanl').html('Proses... <i class="icon-spinner6 position-right"></i>');
                  $('#btnsimpanl').attr('disabled',true);
              },
              success: function(data){

                if (data.status == true) {
                  $('.jam_kerjal')[0].reset();
                  $('[name="id_proyekl[]"]').html('<option value="">-- Pilih Proyek --</option>');
                }

                $(".pesanl").show();
                $(".pesanl").html(data.pesan);

                  $('#btnsimpanl').html('Simpan');
                  $('#btnsimpanl').attr('disabled',false);

                  $('[name="tgll"]').focus();

              }
            });

       }
       //return false;
      });

  });
</script>
