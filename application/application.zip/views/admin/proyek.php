<script language="JavaScript" type="text/JavaScript">
        counter=0;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data='<div id="srow'+counter+'"><br>'+
            '<div class="form-group">'+
            '  <input type="text" name="kode_proyek[]" class="form-control" value="" placeholder="Masukkan Kode Proyek ['+ counterNumber +']" required>'+
            '</div>'+
            '<div class="form-group">'+
            '  <input type="text" name="nama_proyek[]" class="form-control" value="" placeholder="Masukkan Proyek ['+ counterNumber +']" required>'+
            '</div>'+
            '<div class="form-group">'+
            '  <input type="text" name="tgl_proyek[]" class="form-control daterange-single" value="" placeholder="Masukkan Tanggal Proyek yang dibuat ['+ counterNumber +']" required>'+
            '  <p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> Tanggal Proyek yang dibuat ['+ counterNumber +']</p>'+
            '</div>'+
            '<div class="form-group">'+
            '  <input type="text" name="nama_sekolah[]" class="form-control" value="" placeholder="Masukkan Nama Sekolah ['+ counterNumber +']" required>'+
            '</div>'+
            '<input type="button" value="Hapus" onclick="hapusElemen(\''+ counter +'\');" class="btn btn-danger" style="float:right;"/>'+
            '<hr><br>'+
            '</div><div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;
            counter++;

            $('input[name="tgl_proyek[]"]').daterangepicker({singleDatePicker: true});
        }

        function hapusElemen(idf) {
           $('#srow'+idf).remove();
          //  counter = (idf-1) + 2;
           return false;
        }
</script>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Tambah Proyek</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>
        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
            <div class="form-group">
              <label class="control-label col-lg-2"><b>Isi Proyek</b></label>
              <div class="col-lg-10">
                <div class="form-group">
                  <input type="text" name="kode_proyek[]" class="form-control" value="" placeholder="Masukkan Kode Proyek" required>
                </div>
                <div class="form-group">
                  <input type="text" name="nama_proyek[]" class="form-control" value="" placeholder="Masukkan Proyek" required>
                </div>
                <div class="form-group">
                  <input type="text" name="tgl_proyek[]" class="form-control daterange-single" value="" placeholder="Masukkan Tanggal Proyek yang dibuat" required>
                  <p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> Tanggal Proyek yang dibuat</p>
                </div>
                <div class="form-group">
                  <input type="text" name="nama_sekolah[]" class="form-control" value="" placeholder="Masukkan Nama Sekolah" required>
                </div>
                <hr>
                <div id="input0"></div>

                <a href="javascript:action();" class="btn btn-warning">Tambah</a>

              </div>
            </div>
            <hr>

            <a href="admin/t_ip" class="btn btn-default">Tabel Proyek</a>
            <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
          </form>
          <hr>

        </div>

      </div>
      <!-- /basic datatable -->
    </div>
    <!-- /dashboard content -->
