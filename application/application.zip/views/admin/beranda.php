<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-lg-12">

        <!-- Quick stats boxes -->
        <div class="row">
          <div class="col-lg-4">

            <!-- Current server load -->
            <div class="panel bg-teal-400">
              <div class="panel-body">

                <h3 class="no-margin"><?php echo $level_users->num_rows(); ?></h3>
                Jumlah User yang daftar
              </div>

              <div id="server-load"></div>
            </div>
            <!-- /current server load -->

          </div>

          <div class="col-lg-4">

            <!-- Current server load -->
            <div class="panel bg-pink-400">
              <div class="panel-body">

                <h3 class="no-margin"><?php echo $jml_proyek; ?></h3>
                Jumlah Proyek yang diinput
              </div>

              <div id="server-load"></div>
            </div>
            <!-- /current server load -->

          </div>

          <div class="col-lg-4">

            <!-- Today's revenue -->
            <div class="panel bg-blue-400">
              <div class="panel-body">

                <h3 class="no-margin"><?php echo $jml_jk; ?></h3>
                Jam Kerja Bulan ini
              </div>

              <div id="today-revenue"></div>
            </div>
            <!-- /today's revenue -->

          </div>
        </div>
        <!-- /quick stats boxes -->

        <script type="text/javascript">
          var chart1; // globally available
        $(document).ready(function() {
              chart1 = new Highcharts.Chart({
                 chart: {
                    renderTo: 'grafik',
                    type: 'column'
                 },
                 title: {
                    text: 'Grafik Jam Kerja  [<?php echo date('m-Y'); ?>]'
                 },
                 xAxis: {
                    categories: ['Bagian']
                 },
                 yAxis: {
                    title: {
                       text: ''
                    }
                 },
                      series:
                    [
                    <?php
                    $cek_total = 0;
                    foreach ($get_bagian as $baris) {
                      $cek_user = $this->db->get_where('tbl_user', "id_bagian = '$baris->id_bagian'")->result();
                      foreach ($cek_user as $baris1) {
                        $this->db->join('tbl_pertgl', 'tbl_pertgl.id_pertgl=tbl_jam_kerja.id_pertgl');
                        $this->db->where('tbl_jam_kerja.id_user', "$baris1->id_user");
                          $this->db->like('tbl_jam_kerja.id_pertgl', date('m-Y'), 'before');
                        $cek_jam = $this->db->get('tbl_jam_kerja');

                        if ($cek_jam->num_rows() == 0) {
                          $cek_total = 0;
                        }else{
                          $baris2 = $cek_jam->row();
                          $cek_tgl = substr($baris2->id_pertgl,-7);
                          $cek_bln = substr($cek_tgl,0,2);
                          $cek_thn = substr($cek_bln,3,7);

                          $cek_total = $baris2->jam_tgl01 + $baris2->jam_tgl02 + $baris2->jam_tgl03 + $baris2->jam_tgl04 + $baris2->jam_tgl05 +
                                       $baris2->jam_tgl06 + $baris2->jam_tgl07 + $baris2->jam_tgl08 + $baris2->jam_tgl09 + $baris2->jam_tgl10 +
                                       $baris2->jam_tgl11 + $baris2->jam_tgl12 + $baris2->jam_tgl13 + $baris2->jam_tgl14 + $baris2->jam_tgl15 +
                                       $baris2->jam_tgl16 + $baris2->jam_tgl17 + $baris2->jam_tgl18 + $baris2->jam_tgl19 + $baris2->jam_tgl20 +
                                       $baris2->jam_tgl21 + $baris2->jam_tgl22 + $baris2->jam_tgl23 + $baris2->jam_tgl24 + $baris2->jam_tgl25 +
                                       $baris2->jam_tgl26 + $baris2->jam_tgl27 + $baris2->jam_tgl28 + $baris2->jam_tgl29 + $baris2->jam_tgl30 +
                                       $baris2->jam_tgl31 + $cek_total;
                        }

                      }

                      $total = $cek_total;
                    ?>
                          {
                              name: '<?php echo $baris->nama_bagian; ?>',
                              data: [<?php echo $total; ?>]
                          },
                    <?php
                      //}
                    }?>

                    ]
              });
           });
        </script>


        <div class="row">
          <div class="col-lg-6">

            <div class="calendar"></div>
            <div class="box"></div>

          </div>
          <div class="col-lg-6">
            <div class="panel panel-flat col-md-12">

                <div class="panel-body">
                  <fieldset class="content-group">
                    <!-- <legend class="text-bold">Lihat Grafik Perbagian</legend> -->
                      <div id ="grafik" style="height:260px"></div>
                  </fieldset>
                </div>
            </div>
          </div>
        </div>

      </div>


    </div>
    <!-- /dashboard content -->

    <div class="row">
      <div class="col-md-12">
							<div class="panel panel-flat">
                <?php
                echo $this->session->flashdata('msg');
                ?>
								<div class="panel-heading">
									<h6 class="panel-title">Isi Jam Kerja User<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
									<div class="heading-elements">
										<ul class="icons-list">
					          		<li><a data-action="collapse"></a></li>
					          		<li><a data-action="close"></a></li>
					         	</ul>
				           </div>
								</div>

								<div class="panel-body">
                  <div class="tabbable">
										<ul class="nav nav-tabs nav-tabs-highlight nav-justified">
											<li class="active"><a href="#highlighted-justified-tab1" data-toggle="tab" aria-expanded="true">Jam Kerja User</a></li>
											<li class=""><a href="#highlighted-justified-tab2" data-toggle="tab" aria-expanded="false">Jam Lembur User</a></li>
										</ul>

										<div class="tab-content">
                      <div class="tab-pane active" id="highlighted-justified-tab1">
                        <?php $this->load->view('admin/jk'); ?>
											</div>

											<div class="tab-pane" id="highlighted-justified-tab2">
                        <?php $this->load->view('admin/lembur'); ?>
											</div>
										</div>

									</div>
								</div>
							</div>
			</div>
    </div>
