<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="panel panel-flat">

          <div class="panel-body">
            <?php
            echo $this->session->flashdata('msg');
            ?>
            <fieldset class="content-group">
              <legend class="text-bold">Edit User</legend>

            <form class="form-horizontal" action="" method="post">
              <div class="form-group">
                <label class="control-label col-lg-2">Nama</label>
                <div class="col-lg-10">
                  <input type="text" name="nama_lengkap" class="form-control" value="<?php echo $e_user->nama_lengkap; ?>" required>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">NRP</label>
                <div class="col-lg-10">
                  <input type="text" name="nrp" class="form-control" value="<?php echo $e_user->nrp; ?>" required>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Bagian</label>
                <div class="col-lg-10">
                  <select class="form-control" name="bagian" required>
                    <?php
                    foreach ($bagian as $baris) {
                        if ($baris->id_bagian == $e_user->id_bagian) {
                          $aktif = "select";
                        }else{
                          $aktif = "";
                        }
                    ?>
                        <option value="<?php echo $baris->id_bagian; ?>" selected="<?php echo $aktif; ?>"><?php echo $baris->nama_bagian; ?></option>
                    <?php
                    } ?>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Email</label>
                <div class="col-lg-10">
                  <input type="email" name="email" class="form-control" value="<?php echo $e_user->email; ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Username</label>
                <div class="col-lg-10">
                  <input type="text" name="username" class="form-control" value="<?php echo $e_user->username; ?>" readonly>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-lg-2">Password</label>
                <div class="col-lg-10">
                  <input type="text" name="password" class="form-control" value="" placeholder="Password User">
                  <i>*Abaikan jika tidak ingin merubah password</i>
                </div>
              </div>

              <br>
              <table width="100%">
                  <tr>
                    <td width="100">Tanggal Daftar</td>
                    <td>: <?php echo $e_user->tgl_daftar; ?></td>
                  </tr>
                  <tr>
                    <td width="100">Terakhir Login</td>
                    <td>: <?php echo $e_user->terakhir_login; ?></td>
                  </tr>
              </table>
              <hr>
              <a href="admin/lihat_users" class="btn btn-default"><< Kembali</a>
              <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Update</button>
              <?php
              if ($e_user->status != 'terdaftar') {?>
                  <button type="submit" name="btnver" class="btn btn-warning" style="float:right;margin-right:10px;" onclick="return confirm('Apakah anda yakin ingin verifikasi user manual? ')">Verifikasi User</button>
              <?php
              }else{ ?>
                <button type="submit" name="btnunver" class="btn btn-warning" style="float:right;margin-right:10px;" onclick="return confirm('Apakah anda yakin ingin batalkan verifikasi user? ')"> Batalkan Verifikasi User</button>
              <?php
              } ?>
            </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->
