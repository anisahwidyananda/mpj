<!-- <script type='text/javascript' src='assets/autocomplete/js/jquery-1.8.2.min.js'></script> -->
<script src="assets/js/jquery-ui.js"></script>
<script>
$( function() {
  $( "#datepicker" ).datepicker();
  $( "#datepickerl" ).datepicker();
} );
</script>
<script type='text/javascript' src='assets/autocomplete/js/jquery.autocomplete.js'></script>

<!-- Memanggil file .css untuk style saat data dicari dalam filed -->
<link href='assets/autocomplete/js/jquery.autocomplete.css' rel='stylesheet' />

<!-- Memanggil file .css autocomplete_ci/assets/css/default.css -->
<link href='assets/autocomplete/css/default.css' rel='stylesheet' />

<script type='text/javascript'>
        var site = "<?php echo site_url();?>";


        $(function(){
            $('.autocomplete_user').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_user',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                  $('#id_user').val(''+suggestion.id_user);
                  $('#nrp').val(''+suggestion.nrp);
                  $('#bagian').val(''+suggestion.nama_bagian);

                  $('.autocomplete').autocomplete({
                      // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                      serviceUrl: site+'/admin/cari_proyek_user/'+$('#nrp').val(),
                      // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                      onSelect: function (suggestion) {
                          $('#v_kd_p').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                          // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                          $.ajax({
                            url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                            type : "GET",
                            beforeSend: function() {
                                $('#sel_proyek').attr('disabled', true);
                            },
                            success: function(data){
                                $('#sel_proyek').attr('disabled', false);
                                $('#sel_proyek').html(data);
                                $('#sel_proyek').focus();
                            }
                          });

                      }
                  });


                  $('.v_aktivitas').autocomplete({
                      // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                      serviceUrl: site+'/admin/cari_aktivitas/'+$('#id_user').val(),
                      // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                      onSelect: function (suggestion) {
                          $('#v_no_wbsx').val(''+suggestion.no_wbs);
                          $('#v_no_wbs').val(''+suggestion.no_wbs);
                      }
                  });

                }
            });

            $('.autocomplete_user').keyup(function(){
                if ($('.autocomplete_user').val() == "") {
                  $('#id_user').val('');
                  $('#nrp').val('');
                  $('#bagian').val('');
                }
            });


            $('#cari').keyup(function(){
                if ($('#cari').val() == "") {
                    $('#v_kd_p').val('');
                    $('#sel_proyek').html('<option value="">-- Pilih Proyek --</option>');
                }
            });


            $('#aktivitas').keyup(function(){
                if ($('#aktivitas').val() == "") {
                    $('#v_no_wbsx').val('');
                    $('#v_no_wbs').val('');
                }
            });

        });


        counter=0;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data=''+
            '<div class="col-md-12"><hr>'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Kode Proyek ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="search" name="cari[]" id="cari_'+ counterNumber +'" class="form-control autocomplete_'+ counterNumber +'" value="" placeholder="Ketikkan Kode Proyek ['+ counterNumber +']" required>'+
            '        <input type="hidden" id="v_kd_p_'+ counterNumber +'" name="kode_proyek[]"/>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Pilih Proyek ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '         <select class="form-control" name="id_proyek[]" id="sel_proyek_'+ counterNumber +'" required>'+
            '             <option value="">-- Pilih Proyek --</option>'+
            '         </select>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">Aktivitas ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="aktivitas[]" class="form-control v_aktivitas_'+ counterNumber +'" value="" placeholder="Isi Aktivitas ['+ counterNumber +']" id="aktivitas_'+ counterNumber +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">No. WBS ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <input type="text" name="no_wbsx[]" class="form-control" value="" placeholder="No. WBS ['+ counterNumber +']" id="v_no_wbsx_'+ counterNumber +'" required readonly>'+
            '        <input type="hidden" name="no_wbs[]" class="form-control" value="" placeholder="No. WBS" id="v_no_wbs_'+ counterNumber +'" required>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '     <label class="control-label col-lg-2">Jumlah Jam ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '       <input type="number" name="jam[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam ['+ counterNumber +']">'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div class="col-md-12">'+
            '  <div class="col-md-12">'+
            '    <div class="form-group">'+
            '      <label class="control-label col-lg-2">History Hari ini ['+ counterNumber +']</label>'+
            '      <div class="col-lg-10">'+
            '        <textarea name="ket[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan ['+ counterNumber +']"></textarea>'+
            '      </div>'+
            '    </div>'+
            '  </div>'+
            '</div>'+
            '<div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;

            $('.autocomplete_'+ counterNumber +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_proyek_user/'+$('#nrp').val(),
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_kd_p_'+ counterNumber +'').val(''+suggestion.kode_proyek); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan

                    $.ajax({
                      url  : "<?php echo site_url('users/sel_proyek_user/')?>"+suggestion.id_proyek,
                      type : "GET",
                      beforeSend: function() {
                          $('#sel_proyek_'+ counterNumber +'').attr('disabled', true);
                      },
                      success: function(data){
                          $('#sel_proyek_'+ counterNumber +'').attr('disabled', false);
                          $('#sel_proyek_'+ counterNumber +'').html(data);
                          $('#sel_proyek_'+ counterNumber +'').focus();
                      }
                    });

                }

            });


            $('#cari_'+ counterNumber +'').keyup(function(){
                if ($('#cari_'+ counterNumber +'').val() == "") {
                    $('#v_kd_p_'+ counterNumber +'').val('');
                }
            });

            $('.v_aktivitas_'+ counterNumber +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_aktivitas/'+$('#id_user').val(),
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_no_wbsx_'+ counterNumber +'').val(''+suggestion.no_wbs);
                    $('#v_no_wbs_'+ counterNumber +'').val(''+suggestion.no_wbs);
                }
            });

            $('#aktivitas_'+ counterNumber +'').keyup(function(){
                if ($('#aktivitas_'+ counterNumber +'').val() == "") {
                    $('#v_no_wbsx_'+ counterNumber +'').val('');
                    $('#v_no_wbs_'+ counterNumber +'').val('');
                }
            });

            counter++;
        }
</script>

<?php
$cek = $user->row();
?>
<!-- Main content -->


            <div class="pesan"></div>

              <form class="form-horizontal jam_kerja" action="#" method="post">
                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Tanggal</label>
                      <div class="col-lg-10 input-group">
                        <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                        <input type="hidden" name="mode" id="mode" value="auto">
                        <input type="text" name="tgl" class="form-control daterange-single" id="datepicker" value="<?php echo date('d-m-Y'); ?>" maxlength="10" required placeholder="Masukkan Tanggal">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Nama</label>
                      <div class="col-lg-10">
                        <input type="text" name="" class="form-control autocomplete_user" value="">
                        <input type="hidden" name="id_user" id="id_user" class="form-control" value="">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">NRP</label>
                      <div class="col-lg-10">
                        <input type="text" name="" id="nrp" class="form-control" value="" readonly>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Bagian</label>
                      <div class="col-lg-10">
                        <input type="text" name=""id="bagian" class="form-control" value="" readonly>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Kode Proyek</label>
                      <div class="col-lg-10">
                        <input type="search" name="cari[]" id="cari" class="form-control autocomplete" value="" placeholder="Ketikkan Kode Proyek" required>
                        <input type="hidden" id="v_kd_p" name="kode_proyek[]"/>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Pilih Proyek</label>
                      <div class="col-lg-10">
                         <select class="form-control" name="id_proyek[]" id="sel_proyek" required>
                             <option value="">-- Pilih Proyek --</option>
                         </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Aktivitas</label>
                      <div class="col-lg-10">
                        <input type="text" name="aktivitas[]" class="form-control v_aktivitas" value="" placeholder="Isi Aktivitas" id="aktivitas" required>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">No. WBS</label>
                      <div class="col-lg-10">
                        <input type="text" name="no_wbsx[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbsx' required readonly>
                        <input type="hidden" name="no_wbs[]" class="form-control" value="" placeholder="No. WBS" id='v_no_wbs' required>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">Jumlah Jam</label>
                      <div class="col-lg-10">
                        <input type="number" name="jam[]" class="form-control" value="" required maxlength="2" placeholder="Isi Berapa Jam">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2">History Hari ini</label>
                      <div class="col-lg-10">
                        <textarea name="ket[]" rows="4" cols="80" class="form-control" placeholder="Isi History Apa saja yang dikerjakan"></textarea>
                      </div>
                    </div>
                  </div>
                </div>

                <div id="input0"></div>

                <div class="col-md-12">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-lg-2"></label>
                      <div class="col-lg-10">
                        <hr>
                        <a href="javascript:action();" class="btn btn-warning">Tambah</a>
                      </div>
                    </div>
                  </div>
                </div>

                <br>
                <hr>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;" id='btnsimpan'>Simpan</button>

              </form>




<script type="text/javascript">
  $('.pesan').hide();

  $(document).ready(function() {
    $('#btnsimpan').click(function(){
       var id_user    = $('[name="id_user"]');
       var tgl        = $('[name="tgl"]');
       var no_wbs     = $('[name="no_wbs"]');
       var cari       = $('[name="cari"]');
       var aktivitas  = $('[name="aktivitas"]');
       var jam        = $('[name="jam"]');
       var ket        = $('[name="ket"]');

       if(id_user.val() != '' && tgl.val() != '' && no_wbs.val() != '' && cari.val() != '' && aktivitas.val() != '' && jam.val() != '' && ket.val() != ''){

            $.ajax({
              type : 'POST',
              data :$('.jam_kerja').serialize(),
              url  : '<?php echo base_url(); ?>users/simpan_jk',
              cache: false,
              dataType: "JSON",
              beforeSend: function() {
                  $(".pesan").hide();
                  $(".pesan").html('');
                  $('#btnsimpan').html('Proses... <i class="icon-spinner6 position-right"></i>');
                  $('#btnsimpan').attr('disabled',true);
              },
              success: function(data){

                if (data.status == true) {
                  $('.jam_kerja')[0].reset();
                  $('[name="id_proyek[]"]').html('<option value="">-- Pilih Proyek --</option>');
                }

                $(".pesan").show();
                $(".pesan").html(data.pesan);

                  $('#btnsimpan').html('Simpan');
                  $('#btnsimpan').attr('disabled',false);

                  $('[name="tgl"]').focus();

              }
            });

       }
       //return false;
      });

  });
</script>
