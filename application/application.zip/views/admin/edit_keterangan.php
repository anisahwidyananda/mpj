<script type="text/javascript">
var site = "<?php echo site_url();?>";

$(function(){
    $('.autocomplete').autocomplete({
        // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
        serviceUrl: site+'/admin/cari_kode_proyek',
        // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
        onSelect: function (suggestion) {
            $('#v_p').val(''+suggestion.nama_proyek); // membuat id 'v_nim' untuk ditampilkan
            $('#v_id_p').val(''+suggestion.id_proyek);
            // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
        }
    });


    $('#cari').keyup(function(){
        if ($('#cari').val() == "") {
            $('#v_p').val('');
            $('#v_id_p').val('');
        }
    });

});
</script>

<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-md-3"></div>
      <div class="panel panel-flat col-md-6">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Edit Keterangan</legend>

              <form class="form-horizontal" action="" method="post">
                <div class="form-group">
                  <!-- <label class="control-label col-lg-2">Nama Bagian</label> -->
                  <div class="col-lg-12">
                    <input type="search" name="cari[]" id="cari" class="form-control autocomplete" placeholder="Ketikkan Kode Proyek" value="<?php echo $e_ket->kode_proyek; ?>" required>
                    <input type="text" id="v_p" class="form-control" placeholder="Nama Proyek" value="<?php echo $e_ket->nama_proyek; ?>" readonly required/>
                    <input type="hidden" id="v_id_p" name="id_proyek" value="<?php echo $e_ket->id_proyek; ?>" required/>
                  </div>
                </div>
                <hr>
                <a href="admin/keterangan" class="btn btn-default"><< Kembali</a>
                <button type="submit" name="btnupdate" class="btn btn-success" style="float:right;">Update</button>
              </form>
            </fieldset>

          </div>

      </div>
    </div>
    <!-- /dashboard content -->
