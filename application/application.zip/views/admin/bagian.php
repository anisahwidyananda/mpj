<script language="JavaScript" type="text/JavaScript">
        counter=2;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data='<div id="srow'+counter+'">'+
            '<div class="form-group">'+
            '  <input type="text" name="nama_bagian[]" class="form-control" value="" placeholder="Masukkan nama bagian ['+ counterNumber +']">'+
            '  <input type="button" value="Hapus" onclick="hapusElemen(\''+ counter +'\');" class="btn btn-danger" style="float:right;"/>'+
            '</div>'+
            '<hr>'+
            '</div><div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;
            counter++;
        }

        function hapusElemen(idf) {
           $('#srow'+idf).remove();
          //  counter = (idf-1) + 2;
           return false;
        }
</script>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Tambah Bagian</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>
        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
            <div class="form-group">
              <label class="control-label col-lg-2"><b>Nama Bagian</b></label>
              <div class="col-lg-10">
                <input type="text" name="nama_bagian[]" class="form-control" value="" placeholder="Masukkan nama bagian [1]" required>
                <hr>
                <div id="input0"></div>

                <input type="text" name="nama_bagian[]" class="form-control" value="" placeholder="Masukkan nama bagian [2]">
                <hr>
                <div id="input1"></div>

                <input type="text" name="nama_bagian[]" class="form-control" value="" placeholder="Masukkan nama bagian [3]">
                <hr>
                <div id="input2"></div>

                <a href="javascript:action();" class="btn btn-warning">Tambah</a>
              </div>
            </div>
            <hr>
            <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
            <br><br>
          </form>

        </div>
      </div>
      <!-- /basic datatable -->
    </div>



  <div class="row">
            <!-- Basic datatable -->
    <div class="panel panel-flat">
      <div class="panel-heading">
        <h5 class="panel-title">Tabel Bagian</h5>
        <div class="heading-elements">
          <ul class="icons-list">
            <li><a data-action="collapse"></a></li>
          </ul>
        </div>

        </div>
        <hr style="margin:0px;">
        <div class="panel-body">
          <table class="table datatable-basic" width="100%">
            <thead>
              <tr>
                <th width="30px;">No.</th>
                <th>Nama Bagian</th>
                <th width="200">Total User</th>
                <th class="text-center" width="230"></th>
              </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($bagian as $baris) {
                  $total_user = $this->db->get_where('tbl_user', array('id_bagian' => $baris->id_bagian))->num_rows();
                ?>
                  <tr>
                    <td><?php echo $no.'.'; ?></td>
                    <td><?php echo $baris->nama_bagian; ?></td>
                    <td><?php echo number_format($total_user,0,",","."); ?></td>
                    <td>
                      <a href="admin/bagian/p_bag/<?php echo $baris->id_bagian; ?>" class="btn btn-info">Lihat</a>
                      <a href="admin/bagian/e/<?php echo $baris->id_bagian; ?>" class="btn btn-success">Edit</a>
                      <a href="admin/bagian/h/<?php echo $baris->id_bagian; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                    </td>
                  </tr>
                <?php
                $no++;
                } ?>
            </tbody>
          </table>

        </div>
      </div>
      <!-- /basic datatable -->
    </div>
    <!-- /dashboard content -->
