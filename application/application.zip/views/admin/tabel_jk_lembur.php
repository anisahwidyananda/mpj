<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">

      <div class="col-md-4">
        <div class="panel panel-flat">

            <div class="panel-body">
              <fieldset class="content-group">
                <legend class="text-bold">Lihat Tabel Jam Kerja Lembur Per User</legend>

                <b>Pilih User:</b> <br>
                <?php
                $bln = date('m');
                $thn = date('Y');
                $bln_thn = "$bln$thn";
                foreach ($t_user as $baris) {
                ?>
                  <div class="col-md-12">
                    <a href="admin/tabel_jk_lembur/<?php echo $baris->id_user ?>/user" class="btn btn-primary btn-lg" style="width:100%;margin:5px;"><?php echo ucwords($baris->nama_lengkap); ?></a>
                  </div>
                <?php
                } ?>
              </fieldset>
              <div class="col-md-12">
                <!-- <a href="" class="btn btn-default" style="float:right;">Beranda</a> -->
              </div>
            </div>

        </div>
      </div>

      <div class="col-md-4">
        <div class="panel panel-flat">

            <div class="panel-body">
              <fieldset class="content-group">
                <legend class="text-bold">Lihat Tabel Jam Kerja Lembur Per Proyek</legend>

                <b>Pilih Proyek:</b> <br>
                <?php
                $bln = date('m');
                $thn = date('Y');
                $bln_thn = "$bln$thn";
                foreach ($proyek as $baris) {
                ?>
                  <div class="col-md-12">
                    <a href="admin/tabel_jk_lembur/<?php echo $baris->id_proyek ?>/proyek" class="btn btn-primary btn-lg" style="width:100%;margin:5px;"><?php echo $baris->nama_proyek; ?></a>
                  </div>
                <?php
                } ?>
              </fieldset>
              <div class="col-md-12">
                <!-- <a href="" class="btn btn-default" style="float:right;">Beranda</a> -->
              </div>
            </div>

        </div>
      </div>

      <div class="col-md-4">
        <div class="panel panel-flat">

          <div class="panel-body">
            <fieldset class="content-group">
              <legend class="text-bold">Lihat Tabel Jam Kerja Lembur Per Bagian</legend>

              <b>Pilih Bagian:</b> <br>
              <?php
              $bln = date('m');
              $thn = date('Y');
              $bln_thn = "$bln$thn";
              foreach ($bagian as $baris) {
              ?>
                <div class="col-md-12">
                  <a href="admin/tabel_jk_lembur/<?php echo $baris->id_bagian ?>/bagian" class="btn btn-primary btn-lg" style="width:100%;margin:5px;"><?php echo $baris->nama_bagian; ?></a>
                </div>
              <?php
              } ?>
            </fieldset>
            <div class="col-md-12">
              <!-- <a href="" class="btn btn-default" style="float:right;">Beranda</a> -->
            </div>
          </div>

        </div>
      </div>


    </div>
    <!-- /dashboard content -->
