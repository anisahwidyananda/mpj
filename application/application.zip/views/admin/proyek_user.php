

<script type='text/javascript'>
        var site = "<?php echo site_url();?>";
        $(function(){
            $('.autocomplete').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_nrp',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_nrp').val(''+suggestion.nrp); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                }
            });

            $('.autocomplete_2').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_nrp',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_nrp_2').val(''+suggestion.nrp); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                }
            });

            $('.autocomplete_3').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_nrp',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_nrp_3').val(''+suggestion.nrp); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                }
            });
        });
</script>


<script language="JavaScript" type="text/JavaScript">
        counter=2;
        function action(){
            counterNext=counter+1;
            counterNumber=counterNext+1;

            var data='<div id="srow'+counter+'">'+
            '<div class="form-group">'+
            '  <input type="search" name="cari[]" class="form-control autocomplete_'+ counterNumber +'" value="" placeholder="'+ counterNumber +'. Ketikkan NRP">'+
            '  <input type="hidden" id="v_nrp_'+ counterNumber +'" name="nrp[]"/>'+
            '  <input type="button" value="Hapus" onclick="hapusElemen(\''+ counter +'\');" class="btn btn-danger" style="float:right;"/>'+
            '</div>'+
            '</div><div id="input'+counterNext+'"></div>';

            document.getElementById("input"+counter).innerHTML = data;

            $('.autocomplete_'+ counterNumber +'').autocomplete({
                // serviceUrl berisi URL ke controller/fungsi yang menangani request kita
                serviceUrl: site+'/admin/cari_nrp',
                // fungsi ini akan dijalankan ketika user memilih salah satu hasil request
                onSelect: function (suggestion) {
                    $('#v_nrp_'+ counterNumber +'').val(''+suggestion.nrp); // membuat id 'v_nim' untuk ditampilkan
                    // $('#v_nama_lengkap').val(''+suggestion.nama_lengkap); // membuat id 'v_jurusan' untuk ditampilkan
                }
            });

            counter++;
        }

        function hapusElemen(idf) {
           $('#srow'+idf).remove();
          //  counter = (idf-1) + 2;
           return false;
        }
</script>
<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="col-md-3"></div>

    <div class="col-md-6">

    <div class="row">
      <!-- Basic datatable -->
      <div class="panel panel-flat">
        <div class="panel-heading">
          <h5 class="panel-title">Tambah Proyek User</h5>
          <div class="heading-elements">
            <ul class="icons-list">
              <li><a data-action="collapse"></a></li>
            </ul>
          </div>

                    <?php
                    echo $this->session->flashdata('msg');
                    ?>
        </div>

        <hr style="margin:0px;">
        <div class="panel-body">
          <form class="form-horizontal" action="" method="post">
              <label class="control-label col-lg-12"><p class="help-block "><i class="glyphicon glyphicon-info-sign"></i> <b>Keterangan :</b> Tambahkan User pada Proyek <b><?php echo ucwords($nama_proyek); ?></b></p></label>
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="search" name="cari[]" class="form-control autocomplete" value="" placeholder="1. Ketikkan NRP" required>
                  <input type="hidden" id="v_nrp" name="nrp[]"/>
                </div>
                <div class="form-group">
                  <input type="search" name="cari[]" class="form-control autocomplete_2" value="" placeholder="2. Ketikkan NRP">
                  <input type="hidden" id="v_nrp_2" name="nrp[]"/>
                </div>
                <div class="form-group">
                  <input type="search" name="cari[]" class="form-control autocomplete_3" value="" placeholder="3. Ketikkan NRP">
                  <input type="hidden" id="v_nrp_3" name="nrp[]"/>
                </div>
                <div id="input2"></div>
                <a href="javascript:action();" class="btn btn-warning">Tambah</a>
                <br>
              </div>

              <div class="col-lg-12">
              <hr>
                <a href="admin/t_ip" class="btn btn-default">Kembali</a>
                <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
              </div>
          </form>
        </div>
      </div>
      <!-- /basic datatable -->
    </div>

    </div>
    <!-- /dashboard content -->
