<!-- Main content -->
<div class="content-wrapper">
  <br><br><br>
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-md-3"></div>
      <div class="panel panel-flat col-md-6">

          <div class="panel-body">
            <?php
            echo $this->session->flashdata('msg');
            ?>
            <fieldset class="content-group">
              <legend class="text-bold">Isi Aktivitas User - Pilih Bagian</legend>

              <?php
              $thn = date('Y');
              foreach ($bagian as $baris) {
              ?>
                <div class="col-md-12">
                  <a href="admin/aktivitas/t/<?php echo $baris->id_bagian; ?>" class="btn btn-primary btn-lg" style="width:100%;margin:5px;"><?php echo $baris->nama_bagian; ?></a>
                </div>
              <?php
              } ?>
            </fieldset>

          </div>

      </div>

    </div>
    <!-- /dashboard content -->

    <div class="row">
      <div class="col-md-1"></div>
      <div class="panel panel-flat col-md-10">
          <div class="panel-heading">
            <h5 class="panel-title">Tabel Aktivitas</h5>
            <div class="heading-elements">
              <ul class="icons-list">
                <li><a data-action="collapse"></a></li>
              </ul>
            </div>
          </div>
          <hr style="margin:0px;">
          <div class="panel-body">

            <table class="table datatable-basic" width="100%">
              <thead>
                <tr>
                  <th width="30px;">No.</th>
                  <th>No WBS</th>
                  <th>Nama Aktivitas</th>
                  <th>Nama Bagian</th>
                  <th class="text-center" width="230"></th>
                </tr>
              </thead>
              <tbody>
                  <?php
                  $no = 1;
                  foreach ($aktivitas as $baris) {
                  ?>
                    <tr>
                      <td><?php echo $no.'.'; ?></td>
                      <td><?php echo $baris->no_wbs; ?></td>
                      <td><?php echo $baris->nama_aktivitas; ?></td>
                      <td><?php echo $baris->nama_bagian; ?></td>
                      <td>
                        <a href="admin/aktivitas/e/<?php echo $baris->id_aktivitas; ?>" class="btn btn-success">Edit</a>
                        <a href="admin/aktivitas/h/<?php echo $baris->id_aktivitas; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin?')">Hapus</a>
                      </td>
                    </tr>
                  <?php
                  $no++;
                  } ?>
              </tbody>
            </table>

          </div>

      </div>

    </div>
