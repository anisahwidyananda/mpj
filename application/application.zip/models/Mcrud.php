<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mcrud extends CI_Model {

	var $tbl_users				 = 'tbl_user';
	// var $tbl_kat_proyek		 = 'tbl_kat_proyek';
	var $tbl_proyek		 	   = 'tbl_proyek';
	var $tbl_jam_kerja		 = 'tbl_jam_kerja';
	var $tbl_bagian		 		 = 'tbl_bagian';
	var $tbl_pertgl		 		 = 'tbl_pertgl';

	//Sent mail
			public function sent_mail($username, $email, $aksi)
			{
				$email_saya = "";
				$pass_saya  = "";

				//konfigurasi email
				$config = array();
				$config['charset'] = 'utf-8';
				$config['useragent'] = 'jkp.ordodev.com';
				$config['protocol']= "smtp";
				$config['mailtype']= "html";
				$config['smtp_host']= "ssl://smtp.gmail.com";
				$config['smtp_port']= "465";
				$config['smtp_timeout']= "465";
				$config['smtp_user']= "$email_saya";
				$config['smtp_pass']= "$pass_saya";
				$config['crlf']="\r\n";
				$config['newline']="\r\n";

				$config['wordwrap'] = TRUE;
				//memanggil library email dan set konfigurasi untuk pengiriman email

				$this->email->initialize($config);
				//$ipaddress = get_real_ip(); //untuk mendeteksi alamat IP

				date_default_timezone_set('Asia/Jakarta');
				$waktu 	  = date('Y-m-d H:i:s');
				$tgl 			= date('Y-m-d');

				$id = md5("$email * $tgl");

				if ($aksi == 'reg') {
						$link			= base_url().'web/verify';
						$pesan    = "Hello $username,
													<br /><br />
													Welcome to Jam Kerja Proyek!<br/>
													Untuk melengkapi pendaftaran Anda, silahkan klik link berikut<br/>
													<br /><br />
													<b><a href='$link/$id/$username'>Klik Aktivasi disini :)</a></b>
													<br /><br />
													Terimakasih ^_^,
													";
						$subject = 'Aktivasi Akun | JKP';

				}elseif ($aksi == 'lp') {
						$link			= base_url().'web/konfirm_pass';
						$pesan    = "Hello $username,
													<br /><br />
													Welcome to Jam Kerja Proyek!<br/>
													Untuk membuat password baru, silahkan klik link berikut<br/>
													<br /><br />
													<b><a href='$link/$id/$username'>Klik disini untuk merubah Password baru :)</a></b>
													<br /><br />
													Terimakasih ^_^,
													";
						 $subject = 'Lupa Password | JKP';
				}

				$this->email->from("$email_saya");
				$this->email->to("$email");
				$this->email->subject($subject);
				$this->email->message($pesan);
			}
	//End Sent mail


	public function get_users()
	{
			$this->db->from($this->tbl_users);
			$query = $this->db->get();

			return $query;
	}

	public function get_users_daftar()
	{
			$this->db->from($this->tbl_users);
			$this->db->where('status','terdaftar');
			$query = $this->db->get();

			return $query;
	}

	public function get_bagian()
	{
			$this->db->from($this->tbl_bagian);
			$query = $this->db->get();

			return $query->result();
	}

	public function get_level_users()
	{
			$this->db->from($this->tbl_users);
			$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_user.id_bagian');
			$this->db->where('tbl_user.level', 'user');
			$query = $this->db->get();

			return $query;
	}

	public function get_countproyek()
	{
			$this->db->from($this->tbl_proyek);
			$query = $this->db->get();

			return $query->num_rows();
	}

	public function get_countjk()
	{
			$this->db->from($this->tbl_jam_kerja);
			$query = $this->db->get();

			return $query->num_rows();
	}

	public function get_users_by_un($id)
	{
				$this->db->from($this->tbl_users);
				$this->db->where('username',$id);
				$query = $this->db->get();

				return $query;
	}

	public function get_users_by_nrp($id)
	{
				$this->db->from($this->tbl_users);
				$this->db->where('nrp',$id);
				$query = $this->db->get();

				return $query;
	}

	public function get_level_users_by_id($id)
	{
			$this->db->from($this->tbl_users);
			$this->db->join('tbl_bagian', 'tbl_bagian.id_bagian=tbl_user.id_bagian');
			$this->db->where('tbl_user.level', 'user');
			$this->db->where('tbl_user.id_user', $id);
			$query = $this->db->get();

			return $query->row();
	}

	public function save_user($data)
	{
		$this->db->insert($this->tbl_users, $data);
		return $this->db->insert_id();
	}

	public function update_user($where, $data)
	{
		$this->db->update($this->tbl_users, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_user_by_id($id)
	{
		$this->db->where('id_user', $id);
		$this->db->delete($this->tbl_users);
	}

	// public function get_kat_proyek()
	// {
	// 			$this->db->from($this->tbl_kat_proyek);
	// 			$query = $this->db->get();
	//
	// 			return $query->result();
	// }
	//
	// public function get_kat_proyek_by_id($id)
	// {
	// 			$this->db->from($this->tbl_kat_proyek);
	// 			$this->db->where('id_kat_proyek',$id);
	// 			$query = $this->db->get();
	//
	// 			return $query->row();
	// }
	//
	// public function save_kat_proyek($data)
	// {
	// 	$this->db->insert($this->tbl_kat_proyek, $data);
	// 	return $this->db->insert_id();
	// }
	//
	// public function update_kat_proyek($where, $data)
	// {
	// 	$this->db->update($this->tbl_kat_proyek, $data, $where);
	// 	return $this->db->affected_rows();
	// }
	//
	// public function delete_kat_proyek_by_id($id)
	// {
	// 	$this->db->where('id_kat_proyek', $id);
	// 	$this->db->delete($this->tbl_kat_proyek);
	// }




	public function get_bagian_by_id($id)
	{
				$this->db->from($this->tbl_bagian);
				$this->db->where('id_bagian',$id);
				$query = $this->db->get();

				return $query->row();
	}

	public function save_bagian($data)
	{
		$this->db->insert($this->tbl_bagian, $data);
		return $this->db->insert_id();
	}

	public function update_bagian($where, $data)
	{
		$this->db->update($this->tbl_bagian, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_bagian_by_id($id)
	{
		$this->db->where('id_bagian', $id);
		$this->db->delete($this->tbl_bagian);
	}


	// public function get_proyek_by_id($id)
	// {
	// 		$this->db->from($this->tbl_proyek);
	// 		$this->db->join('tbl_user', 'tbl_user.id_user=tbl_proyek.id_user');
	// 		$this->db->join('tbl_kat_proyek', 'tbl_kat_proyek.id_kat_proyek=tbl_proyek.id_kat_proyek');
	// 		$this->db->where('tbl_user.id_user', $id);
	// 		$this->db->where('tbl_user.level', 'user');
	// 		$query = $this->db->get();
	//
	// 		return $query;
	// }

	// public function get_proyek_by_un($id)
	// {
	// 		$this->db->from($this->tbl_proyek);
	// 		$this->db->join('tbl_user', 'tbl_user.id_user=tbl_proyek.id_user');
	// 		$this->db->join('tbl_kat_proyek', 'tbl_kat_proyek.id_kat_proyek=tbl_proyek.id_kat_proyek');
	// 		$this->db->where('tbl_user.username', $id);
	// 		$this->db->where('tbl_user.level', 'user');
	// 		$query = $this->db->get();
	//
	// 		return $query->result();
	// }

	public function save_proyek($data)
	{
		$this->db->insert($this->tbl_proyek, $data);
		return $this->db->insert_id();
	}

	public function delete_proyek_by_id($id)
	{
		$this->db->where('id_user', $id);
		$this->db->delete($this->tbl_proyek);
	}

	public function delete_proyek_by_id_pr($id, $pr)
	{
		$this->db->where('id_user', $id);
		$this->db->where('id_kat_proyek', $pr);
		$this->db->delete($this->tbl_proyek);
	}


	public function get_jam_kerja_by_id($id, $proyek)
	{
				$this->db->from($this->tbl_jam_kerja);
				$this->db->where('id_user',$id);
				//$this->db->where('tgl',$tgl);
				$this->db->where('id_proyek',$proyek);
				//$this->db->where('mode',$mode);
				$query = $this->db->get();

				return $query;
	}

	public function save_jam_kerja($data)
	{
		$this->db->insert($this->tbl_jam_kerja, $data);
		return $this->db->insert_id();
	}


	public function get_jam_proyek($id, $blnthn)
	{
			$bln = substr($blnthn,0,2);
			$thn = substr($blnthn,2,6);
			$bln_thn = "$id-$bln-$thn";

			$this->db->from($this->tbl_jam_kerja);
			$this->db->join($this->tbl_users, 'tbl_user.id_user=tbl_jam_kerja.id_user');
			$this->db->join($this->tbl_pertgl, 'tbl_pertgl.id_pertgl=tbl_jam_kerja.id_pertgl');
			$this->db->where('tbl_jam_kerja.id_proyek',$id);
			$this->db->like('tbl_jam_kerja.id_pertgl',$bln_thn, 'before');
			$query = $this->db->get();

			return $query->result();
	}

	public function save_pertgl($data)
	{
		$this->db->insert($this->tbl_pertgl, $data);
		return $this->db->insert_id();
	}

	public function update_pertgl($where, $data)
	{
		$this->db->update($this->tbl_pertgl, $data, $where);
		return $this->db->affected_rows();
	}

	public function total_bagian_pertahun($id,$thn)
	{
			$this->db->from($this->tbl_jam_kerja);
			$this->db->join($this->tbl_users, 'tbl_user.id_user=tbl_jam_kerja.id_user');
			$this->db->join($this->tbl_bagian, 'tbl_bagian.id_bagian=tbl_user.id_bagian');
			$this->db->join($this->tbl_pertgl, 'tbl_pertgl.id_pertgl=tbl_jam_kerja.id_pertgl');
			$this->db->where('tbl_bagian.id_bagian',$id);
			$this->db->like('tbl_jam_kerja.id_pertgl',$thn);
			$query = $this->db->get();

			return $query->result();
	}


}
